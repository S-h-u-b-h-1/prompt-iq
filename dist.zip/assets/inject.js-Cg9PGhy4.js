import{t as e}from"./scorer-mk_Yd85t.js";import{_ as t,a as n,b as r,c as i,l as a,p as o,r as s,y as c}from"./activity-CYgcZLnf.js";import{t as l}from"./optimizer-BL7sNSRc.js";import{n as u,t as d}from"./local-optimizer-DdBhTxLm.js";var f=[{id:`chatgpt`,matches:[`chatgpt.com`,`chat.openai.com`],composers:[`#prompt-textarea`,`textarea[data-id="root"]`]},{id:`claude`,matches:[`claude.ai`],composers:[`[data-testid="chat-input"], [data-testid="chat-input"] [contenteditable="true"]`,`div.ProseMirror[contenteditable="true"]`]},{id:`gemini`,matches:[`gemini.google.com`],composers:[`rich-textarea .ql-editor[contenteditable="true"], .ql-editor[aria-label="Enter a prompt for Gemini"]`,`rich-textarea [contenteditable="true"], rich-textarea textarea`]},{id:`perplexity`,matches:[`www.perplexity.ai`],composers:[`[data-lexical-editor="true"][role="textbox"]`,`main textarea, form textarea`]},{id:`deepseek`,matches:[`chat.deepseek.com`],composers:[`#chat-input`,`main textarea, textarea[placeholder*="DeepSeek" i]`]},{id:`grok`,matches:[`grok.com`],composers:[`.query-bar-editor[contenteditable="true"], [aria-label="Message Grok"]`,`main textarea, main [contenteditable="true"][role="textbox"]`]},{id:`mistral`,matches:[`chat.mistral.ai`],composers:[`[data-testid="chat-input"], textarea[name="prompt"]`,`main textarea, main div.ProseMirror[contenteditable="true"]`]},{id:`meta`,matches:[`meta.ai`,`www.meta.ai`],composers:[`main [contenteditable="true"][role="textbox"], main textarea, form textarea`]},{id:`poe`,matches:[`poe.com`],composers:[`textarea[class*="ChatMessageInput"], textarea[class*="GrowingTextArea"]`,`main textarea, main [contenteditable="true"][role="textbox"]`]},{id:`you`,matches:[`you.com`],composers:[`main textarea, main [contenteditable="true"][role="textbox"], form textarea`]}];function p(e){return e.tagName===`TEXTAREA`||e.tagName===`INPUT`}function m(e){if(!e?.isConnected||e.disabled||e.readOnly||e.closest(`dialog, [role="dialog"], [hidden], [inert], [aria-hidden="true"], nav, [role="search"]`)||e.matches(`[aria-disabled="true"], [aria-readonly="true"]`)||!e.isContentEditable&&!e.matches(`textarea, input[type="text"], input[type="search"], input:not([type])`)||e.isContentEditable&&e.parentElement?.isContentEditable)return!1;let t=[e.getAttribute(`aria-label`),e.getAttribute(`placeholder`)].filter(Boolean).join(` `);if(/\b(feedback|rename|search (?:chats|conversations|history|messages)|edit (?:this )?message)\b/i.test(t))return!1;let n=e.getBoundingClientRect();return n.width>=110&&n.height>=20&&getComputedStyle(e).visibility===`visible`}function h(e,t){for(let n of e){let e=Array.from(document.querySelectorAll(n)).filter(m);if(e.length===1)return e[0];if(e.length>1)return e.find(e=>e===document.activeElement)??(e.includes(t)?t:null)}return null}function g(e){return e?p(e)?e.value:e.innerText||``:``}function _(e){return e.replace(/\u00a0/g,` `).split(`
`).filter(e=>e.trim()).join(`
`)}var v=()=>new Promise(e=>requestAnimationFrame(()=>requestAnimationFrame(e)));async function y(e,t,n){if(!m(e)||typeof t!=`string`)return!1;let r=t.replace(/\r\n?/g,`
`);if(e.tagName===`INPUT`&&r.includes(`
`))return!1;if(g(e)===r)return!0;if(e.focus({preventScroll:!0}),document.activeElement!==e)return!1;let i=`insertText`;if(p(e))e.select();else{let t=window.getSelection();if(!t)return!1;let n=document.createRange();n.selectNodeContents(e),t.removeAllRanges(),t.addRange(n),r||(i=`delete`)}let a=e.matches(`[data-lexical-editor="true"]`),o=a||e.matches(`.ProseMirror`);if(o){await v();let t=window.getSelection();if(!m(e)||!n()||document.activeElement!==e||!t?.anchorNode||!e.contains(t.anchorNode)||!e.contains(t.focusNode))return!1}if(a){if(r){let t=new DataTransfer;if(t.setData(`text/plain`,r),!e.dispatchEvent(new ClipboardEvent(`paste`,{clipboardData:t,bubbles:!0,cancelable:!0,composed:!0})))return await v(),_(g(e))===_(r)}else return document.execCommand(`delete`),await v(),!_(g(e))}try{if(document.execCommand(i,!1,r)){o&&await v();let t=g(e);return p(e)?t===r:_(t)===_(r)}}catch{}if(!p(e))return!1;let s=e.tagName===`INPUT`?HTMLInputElement.prototype:HTMLTextAreaElement.prototype;return Object.getOwnPropertyDescriptor(s,`value`).set.call(e,r),e.setSelectionRange(r.length,r.length),e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertReplacementText`})),g(e)===r}function b(){let e=f.find(({matches:e})=>e.includes(location.hostname));return e?{platform:e.id,getInputElement:t=>h(e.composers,t),getText:g,setText:y}:null}function x(e,t,n,r,i,a){let o=document.createElement(`div`);o.id=`promptiq-container`,o.style.cssText=`position: fixed; bottom: 24px; right: 24px; z-index: 2147483000; font-family: Inter, system-ui, -apple-system, sans-serif;`;let s=!1,c=null,l=!1,u=!1,d=`general`,f=null,p=null,m=o.attachShadow({mode:`closed`}),h=async()=>{try{if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage){let e=await chrome.runtime.sendMessage({action:`OPEN_ONBOARDING`});if(!e?.success)throw Error(e?.error||`Account page could not be opened.`);return}}catch{window.alert(`PromptIQ was updated. Refresh this page, then try opening the account again.`);return}window.alert(`Open the PromptIQ extension from your browser toolbar.`)},g={chatgpt:`ChatGPT`,claude:`Claude`,gemini:`Gemini`,perplexity:`Perplexity`,copilot:`Copilot`,deepseek:`DeepSeek`,grok:`Grok`,mistral:`Le Chat`,meta:`Meta AI`,poe:`Poe`,you:`You.com`,general:`AI assistant`},_=document.createElement(`style`);_.textContent=`
    :host {
      color-scheme: dark;
      --pi-bg: #101414;
      --pi-card: #101414;
      --pi-elevated: #171e1b;
      --pi-border: rgba(159, 255, 200, .08);
      --pi-text: #f1f7f3;
      --pi-muted: #a8b8af;
      --pi-primary: #9fffc8;
      --pi-primary-strong: #9fffc8;
      --pi-success: #9fffc8;
      --pi-warning: #9fffc8;
      --pi-danger: #9fffc8;
      --pi-pro: #9fffc8;
      --pi-glow: rgba(159, 255, 200, 0.08);
      --pi-shadow: rgba(159, 255, 200, 0.06);
      --pi-radius: 8px;
    }
    :host([hidden]) { display: none !important; }
    .insert-status {
      color: var(--pi-muted);
      font-size: 12px;
      margin: 0 0 8px;
    }


    .badge {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 9px 16px;
      border-radius: 9999px;
      background: var(--pi-elevated);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 25px -5px var(--pi-shadow);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .badge:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 30px -5px var(--pi-shadow);
      border-color: var(--pi-primary);
    }
    :host(.panel-open) .badge {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8) translateY(10px);
    }
    .score-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--pi-muted);
      transition: background 0.3s, box-shadow 0.3s;
    }
    .score-excellent { background: var(--pi-success); box-shadow: none; }
    .score-good { background: var(--pi-warning); box-shadow: none; }
    .score-fair { background: #9fffc8; box-shadow: none; }
    .score-weak { background: var(--pi-danger); box-shadow: none; }
    
    .panel-wrapper {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 24px;
      right: 24px;
      bottom: 24px;
      width: 382px;
      max-width: calc(100vw - 48px);
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: var(--pi-radius);
      box-shadow: 0 28px 60px -18px var(--pi-shadow), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 18px;
      color: var(--pi-text);
      box-sizing: border-box;
      z-index: 1000000;
      backdrop-filter: blur(24px) saturate(120%);
      -webkit-backdrop-filter: blur(24px) saturate(120%);
      overflow: hidden;
      
      transform: translateX(calc(100% + 48px));
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 0;
      pointer-events: none;
    }
    .panel-wrapper.visible {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    .panel-wrapper.has-result .signin-card,
    .panel-wrapper.has-result .score-area,
    .panel-wrapper.has-result .chips-container {
      display: none;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      border-bottom: 1px solid var(--pi-border);
      padding-bottom: 12px;
    }
    .header-logo-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title { 
      font-weight: 800; 
      font-size: 17px; 
      color: var(--pi-text); 
      letter-spacing: 0;
    }
    .status-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 2.5px 8px;
      border-radius: 6px;
      letter-spacing: 0;
    }
    .status-free {
      background: rgba(159, 255, 200, 0.1);
      color: var(--pi-muted);
    }
    .signin-card {
      display: none;
      background: rgba(159, 255, 200, 0.08);
      border: 1px solid rgba(159, 255, 200, 0.2);
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 14px;
      color: var(--pi-text);
    }
    .signin-card.visible {
      display: block;
    }
    .signin-title {
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .signin-copy {
      font-size: 11.5px;
      line-height: 1.45;
      color: var(--pi-muted);
      margin-bottom: 10px;
    }
    
    .mode-selector-wrapper {
      margin-bottom: 18px;
    }
    .mode-selector-wrapper label {
      display: block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: var(--pi-muted);
      letter-spacing: 0;
    }
    .settings-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1.2fr) minmax(0, .9fr);
      gap: 8px;
      margin-bottom: 10px;
    }
    .select-control {
      width: 100%;
      min-height: 38px;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font: inherit;
      font-size: 12px;
      font-weight: 700;
      box-sizing: border-box;
    }
    .platform-pill {
      min-height: 38px;
      display: flex;
      align-items: center;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
      box-sizing: border-box;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .engine-summary {
      padding: 8px 0 0;
      background: var(--pi-card);
    }
    .engine-name {
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
    }
    .engine-copy {
      margin-top: 3px;
      color: var(--pi-muted);
      font-size: 11px;
      line-height: 1.4;
    }

    /* Visual Score Progress Area */
    .score-area {
      background: var(--pi-card);
      border-block: 1px solid var(--pi-border);
      padding: 16px 0;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .score-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      flex-shrink: 0;
    }
    .score-ring {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    .score-ring-bg {
      fill: none;
      stroke: var(--pi-border);
      stroke-width: 4;
    }
    .score-ring-progress {
      fill: none;
      stroke: var(--pi-muted);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.5s ease;
    }
    .score-ring-val {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 15px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .score-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .score-grade {
      font-size: 16px;
      font-weight: 800;
      color: var(--pi-text);
    }

    /* Dimension Chips */
    .chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    .chip-present {
      background: rgba(159, 255, 200, 0.06);
      color: var(--pi-success);
      border-color: rgba(159, 255, 200, 0.12);
    }
    .chip-missing {
      background: rgba(159, 255, 200, 0.05);
      color: var(--pi-muted);
      border-color: var(--pi-border);
      opacity: 1;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 8px;
      border: 1px solid transparent;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
      font-family: inherit;
    }
    .btn:focus-visible,
    .feedback-btn:focus-visible,
    .badge:focus-visible,
    select:focus-visible,
    textarea:focus-visible {
      outline: 2px solid var(--pi-primary);
      outline-offset: 2px;
    }
    .btn-primary {
      background: var(--pi-primary);
      color: #101414;
      box-shadow: 0 4px 12px var(--pi-glow);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px var(--pi-glow);
    }
    .btn-primary:disabled {
      opacity: 0.5;
      transform: none;
      cursor: not-allowed;
    }
    .btn-secondary {
      background: var(--pi-card);
      color: var(--pi-text);
      border-color: var(--pi-border);
    }
    .btn-secondary:hover {
      background: var(--pi-border);
    }
    .btn-ghost {
      background: transparent;
      color: var(--pi-muted);
      border-color: var(--pi-border);
    }
    
    .result-section {
      display: none;
      margin-top: 18px;
      padding-top: 18px;
      border-top: 1px solid var(--pi-border);
      overflow-y: auto;
      flex: 1;
    }
    .success-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      margin-bottom: 12px;
      border-radius: 8px;
      border: 1px solid rgba(159, 255, 200, 0.18);
      background: rgba(159, 255, 200, 0.07);
    }
    .success-summary.pulse {
      animation: successPulse 650ms ease-out;
    }
    @keyframes successPulse {
      0% { transform: scale(0.985); border-color: rgba(159, 255, 200, 0.1); }
      100% { transform: scale(1); border-color: rgba(159, 255, 200, 0.18); }
    }
    .success-title {
      font-size: 13px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .success-copy {
      font-size: 11.5px;
      color: var(--pi-muted);
      margin-top: 2px;
    }
    .score-delta {
      font-size: 12px;
      font-weight: 800;
      color: var(--pi-success);
      white-space: nowrap;
    }
    
    /* Mock Editor Window */
    .editor-card {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.03);
    }
    .editor-header {
      background: rgba(159, 255, 200, 0.03);
      padding: 10px 16px;
      border-bottom: 1px solid var(--pi-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .editor-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }

    .optimized-textarea {
      width: 100%;
      height: 150px;
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      resize: vertical;
      font-family: inherit;
      color: var(--pi-text);
      box-sizing: border-box;
      max-height: 240px;
    }
    .optimized-textarea:focus {
      outline: none;
    }

    .diff-view {
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      max-height: 150px;
      overflow-y: auto;
      margin: 0;
      white-space: pre-wrap;
      color: var(--pi-text);
      box-sizing: border-box;
    }
    .diff-added {
      background: rgba(159, 255, 200, 0.15);
      color: var(--pi-success);
      font-weight: 600;
      padding: 2px 4px;
      border-radius: 4px;
    }
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    .comparison-grid[hidden] {
      display: none;
    }
    .compare-box {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      min-width: 0;
    }
    .compare-title {
      padding: 8px 10px;
      border-bottom: 1px solid var(--pi-border);
      color: var(--pi-muted);
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .compare-text {
      margin: 0;
      padding: 10px;
      min-height: 96px;
      max-height: 150px;
      overflow-y: auto;
      white-space: pre-wrap;
      color: var(--pi-text);
      font: inherit;
      font-size: 11.5px;
      line-height: 1.45;
    }

    .changes-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
    }
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .changes-title {
      font-weight: 700;
      font-size: 13px;
      color: var(--pi-text);
    }
    
    .changes-list {
      font-size: 12px;
      list-style: none;
      padding: 0;
      margin: 0 0 18px 0;
      max-height: 150px;
      overflow-y: auto;
      display: none;
    }
    .changes-list.expanded {
      display: block;
    }
    .change-item {
      display: flex;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid var(--pi-border);
    }
    .change-icon {
      font-size: 14px;
      flex-shrink: 0;
    }
    .change-content {
      line-height: 1.45;
    }
    .change-label {
      font-weight: 700;
      color: var(--pi-text);
    }
    
    /* Loading Shimmer State */
    .loader-shimmer {
      display: none;
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      padding: 20px;
      position: relative;
      overflow: hidden;
      margin-top: 18px;
    }
    .shimmer-line {
      height: 11px;
      background: var(--pi-border);
      margin-bottom: 12px;
      border-radius: 4px;
      position: relative;
      overflow: hidden;
    }
    .shimmer-line::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.5s infinite;
    }

    .shimmer-t { width: 35%; height: 13px; }
    .shimmer-l1 { width: 85%; }
    .shimmer-l2 { width: 95%; }
    .shimmer-l3 { width: 70%; }
    .shimmer-label {
      display: block;
      text-align: center;
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-muted);
      margin-top: 8px;
      letter-spacing: 0;
    }
    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }
    
    /* Feedback Section */
    .feedback-section {
      background: var(--pi-card);
      border-top: 1px solid var(--pi-border);
      padding: 14px;
      text-align: center;
      margin-top: 14px;
      margin-bottom: 14px;
    }
    .feedback-title {
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-text);
      display: block;
      margin-bottom: 10px;
    }
    .feedback-buttons {
      display: flex;
      gap: 10px;
      justify-content: center;
    }
    .feedback-btn {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 12.5px;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .feedback-btn:hover {
      background: var(--pi-border);
      transform: translateY(-1px);
    }
    .feedback-thanks {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--pi-success);
      display: none;
      margin-top: 4px;
    }

    /* Error and Authentication states */
    .error-panel {
      display: none;
      background: rgba(159, 255, 200, 0.04);
      border: 1px solid rgba(159, 255, 200, 0.18);
      border-radius: 8px;
      padding: 18px;
      text-align: left;
      margin-top: 18px;
    }
    .error-icon {
      font-size: 28px;
      margin-bottom: 10px;
    }
    .error-title {
      font-weight: 800;
      font-size: 15px;
      color: var(--pi-danger);
      margin-bottom: 6px;
    }
    .error-message {
      font-size: 12px;
      color: var(--pi-text);
      line-height: 1.5;
      margin-bottom: 14px;
    }
    *, *::before, *::after { letter-spacing: 0; }
    .panel-wrapper > * { flex-shrink: 0; }
    .panel-wrapper > .result-section { flex-shrink: 1; min-height: 0; }
    .panel-wrapper { overflow-y: auto; }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { animation: none !important; transition: none !important; }
    }
    @media (max-width: 520px) {
      .panel-wrapper {
        top: auto;
        left: 12px;
        right: 12px;
        bottom: 12px;
        width: auto;
        max-width: none;
        max-height: calc(100vh - 24px);
        padding: 16px;
      }
      .action-row {
        grid-template-columns: 1fr;
      }
      .settings-grid {
        grid-template-columns: 1fr 1fr;
        gap: 6px;
      }
      .platform-pill {
        grid-column: 1 / -1;
        min-height: 20px;
        padding: 0;
        border: 0;
        font-size: 10px;
      }
      .comparison-grid {
        grid-template-columns: 1fr;
      }
    }
  `,m.appendChild(_);let v=document.createElement(`div`);v.className=`badge`,v.tabIndex=0,v.setAttribute(`role`,`button`),v.setAttribute(`aria-label`,`Open PromptIQ optimizer`),v.innerHTML=`<div class="score-dot" id="score-dot"></div><span id="score-text">PromptIQ: 0</span>`,m.appendChild(v);let y=document.createElement(`div`);y.className=`panel-wrapper`,y.innerHTML=`
    <div class="header">
      <div class="header-logo-group">
        <svg width="24" height="24" viewBox="0 0 128 128" aria-hidden="true" style="flex-shrink:0"><rect width="128" height="128" rx="26" fill="#9fffc8"/><path fill="#101414" d="M31 31h42l24 25v18L73 98H53l-22 13V31zm17 17v34l17-10h5l12-12-12-12H48z" fill-rule="evenodd"/></svg>
        <div class="title">PromptIQ</div>
        <div class="status-badge status-free">FREE</div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary" id="logout-sidebar-btn" aria-label="Log out of PromptIQ" style="padding: 4px 8px; font-size: 10px; background: rgba(159, 255, 200, 0.08); color: var(--pi-danger); border-color: rgba(159, 255, 200, 0.12); display: none;">Log Out</button>
        <button class="btn btn-secondary" id="close-btn" aria-label="Close PromptIQ optimizer" style="padding: 6px 12px; font-size: 11px;">Close</button>
      </div>
    </div>
    
    <div class="mode-selector-wrapper">
      <label>Mode, engine, and platform</label>
      <div class="settings-grid">
        <select class="select-control" id="mode-select" aria-label="Optimization mode">
          <option value="standard">Standard</option>
          <option value="concise">Concise</option>
          <option value="detailed">Detailed</option>
          <option value="creative">Creative</option>
          <option value="technical">Technical</option>
        </select>
        <select class="select-control" id="engine-select" aria-label="Optimization engine">
          <option value="quick_rewrite">Quick Rewrite</option>
          <option value="ai_rewrite" disabled hidden>AI Rewrite</option>
        </select>
        <div class="platform-pill" id="platform-pill">AI assistant</div>
      </div>
      <div class="engine-summary">
        <div class="engine-name" id="engine-name">Quick Rewrite</div>
        <div class="engine-copy" id="engine-copy">Create an account to score, save, and optimize prompts.</div>
      </div>
    </div>

    <div class="signin-card" id="signin-card">
      <div class="signin-title" id="signin-title">Account required</div>
      <div class="signin-copy" id="signin-copy">Sign in or create an account to use PromptIQ.</div>
      <button class="btn btn-secondary" id="signin-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%; padding: 8px 10px; font-size: 12px;">Continue to Account</button>
    </div>

    <!-- Visual Score Circle & Info -->
    <div class="score-area">
      <div class="score-ring-container">
        <svg class="score-ring" viewBox="0 0 36 36">
          <path class="score-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="score-ring-progress" id="score-ring-bar" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="score-ring-val" id="score-ring-val">0</div>
      </div>
      <div class="score-info">
        <div class="score-label">Draft Quality</div>
        <div class="score-grade" id="score-grade">Empty</div>
      </div>
    </div>

    <!-- Dimension Chips -->
    <div class="chips-container" id="chips-container">
      <div class="chip chip-missing" data-dimension="task"><span class="chip-icon">✗</span> Task</div>
      <div class="chip chip-missing" data-dimension="context"><span class="chip-icon">✗</span> Context</div>
      <div class="chip chip-missing" data-dimension="role"><span class="chip-icon">✗</span> Role</div>
      <div class="chip chip-missing" data-dimension="format"><span class="chip-icon">✗</span> Format</div>
      <div class="chip chip-missing" data-dimension="constraints"><span class="chip-icon">✗</span> Constraints</div>
      <div class="chip chip-missing" data-dimension="specificity"><span class="chip-icon">✗</span> Specificity</div>
    </div>
    
    <button class="btn btn-primary" id="optimize-btn" aria-label="Optimize prompt" style="width: 100%;">Optimize Prompt</button>
    
    <!-- Shimmer Loader State -->
    <div class="loader-shimmer" id="loader-shimmer">
      <div class="shimmer-line shimmer-t"></div>
      <div class="shimmer-line shimmer-l1"></div>
      <div class="shimmer-line shimmer-l2"></div>
      <div class="shimmer-line shimmer-l3"></div>
      <span class="shimmer-label">Optimizing your prompt...</span>
    </div>

    <!-- Error/Auth card panel -->
    <div class="error-panel" id="error-panel">
      <div class="error-icon" id="error-panel-icon">!</div>
      <div class="error-title" id="error-panel-title">Optimization Failed</div>
      <div class="error-message" id="error-panel-message">Please try refreshing the page.</div>
      <button class="btn btn-secondary" id="error-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%;">Open Account</button>
    </div>
    
    <!-- Result Editor Area -->
    <div class="result-section" id="result-section">
      <div class="success-summary">
        <div>
          <div class="success-title">Prompt is ready</div>
          <div class="success-copy">Review it, copy it, or replace your draft.</div>
        </div>
        <div class="score-delta" id="score-delta">Improved</div>
      </div>
      <div class="editor-card">
        <div class="editor-header">
          <span class="editor-title" id="editor-view-title">Optimized Draft</span>
          <button class="btn btn-secondary" id="toggle-edit-btn" aria-label="Edit optimized prompt text" style="padding: 4px 10px; font-size: 11px;">Edit</button>
        </div>
        <div class="diff-view" id="diff-view"></div>
        <textarea class="optimized-textarea" id="optimized-text" style="display: none;"></textarea>
      </div>
      <button class="btn btn-primary" id="use-btn" aria-label="Use optimized prompt" style="width: 100%; margin: 12px 0;">Use Prompt</button>
      <p class="insert-status" id="insert-status" role="status" hidden></p>

      <div class="comparison-grid" id="comparison-grid" hidden>
        <div class="compare-box">
          <div class="compare-title">Original</div>
          <pre class="compare-text" id="compare-original"></pre>
        </div>
        <div class="compare-box">
          <div class="compare-title">Optimized</div>
          <pre class="compare-text" id="compare-optimized"></pre>
        </div>
      </div>
      
      <div class="changes-header" id="changes-header">
        <span class="changes-title">Changes Explained</span>
        <span style="font-size: 12px; color: var(--pi-primary); font-weight: 700;" id="toggle-changes-label">Show Changes</span>
      </div>
      <ul class="changes-list" id="changes-list"></ul>
      
      <!-- Feedback Loop Panel -->
      <div class="feedback-section" id="feedback-section">
        <span class="feedback-title">Was this optimization useful?</span>
        <div class="feedback-buttons" id="feedback-buttons-wrapper">
          <button class="feedback-btn" id="feedback-yes">Yes</button>
          <button class="feedback-btn" id="feedback-no">No</button>
        </div>
        <div class="feedback-thanks" id="feedback-thanks">Thank you! Your feedback helps us improve.</div>
      </div>
      
      <div class="action-row">
        <button class="btn btn-secondary" id="copy-btn" aria-label="Copy optimized prompt">Copy</button>
        <button class="btn btn-secondary" id="favorite-btn" aria-label="Save optimized prompt as favorite">Favorite</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="compare-btn" aria-label="Compare original and optimized prompt">Compare</button>
        <button class="btn btn-ghost" id="undo-btn" aria-label="Undo the last inserted optimization">Undo</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="retry-btn" aria-label="Retry optimization">Retry</button>
        <button class="btn btn-ghost" id="copy-original-btn" aria-label="Copy original prompt">Copy Original</button>
      </div>
    </div>
  `,m.appendChild(y);let b=m.getElementById(`optimized-text`),x=m.getElementById(`diff-view`),S=m.getElementById(`toggle-edit-btn`),C=m.getElementById(`changes-list`),w=m.getElementById(`changes-header`),T=m.getElementById(`toggle-changes-label`),E=m.getElementById(`optimize-btn`),D=m.getElementById(`loader-shimmer`),O=m.getElementById(`error-panel`),k=m.getElementById(`signin-card`),A=m.getElementById(`copy-btn`),j=m.getElementById(`copy-original-btn`),M=m.getElementById(`retry-btn`),N=m.getElementById(`mode-select`),P=m.getElementById(`engine-select`),F=m.getElementById(`platform-pill`),I=m.getElementById(`favorite-btn`),L=m.getElementById(`compare-btn`),R=m.getElementById(`undo-btn`),z=m.getElementById(`comparison-grid`),B=m.getElementById(`compare-original`),V=m.getElementById(`compare-optimized`);try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(`optimizationMode`,e=>{[...N.options].some(t=>t.value===e.optimizationMode)&&(N.value=e.optimizationMode)})}catch{}function H(){let e=m.getElementById(`engine-name`),t=m.getElementById(`engine-copy`),n=!!(p&&P.value===`ai_rewrite`);s||(E.textContent=n?`Send for AI Rewrite`:`Optimize Prompt`,E.setAttribute(`aria-label`,E.textContent)),!l||!u?(e.textContent=`Account required`,t.textContent=l?`Review the privacy settings to continue.`:`Create an account to score, save, and optimize prompts.`):n?(e.textContent=`AI Rewrite`,t.textContent=`Sends this prompt to FreeLLMAPI and ${p.provider} to rewrite it. The result is saved to your account.`):(e.textContent=`Quick Rewrite`,t.textContent=`Runs on your device. Completed rewrites are saved to your account history.`)}function U(){let e=l&&u;N.disabled=!e,P.disabled=!e,E.disabled=!e||s,k.classList.toggle(`visible`,!e);let t=m.getElementById(`signin-title`),n=m.getElementById(`signin-copy`),r=m.getElementById(`score-text`);l?u?(r.textContent.includes(`Sign in`)||r.textContent.includes(`Finish setup`))&&(r.textContent=`PromptIQ: 0`):(t.textContent=`Finish privacy setup`,n.textContent=`Review how PromptIQ scores drafts and saves rewrites.`,r.textContent=`PromptIQ: Finish setup`):(t.textContent=`Account required`,n.textContent=`Sign in or create an account to use PromptIQ.`,r.textContent=`PromptIQ: Sign in`),e&&p||(P.value=`quick_rewrite`),H()}let W=()=>{let e=y.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)};v.addEventListener(`click`,W),v.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),W())}),m.getElementById(`close-btn`).addEventListener(`click`,()=>{y.classList.remove(`visible`),o.classList.remove(`panel-open`),P.value=`quick_rewrite`,H()});let G=m.getElementById(`logout-sidebar-btn`);G.addEventListener(`click`,()=>{confirm(`Are you sure you want to log out of PromptIQ?`)&&r()}),m.getElementById(`signin-open-popup-btn`).addEventListener(`click`,h),m.getElementById(`error-open-popup-btn`).addEventListener(`click`,h),N.addEventListener(`change`,()=>{try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({optimizationMode:N.value})}catch{}}),P.addEventListener(`change`,H);let K=async t=>{if(t.isTrusted&&!E.disabled){if(!l||!u)h();else{y.classList.remove(`has-result`),D.style.display=`block`,O.style.display=`none`,m.getElementById(`result-section`).style.display=`none`,E.disabled=!0;try{await e()}catch(e){console.error(`onOptimize failed:`,e)}finally{D.style.display=`none`,!s&&l&&u&&(E.disabled=!1)}}}};E.addEventListener(`click`,K),S.addEventListener(`click`,()=>{let e=m.getElementById(`editor-view-title`);b.style.display===`none`?(b.value=x.textContent,b.style.display=`block`,x.style.display=`none`,S.textContent=`View Diff`,e.textContent=`Edit Mode`):(x.style.display=`block`,b.style.display=`none`,S.textContent=`Edit`,e.textContent=`Optimized Draft`)}),w.addEventListener(`click`,()=>{C.classList.toggle(`expanded`);let e=C.classList.contains(`expanded`);T.textContent=e?`Hide`:`Show Changes`});function q(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}let J=m.getElementById(`insert-status`),Y=m.getElementById(`use-btn`);return Y.addEventListener(`click`,async e=>{if(!e.isTrusted)return;let n=b.style.display===`none`?x.textContent:b.value;Y.disabled=!0;let r=!1;try{r=await t(n)}catch{}finally{Y.disabled=!1}r?(J.hidden=!0,y.classList.remove(`visible`),o.classList.remove(`panel-open`)):(J.textContent=`Could not insert safely. Copy the rewrite or optimize the current draft.`,J.hidden=!1)}),A.addEventListener(`click`,async()=>{let e=b.style.display===`none`?x.textContent:b.value;try{await navigator.clipboard.writeText(e),A.textContent=`Copied`}catch{A.textContent=`Copy failed`}setTimeout(()=>{A.textContent=`Copy`},1600)}),j.addEventListener(`click`,async()=>{let e=f?.original||``;try{await navigator.clipboard.writeText(e),j.textContent=`Copied`}catch{j.textContent=`Copy failed`}setTimeout(()=>{j.textContent=`Copy Original`},1600)}),L.addEventListener(`click`,()=>{z.hidden=!z.hidden,L.textContent=z.hidden?`Compare`:`Hide Compare`}),R.addEventListener(`click`,async e=>{if(!e.isTrusted)return;R.disabled=!0;let t=!1;try{t=await i()}catch{}finally{R.disabled=!1}R.textContent=t?`Undone`:`Nothing to undo`,setTimeout(()=>{R.textContent=`Undo`},1600)}),I.addEventListener(`click`,async()=>{if(!f||typeof a!=`function`)return;let e=b.style.display===`none`?x.textContent:b.value;I.disabled=!0;try{let t=await a({...f,optimized:e,mode:N.value});I.textContent=t?`Favorited`:`Favorite`}catch{I.textContent=`Favorite failed`}finally{setTimeout(()=>{I.disabled=!1,I.textContent===`Favorite failed`&&(I.textContent=`Favorite`)},1400)}}),M.addEventListener(`click`,K),m.getElementById(`feedback-yes`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`helpful`),m.getElementById(`feedback-buttons-wrapper`).style.display=`none`,m.getElementById(`feedback-thanks`).style.display=`block`)}),m.getElementById(`feedback-no`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`unhelpful`),m.getElementById(`feedback-buttons-wrapper`).style.display=`none`,m.getElementById(`feedback-thanks`).style.display=`block`)}),{container:o,setComposerAvailable:e=>{o.hidden=!e,e||(y.classList.remove(`visible`),o.classList.remove(`panel-open`))},open:()=>{y.classList.add(`visible`),o.classList.add(`panel-open`)},setCloudRewrite:e=>{p=e;let t=P.querySelector(`option[value="ai_rewrite"]`);t.hidden=t.disabled=!p,U()},clearResult:()=>{c=null,f=null,J.hidden=!0,b.value=``;for(let e of[x,B,V,C])e.replaceChildren();y.classList.remove(`has-result`),m.getElementById(`result-section`).style.display=`none`},setLoggedState:e=>{l=!!e,G.style.display=l?`block`:`none`,U()},setStorageReady:e=>{u=!!e,U()},showAccountRequired:(e=`signin`)=>{y.classList.add(`visible`),o.classList.add(`panel-open`),U()},getSettings:()=>({mode:N.value||`standard`,engine:p&&P.value===`ai_rewrite`?`ai_rewrite`:`quick_rewrite`,disclosureId:p?.id,platform:d||`general`}),setPlatform:e=>{d=e||`general`,F.textContent=g[d]||g.general},toggleVisibility:()=>{let e=y.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)},setTier:()=>{U()},updateScore:e=>{let t=m.getElementById(`score-dot`),n=m.getElementById(`score-text`),r=m.getElementById(`score-ring-bar`),i=m.getElementById(`score-ring-val`),a=m.getElementById(`score-grade`),o=Math.max(0,Math.min(100,e.score||0)),s=`Empty`;o>=76?s=`Strong`:o>=46?s=`Good`:o>0&&(s=`Weak`),i.textContent=o,a.textContent=s,n.textContent=`PromptIQ: ${o}`,r.setAttribute(`stroke-dasharray`,`${o}, 100`),t.className=`score-dot`,r.style.stroke=`var(--pi-muted)`,a.style.color=`var(--pi-text)`;let c=``,l=`var(--pi-muted)`;o>=76?(c=`score-excellent`,l=`var(--pi-success)`,a.style.color=`var(--pi-success)`):o>=46?(c=`score-good`,l=`var(--pi-warning)`,a.style.color=`var(--pi-warning)`):o>0&&(c=`score-weak`,l=`var(--pi-danger)`,a.style.color=`var(--pi-danger)`),c&&t.classList.add(c),r.style.stroke=l,m.querySelectorAll(`.chip`).forEach(t=>{let n=t.getAttribute(`data-dimension`);e.missing&&e.missing.includes(n)?(t.className=`chip chip-missing`,t.innerHTML=`<span class="chip-icon">✗</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`):(t.className=`chip chip-present`,t.innerHTML=`<span class="chip-icon">✓</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`)})},showResult:(e,t,n,r,i=null,a={})=>{J.hidden=!0,c=r,y.classList.add(`has-result`),O.style.display=`none`,m.getElementById(`result-section`).style.display=`block`,H(),z.hidden=!0,L.textContent=`Compare`,m.getElementById(`feedback-buttons-wrapper`).style.display=`flex`,m.getElementById(`feedback-thanks`).style.display=`none`,I.textContent=`Favorite`,b.value=e;let o=m.getElementById(`score-delta`);if(i&&Number.isFinite(i.originalScore)&&Number.isFinite(i.newScore)){let e=i.newScore-i.originalScore;o.textContent=e>=0?`+${e} pts`:`${e} pts`}else o.textContent=`Improved`;f={original:a.originalPrompt||``,optimized:e,platform:a.platform||d||`general`,intent:a.intent||null,mode:a.mode||N.value||`standard`,scoreOriginal:i?.originalScore??null,scoreOptimized:i?.newScore??null,timestamp:Date.now()},B.textContent=f.original,V.textContent=e,x.innerHTML=t.map(e=>e.added?`<span class="diff-added">${q(e.text)}</span>`:q(e.text)).join(``),C.innerHTML=n.map(e=>`
        <li class="change-item">
          <span class="change-icon" aria-hidden="true">+</span>
          <div class="change-content">
            <span class="change-label">${q(e.label)}:</span>
            <span>${q(e.description)}</span>
          </div>
        </li>
      `).join(``),C.classList.remove(`expanded`),T.textContent=`Show Changes`,x.style.display=`block`,b.style.display=`none`,S.textContent=`Edit`,m.getElementById(`editor-view-title`).textContent=`Optimized Draft`;let s=m.querySelector(`.success-summary`);s.classList.remove(`pulse`),s.offsetWidth,s.classList.add(`pulse`)},showError:e=>{y.classList.remove(`has-result`),D.style.display=`none`,E.disabled=!l||!u,m.getElementById(`result-section`).style.display=`none`;let t=m.getElementById(`error-panel-icon`),n=m.getElementById(`error-panel-title`),r=m.getElementById(`error-panel-message`);if(e.status===401||e.message.toLowerCase().includes(`log in`)||e.message.toLowerCase().includes(`session`)?(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=`Please log in again or try refreshing the page.`):(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=e.message||`Please log in again or try refreshing the page.`),O.style.display=`block`,e.code!==`LOCAL_DAILY_LIMIT_REACHED`&&e.code!==`PREMIUM_DAILY_LIMIT_REACHED`&&(e.status===429||e.message.includes(`429`)||e.message.includes(`quota`))){s=!0;let t=e.message.match(/retry in ([\d\.]+)s/i),n=t?Math.ceil(parseFloat(t[1])):60;E.disabled=!0,E.textContent=`Retry in ${n}s`;let r=setInterval(()=>{n--,n<=0?(clearInterval(r),s=!1,U()):E.textContent=`Retry in ${n}s`},1e3)}}}}function S(e,t=2e3){let n,r,i=0;return{reset(){clearTimeout(n),r=null,i=0},schedule(a,o,s){if(clearTimeout(n),!a.trim()){r=null,i=0;return}if(a.length>6e3)return;r||=crypto.randomUUID();let c={kind:`draft`,clientId:r,text:a,platform:o,mode:s,revision:++i};n=setTimeout(()=>{Promise.resolve(e(c)).catch(()=>{})},t)}}}function C(e,t){let n=e.split(/(\s+)/),r=t.split(/(\s+)/),i=Array(n.length+1).fill(null).map(()=>Array(r.length+1).fill(0));for(let e=1;e<=n.length;e++)for(let t=1;t<=r.length;t++)n[e-1]===r[t-1]?i[e][t]=i[e-1][t-1]+1:i[e][t]=Math.max(i[e-1][t],i[e][t-1]);let a=[],o=n.length,s=r.length;for(;o>0||s>0;)o>0&&s>0&&n[o-1]===r[s-1]?(a.unshift({text:n[o-1],added:!1}),o--,s--):s>0&&(o===0||i[o][s-1]>=i[o-1][s])?(a.unshift({text:r[s-1],added:!0}),s--):o--;let c=[];for(let e of a)c.length>0&&c[c.length-1].added===e.added?c[c.length-1].text+=e.text:c.push({...e});return c}var w={role:{label:`Role / Persona`,icon:`👤`},task:{label:`Task Definition`,icon:`🎯`},context:{label:`Context / Background`,icon:`📖`},format:{label:`Output Format`,icon:`📊`},constraints:{label:`Constraints`,icon:`⛔`},specificity:{label:`Specificity`,icon:`🔍`},addition:{label:`Added Detail`,icon:`➕`},modification:{label:`Refined Phrasing`,icon:`✏️`},removal:{label:`Removed Clutter`,icon:`➖`}};function T(e){return Array.isArray(e)?e.map(e=>{let t=(e.type||``).toLowerCase(),n=w[t]||{label:`General Optimization`,icon:`⚡`};return{type:t,label:n.label,icon:n.icon,description:e.description||``}}):[]}var E=null,D=null,O=null,k=``,A=null,j=null,M=null,N=0,P=!1,F=!1,I=null,L=0,R=S(e=>I&&n(e,I));async function z(e){let t=++L;F=!1,I=null,R.reset();let n=e===void 0?await o():e,r;if(n)try{r=await s(!0)}catch{}let i=await o();if(t===L&&n===i&&(F=!!(n&&r?.disclosureVersion===`2026-11-19-v4`),I=F&&r.saveDrafts?n:null,D?.setLoggedState(!!n),D?.setStorageReady(F),D?.setCloudRewrite(null),F&&E&&W(),F)){let e=await l();t===L&&D?.setCloudRewrite(e)}}function B(){return typeof chrome>`u`||!chrome.runtime||!chrome.runtime.id?(V(),!1):!0}function V(){R.reset();try{E&&E.removeEventListener(`input`,W),M?.disconnect(),cancelAnimationFrame(N),document.removeEventListener(`focusin`,K),window.navigation?.removeEventListener(`currententrychange`,K),window.removeEventListener(`keydown`,X);let e=document.getElementById(`promptiq-container`);e&&e.remove()}catch{}}function H(){try{typeof chrome<`u`&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,t)=>{if(t===`local`&&D){if(e.sessionToken){A=null,j=null,D.clearResult(),R.reset();let t=e.sessionToken.newValue;z(t)}e.promptIqCapturePreferencesVersion&&z(),e.userTier&&D.setTier(e.userTier.newValue||`free`)}})}catch{}}function U(){O=b(),O&&!document.getElementById(`promptiq-container`)&&(Y(),D.setPlatform(O.platform),G(),z(),q(),ee(),te(),H())}function W(t){if(!B()||!E?.isConnected||!D||P||!F)return;let n=O.getText(E);I&&t?.isTrusted&&typeof n==`string`&&R.schedule(n,O.platform,D.getSettings().mode);let r=e(n);r.missing=u(n).missing,D.updateScore(r)}function G(){let e=location.pathname+location.search,t=O.getInputElement(e===k?E:null);if(t===E&&e===k)return;let n=e!==k;R.reset(),E?.removeEventListener(`input`,W),E=t,k=e,D.setComposerAvailable(!!t),n&&(A=null,j=null,D.clearResult()),E?.addEventListener(`input`,W),t&&F&&W()}function K(){N||=requestAnimationFrame(()=>{N=0,B()&&G()})}function q(){M=new MutationObserver(K),M.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:[`contenteditable`,`hidden`,`inert`,`aria-hidden`,`disabled`,`readonly`,`aria-disabled`,`aria-readonly`]}),document.addEventListener(`focusin`,K),window.navigation?.addEventListener(`currententrychange`,K)}async function J(){await i(),A=null,j=null,++L,F=!1,I=null,R.reset(),D&&(D.clearResult(),D.setLoggedState(!1),D.setStorageReady(!1),D.setTier(`free`),D.showError(Error(`Signed out. Create an account or sign in to use PromptIQ.`)))}function Y(){document.getElementById(`promptiq-container`)||(D=x(Z,ne,oe,J,re,ae),document.body.appendChild(D.container))}function X(e){if(B()&&e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()===`p`){if(G(),!E)return;e.preventDefault(),D.toggleVisibility()}}function ee(){window.addEventListener(`keydown`,X)}function te(){try{chrome.runtime.onMessage.addListener((e,t)=>{B()&&t.id===chrome.runtime.id&&e.action===`OPTIMIZE_SELECTION`&&(G(),E&&typeof e.text==`string`&&(D.open(),Z(e.text)))})}catch{}}async function Z(n=null){if(!B())return;let s=await o();if(!s||!F){D.showAccountRequired(s?`consent`:`signin`);return}if(G(),!E){D.showError(Error(`No chat composer is open. Paste your draft into the PromptIQ toolbar to rewrite it.`));return}let c={el:E,route:k,text:O.getText(E)},l=(n??c.text).trim();if(!l){D.showError(Error(`Prompt is empty.`));return}if(l.length>6e3){D.showError(Error(`Rewrite supports up to 6,000 characters.`));return}let u=D.getSettings?D.getSettings():{mode:`standard`,platform:O.platform},f=u.mode||`standard`,p=n===null?u.engine:`quick_rewrite`;D&&(D.setLoggedState(!0),D.setStorageReady(!0),D.setTier(`free`));let m=d(l,{mode:f,platform:O.platform}),h,g=p===`ai_rewrite`;try{if(r(`optimization_requested`),g)try{let e=await chrome.runtime.sendMessage({action:`CALL_OPTIMIZER`,originalPrompt:l,platform:O.platform,disclosureId:u.disclosureId,detectedIntent:m.intent,mode:f,token:s});if(!e||!e.success){let t=Error(e?.error||`Failed to optimize prompt.`);throw t.status=e?.status,t.code=e?.code,t}h=e.result}catch(e){if(e.status===401||e.status===403)throw e;await a(`free`),h=Q(m),h.changes.unshift({type:`specificity`,description:e.code===`CLOUD_AI_DAILY_LIMIT_REACHED`?`The daily AI Rewrite allowance was used, so PromptIQ completed this rewrite on your device.`:`AI Rewrite was unavailable, so PromptIQ completed this rewrite on your device.`}),g=!1,r(`optimization_fallback_used`)}else await a(`free`),h=Q(m);if(s!==await o())return;let n=e(l).score,i=e(h.optimized).score,d=await t(l,h.optimized,i-n,O.platform,m.intent,f,n,i,g?`ai_rewrite`:`quick_rewrite`,s);if(s!==await o()||(G(),c.route!==k||c.el!==E))return;A=c;let p=C(l,h.optimized),_=T(h.changes);D.showResult(h.optimized,p,_,d,{originalScore:n,newScore:i},{originalPrompt:l,platform:O.platform,intent:m.intent,mode:f,engine:g?`ai_rewrite`:`quick_rewrite`,tier:`free`}),r(`optimization_completed`)}catch(e){if(r(`optimization_failed`),e.code===`CLOUD_AI_DAILY_LIMIT_REACHED`||e.code===`LOCAL_DAILY_LIMIT_REACHED`)D&&D.showError(e);else if(e.status===401||e.status===403)await i(),F=!1,R.reset(),D&&(D.setLoggedState(!1),D.setStorageReady(!1),D.setTier(`free`)),D.showError(Error(`Your account session expired. Sign in again to continue.`));else if(e.message&&e.message.includes(`Extension context invalidated`)){let e=Error(`PromptIQ has been updated. Please refresh the page to continue.`);D.showError(e)}else D&&D.showError(e)}}function Q(e){return{optimized:e.enhancedPrompt,changes:[{type:`task`,description:`Preserved your request in a separate Task section.`},{type:`specificity`,description:`Added brief guidance for the detected task and your selected mode where applicable.`}]}}async function ne(e){if(!B()||!F||!e?.trim()||(G(),!$(A)))return!1;let t=A,n=t.text;if(!await ie(e,t)||A!==t)return!1;let i=O.getText(E);return A={el:E,route:k,text:i},i!==n&&(j={...A,original:n},r(`prompt_inserted`)),!0}async function re(){if(!B()||!F)return!1;G();let e=j;return!$(e)||!await ie(e.original,e)||j!==e?!1:(A={el:E,route:k,text:O.getText(E)},j=null,!0)}function $(e){return!!(e&&E&&e.el===E&&e.route===k&&e.text===O.getText(E))}async function ie(e,t){if(P)return!1;P=!0,R.reset();try{let n=await O.setText(t.el,e,()=>F&&location.pathname+location.search===t.route&&$(t));return G(),n&&E===t.el&&k===t.route}finally{P=!1,W()}}async function ae(e){if(!B())return!1;let t=await c(e);return r(`favorite_toggled`),t.favorite}async function oe(e,t){if(!B()||!e)return;let n=await o();if(n)try{await fetch(`https://promptiq-theta.vercel.app/api/feedback`,{method:`POST`,headers:{Authorization:`Bearer ${n}`,"Content-Type":`application/json`},body:JSON.stringify({id:e,feedback:t})})}catch{console.warn(`PromptIQ feedback could not be saved`)}}U();