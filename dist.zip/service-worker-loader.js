import './assets/service-worker.js-CASUG8y0.js';
