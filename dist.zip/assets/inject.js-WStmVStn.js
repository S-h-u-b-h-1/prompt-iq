import{c as e,f as t,h as n,i as r,l as i,s as a,t as o}from"./storage-fD0Ei4MN.js";var s=[{id:`chatgpt`,matches:[`chatgpt.com`,`chat.openai.com`],selector:`#prompt-textarea`,isContentEditable:!1},{id:`claude`,matches:[`claude.ai`],selector:`div.ProseMirror`,isContentEditable:!0},{id:`gemini`,matches:[`gemini.google.com`],selector:`rich-textarea p, .ql-editor p, rich-textarea, .text-input-field`,isContentEditable:!0},{id:`perplexity`,matches:[`www.perplexity.ai`],selector:`textarea`,isContentEditable:!1},{id:`copilot`,matches:[`copilot.microsoft.com`],selector:`#searchbox, textarea`,isContentEditable:!1},{id:`deepseek`,matches:[`chat.deepseek.com`],selector:`#chat-input, textarea`,isContentEditable:!1}];function c(){let e=window.location.hostname,t=s.find(t=>t.matches.some(t=>e.includes(t)));return t?{platform:t.id,getInputElement:()=>{let e=t.selector.split(`,`).map(e=>e.trim());for(let t of e){let e=document.querySelector(t);if(e)return e}return null},getText:e=>e?e.tagName===`TEXTAREA`||e.tagName===`INPUT`?e.value||``:e.innerText||``:``,setText:(e,t)=>{if(!e)return;e.focus();let n=e.tagName===`TEXTAREA`||e.tagName===`INPUT`;if(n)e.select();else{let t=document.createRange();t.selectNodeContents(e);let n=window.getSelection();n.removeAllRanges(),n.addRange(t)}let r=!1;try{r=document.execCommand(`insertText`,!1,t)}catch(e){console.error(`execCommand failed:`,e)}if(!r)if(!n)e.innerText=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}));else{let n=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}:null}function l(e,t,n,r){let i=document.createElement(`div`);i.id=`promptiq-container`,i.style.cssText=`position: fixed; bottom: 24px; right: 24px; z-index: 999999; font-family: "Plus Jakarta Sans", system-ui, -apple-system, sans-serif;`;let a=!1,o=null,s=`free`;(document.documentElement.classList.contains(`dark`)||document.body.classList.contains(`dark`)||document.documentElement.getAttribute(`data-theme`)===`dark`||window.matchMedia(`(prefers-color-scheme: dark)`).matches)&&i.classList.add(`dark-mode`);let c=i.attachShadow({mode:`open`}),l=()=>{try{if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.getURL){window.open(chrome.runtime.getURL(`src/popup/popup.html`),`_blank`,`noopener,noreferrer`);return}}catch{}window.alert(`Open the PromptIQ extension from your browser toolbar.`)},u=document.createElement(`style`);u.textContent=`
    :host {
      --pi-bg: #ffffff;
      --pi-card: #f8fafc;
      --pi-elevated: rgba(255, 255, 255, 0.88);
      --pi-border: #dbe3ee;
      --pi-text: #0f172a;
      --pi-muted: #64748b;
      --pi-primary: #2563eb;
      --pi-primary-strong: #1d4ed8;
      --pi-success: #10b981;
      --pi-warning: #f59e0b;
      --pi-danger: #ef4444;
      --pi-pro: #7c3aed;
      --pi-glow: rgba(37, 99, 235, 0.08);
      --pi-shadow: rgba(0, 0, 0, 0.06);
      --pi-radius: 18px;
    }
    :host(.dark-mode) {
      --pi-bg: rgba(9, 14, 26, 0.94);
      --pi-card: rgba(18, 27, 44, 0.82);
      --pi-elevated: rgba(15, 23, 42, 0.94);
      --pi-border: rgba(148, 163, 184, 0.18);
      --pi-text: #f8fafc;
      --pi-muted: #94a3b8;
      --pi-primary: #38bdf8;
      --pi-primary-strong: #0ea5e9;
      --pi-success: #34d399;
      --pi-warning: #fbbf24;
      --pi-danger: #f87171;
      --pi-pro: #a78bfa;
      --pi-glow: rgba(56, 189, 248, 0.18);
      --pi-shadow: rgba(0, 0, 0, 0.35);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 9px 16px;
      border-radius: 9999px;
      background: var(--pi-elevated);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 25px -5px var(--pi-shadow);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .badge:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 30px -5px var(--pi-shadow);
      border-color: var(--pi-primary);
    }
    :host(.panel-open) .badge {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8) translateY(10px);
    }
    .score-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--pi-muted);
      transition: background 0.3s, box-shadow 0.3s;
    }
    .score-excellent { background: var(--pi-success); box-shadow: 0 0 10px var(--pi-success); }
    .score-good { background: var(--pi-warning); box-shadow: 0 0 10px var(--pi-warning); }
    .score-fair { background: #f97316; box-shadow: 0 0 10px #f97316; }
    .score-weak { background: var(--pi-danger); box-shadow: 0 0 10px var(--pi-danger); }
    
    .panel-wrapper {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 24px;
      right: 24px;
      bottom: 24px;
      width: 382px;
      max-width: calc(100vw - 48px);
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: var(--pi-radius);
      box-shadow: 0 28px 60px -18px var(--pi-shadow), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 18px;
      color: var(--pi-text);
      box-sizing: border-box;
      z-index: 1000000;
      backdrop-filter: blur(24px) saturate(120%);
      -webkit-backdrop-filter: blur(24px) saturate(120%);
      overflow: hidden;
      
      transform: translateX(calc(100% + 48px));
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 0;
      pointer-events: none;
    }
    .panel-wrapper.visible {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      border-bottom: 1px solid var(--pi-border);
      padding-bottom: 12px;
    }
    .header-logo-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title { 
      font-weight: 800; 
      font-size: 17px; 
      color: var(--pi-text); 
      letter-spacing: 0;
    }
    .status-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 2.5px 8px;
      border-radius: 6px;
      letter-spacing: 0.05em;
    }
    .status-free {
      background: rgba(100, 116, 139, 0.1);
      color: var(--pi-muted);
    }
    .status-pro {
      background: rgba(124, 58, 237, 0.14);
      color: var(--pi-pro);
      border: 1px solid rgba(139, 92, 246, 0.2);
    }
    .signin-card {
      display: none;
      background: rgba(245, 158, 11, 0.08);
      border: 1px solid rgba(245, 158, 11, 0.2);
      border-radius: 14px;
      padding: 12px;
      margin-bottom: 14px;
      color: var(--pi-text);
    }
    .signin-card.visible {
      display: block;
    }
    .signin-title {
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .signin-copy {
      font-size: 11.5px;
      line-height: 1.45;
      color: var(--pi-muted);
      margin-bottom: 10px;
    }
    
    .mode-selector-wrapper {
      margin-bottom: 18px;
    }
    .mode-selector-wrapper label {
      display: block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: var(--pi-muted);
      letter-spacing: 0.05em;
    }
    .mode-selector-wrapper select {
      width: 100%;
      padding: 10px 14px;
      border-radius: 12px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 600;
      outline: none;
      transition: all 0.2s;
      cursor: pointer;
    }
    .mode-selector-wrapper select:focus {
      border-color: var(--pi-primary);
      box-shadow: 0 0 0 3px var(--pi-glow);
    }

    /* Visual Score Progress Area */
    .score-area {
      background: linear-gradient(180deg, var(--pi-card), transparent);
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      padding: 16px;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .score-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      flex-shrink: 0;
    }
    .score-ring {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    .score-ring-bg {
      fill: none;
      stroke: var(--pi-border);
      stroke-width: 4;
    }
    .score-ring-progress {
      fill: none;
      stroke: var(--pi-muted);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.5s ease;
    }
    .score-ring-val {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 15px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .score-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .score-grade {
      font-size: 16px;
      font-weight: 800;
      color: var(--pi-text);
    }

    /* Dimension Chips */
    .chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    .chip-present {
      background: rgba(16, 185, 129, 0.06);
      color: var(--pi-success);
      border-color: rgba(16, 185, 129, 0.12);
    }
    .chip-missing {
      background: rgba(100, 116, 139, 0.05);
      color: var(--pi-muted);
      border-color: var(--pi-border);
      opacity: 0.65;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 12px;
      border: 1px solid transparent;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
      font-family: inherit;
    }
    .btn:focus-visible,
    .feedback-btn:focus-visible,
    .badge:focus-visible,
    select:focus-visible,
    textarea:focus-visible {
      outline: 2px solid var(--pi-primary);
      outline-offset: 2px;
    }
    .btn-primary {
      background: linear-gradient(135deg, var(--pi-primary), var(--pi-primary-strong));
      color: #ffffff;
      box-shadow: 0 4px 12px var(--pi-glow);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px var(--pi-glow);
    }
    .btn-primary:disabled {
      opacity: 0.5;
      transform: none;
      cursor: not-allowed;
    }
    .btn-secondary {
      background: var(--pi-card);
      color: var(--pi-text);
      border-color: var(--pi-border);
    }
    .btn-secondary:hover {
      background: var(--pi-border);
    }
    .btn-ghost {
      background: transparent;
      color: var(--pi-muted);
      border-color: var(--pi-border);
    }
    
    .result-section {
      display: none;
      margin-top: 18px;
      padding-top: 18px;
      border-top: 1px solid var(--pi-border);
      overflow-y: auto;
      flex: 1;
    }
    .success-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      margin-bottom: 12px;
      border-radius: 14px;
      border: 1px solid rgba(16, 185, 129, 0.18);
      background: rgba(16, 185, 129, 0.07);
    }
    .success-title {
      font-size: 13px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .success-copy {
      font-size: 11.5px;
      color: var(--pi-muted);
      margin-top: 2px;
    }
    .score-delta {
      font-size: 12px;
      font-weight: 800;
      color: var(--pi-success);
      white-space: nowrap;
    }
    
    /* Mock Editor Window */
    .editor-card {
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      background: var(--pi-card);
      overflow: hidden;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.03);
    }
    .editor-header {
      background: rgba(15, 23, 42, 0.03);
      padding: 10px 16px;
      border-bottom: 1px solid var(--pi-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .editor-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .optimized-textarea {
      width: 100%;
      height: 150px;
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      resize: vertical;
      font-family: inherit;
      color: var(--pi-text);
      box-sizing: border-box;
      max-height: 240px;
    }
    .optimized-textarea:focus {
      outline: none;
    }

    .diff-view {
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      max-height: 150px;
      overflow-y: auto;
      margin: 0;
      white-space: pre-wrap;
      color: var(--pi-text);
      box-sizing: border-box;
    }
    .diff-added {
      background: rgba(16, 185, 129, 0.15);
      color: var(--pi-success);
      font-weight: 600;
      padding: 2px 4px;
      border-radius: 4px;
    }

    .changes-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
    }
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .changes-title {
      font-weight: 700;
      font-size: 13px;
      color: var(--pi-text);
    }
    
    .changes-list {
      font-size: 12px;
      list-style: none;
      padding: 0;
      margin: 0 0 18px 0;
      max-height: 150px;
      overflow-y: auto;
      display: none;
    }
    .changes-list.expanded {
      display: block;
    }
    .change-item {
      display: flex;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid var(--pi-border);
    }
    .change-icon {
      font-size: 14px;
      flex-shrink: 0;
    }
    .change-content {
      line-height: 1.45;
    }
    .change-label {
      font-weight: 700;
      color: var(--pi-text);
    }
    
    /* Loading Shimmer State */
    .loader-shimmer {
      display: none;
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      padding: 20px;
      position: relative;
      overflow: hidden;
      margin-top: 18px;
    }
    .shimmer-line {
      height: 11px;
      background: var(--pi-border);
      margin-bottom: 12px;
      border-radius: 4px;
      position: relative;
      overflow: hidden;
    }
    .shimmer-line::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.5s infinite;
    }
    :host(.dark-mode) .shimmer-line::after {
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.05), transparent);
    }
    .shimmer-t { width: 35%; height: 13px; }
    .shimmer-l1 { width: 85%; }
    .shimmer-l2 { width: 95%; }
    .shimmer-l3 { width: 70%; }
    .shimmer-label {
      display: block;
      text-align: center;
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-muted);
      margin-top: 8px;
      letter-spacing: 0.02em;
    }
    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }
    
    /* Paywall Overlay */
    .paywall-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(15, 23, 42, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
      z-index: 1000010;
      padding: 20px;
      box-sizing: border-box;
    }
    .paywall-overlay.active {
      opacity: 1;
      pointer-events: auto;
    }
    .paywall-card {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: 20px;
      padding: 28px;
      text-align: center;
      max-width: 320px;
      box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.4);
      box-sizing: border-box;
    }
    .paywall-icon {
      font-size: 36px;
      margin-bottom: 12px;
    }
    .paywall-title {
      font-weight: 800;
      font-size: 18px;
      margin-bottom: 8px;
      color: var(--pi-text);
      letter-spacing: 0;
    }
    .paywall-desc {
      font-size: 12.5px;
      color: var(--pi-muted);
      margin-bottom: 20px;
      line-height: 1.5;
    }
    
    /* Feedback Section */
    .feedback-section {
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 12px;
      padding: 14px;
      text-align: center;
      margin-top: 14px;
      margin-bottom: 14px;
    }
    .feedback-title {
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-text);
      display: block;
      margin-bottom: 10px;
    }
    .feedback-buttons {
      display: flex;
      gap: 10px;
      justify-content: center;
    }
    .feedback-btn {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 12.5px;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .feedback-btn:hover {
      background: var(--pi-border);
      transform: translateY(-1px);
    }
    .feedback-thanks {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--pi-success);
      display: none;
      margin-top: 4px;
    }

    /* Error and Authentication states */
    .error-panel {
      display: none;
      background: linear-gradient(180deg, rgba(239, 68, 68, 0.08), rgba(239, 68, 68, 0.03));
      border: 1px solid rgba(239, 68, 68, 0.18);
      border-radius: 16px;
      padding: 18px;
      text-align: left;
      margin-top: 18px;
    }
    .error-icon {
      font-size: 28px;
      margin-bottom: 10px;
    }
    .error-title {
      font-weight: 800;
      font-size: 15px;
      color: var(--pi-danger);
      margin-bottom: 6px;
    }
    .error-message {
      font-size: 12px;
      color: var(--pi-text);
      line-height: 1.5;
      margin-bottom: 14px;
    }
    @media (max-width: 520px) {
      .panel-wrapper {
        top: auto;
        left: 12px;
        right: 12px;
        bottom: 12px;
        width: auto;
        max-width: none;
        max-height: calc(100vh - 24px);
        padding: 16px;
      }
      .action-row {
        grid-template-columns: 1fr;
      }
    }
  `,c.appendChild(u);let d=document.createElement(`div`);d.className=`badge`,d.tabIndex=0,d.setAttribute(`role`,`button`),d.setAttribute(`aria-label`,`Open PromptIQ optimizer`),d.innerHTML=`<div class="score-dot" id="score-dot"></div><span id="score-text">PromptIQ: 0</span>`,c.appendChild(d);let f=document.createElement(`div`);f.className=`panel-wrapper`,f.innerHTML=`
    <div class="header">
      <div class="header-logo-group">
        <div class="title">PromptIQ Optimizer</div>
        <div class="status-badge status-free" id="header-pro-badge">FREE</div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary" id="logout-sidebar-btn" aria-label="Log out of PromptIQ" style="padding: 4px 8px; font-size: 10px; background: rgba(239, 68, 68, 0.08); color: var(--pi-danger); border-color: rgba(239, 68, 68, 0.12); display: none;">Log Out</button>
        <button class="btn btn-secondary" id="close-btn" aria-label="Close PromptIQ optimizer" style="padding: 6px 12px; font-size: 11px;">Close</button>
      </div>
    </div>
    
    <!-- Mode Selector -->
    <div class="mode-selector-wrapper">
      <label for="mode-select">Optimization Mode</label>
      <select id="mode-select">
        <option value="turbo">⚡ Turbo (Free)</option>
        <option value="professional">🔒 Professional (Pro)</option>
        <option value="research">🔒 Research (Pro)</option>
        <option value="creative">🔒 Creative (Pro)</option>
        <option value="coding">🔒 Coding (Pro)</option>
        <option value="business">🔒 Business (Pro)</option>
      </select>
    </div>

    <div class="signin-card" id="signin-card">
      <div class="signin-title">Sign in required</div>
      <div class="signin-copy">Open the PromptIQ popup to log in, then return here to optimize prompts inline.</div>
      <button class="btn btn-secondary" id="signin-open-popup-btn" aria-label="Open PromptIQ popup" style="width: 100%; padding: 8px 10px; font-size: 12px;">Open PromptIQ Popup</button>
    </div>

    <!-- Visual Score Circle & Info -->
    <div class="score-area">
      <div class="score-ring-container">
        <svg class="score-ring" viewBox="0 0 36 36">
          <path class="score-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="score-ring-progress" id="score-ring-bar" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="score-ring-val" id="score-ring-val">0</div>
      </div>
      <div class="score-info">
        <div class="score-label">Draft Quality</div>
        <div class="score-grade" id="score-grade">Empty</div>
      </div>
    </div>

    <!-- Dimension Chips -->
    <div class="chips-container" id="chips-container">
      <div class="chip chip-missing" data-dimension="task"><span class="chip-icon">✗</span> Task</div>
      <div class="chip chip-missing" data-dimension="context"><span class="chip-icon">✗</span> Context</div>
      <div class="chip chip-missing" data-dimension="role"><span class="chip-icon">✗</span> Role</div>
      <div class="chip chip-missing" data-dimension="format"><span class="chip-icon">✗</span> Format</div>
      <div class="chip chip-missing" data-dimension="constraints"><span class="chip-icon">✗</span> Constraints</div>
      <div class="chip chip-missing" data-dimension="specificity"><span class="chip-icon">✗</span> Specificity</div>
    </div>
    
    <button class="btn btn-primary" id="optimize-btn" aria-label="Optimize prompt" style="width: 100%;">Optimize Prompt</button>
    
    <!-- Shimmer Loader State -->
    <div class="loader-shimmer" id="loader-shimmer">
      <div class="shimmer-line shimmer-t"></div>
      <div class="shimmer-line shimmer-l1"></div>
      <div class="shimmer-line shimmer-l2"></div>
      <div class="shimmer-line shimmer-l3"></div>
      <span class="shimmer-label">Optimizing your prompt...</span>
    </div>

    <!-- Error/Auth card panel -->
    <div class="error-panel" id="error-panel">
      <div class="error-icon" id="error-panel-icon">!</div>
      <div class="error-title" id="error-panel-title">Optimization Failed</div>
      <div class="error-message" id="error-panel-message">Please try refreshing the page.</div>
      <button class="btn btn-secondary" id="error-open-popup-btn" aria-label="Open PromptIQ popup" style="width: 100%;">Open PromptIQ Popup</button>
    </div>
    
    <!-- Paywall Overlay -->
    <div class="paywall-overlay" id="paywall-overlay">
      <div class="paywall-card">
        <div class="paywall-icon" id="paywall-icon">PRO</div>
        <div class="paywall-title" id="paywall-title">Unlock PromptIQ Pro</div>
        <div class="paywall-desc" id="paywall-desc">Unlock advanced modes and unlimited daily optimizations.</div>
        <button class="btn btn-primary" id="paywall-upgrade-btn" aria-label="Open PromptIQ popup to upgrade" style="width: 100%;">Open Upgrade Options</button>
        <button class="btn btn-secondary" id="paywall-close-btn" aria-label="Close upgrade message" style="width: 100%; margin-top: 8px;">Back</button>
      </div>
    </div>
    
    <!-- Result Editor Area -->
    <div class="result-section" id="result-section">
      <div class="success-summary">
        <div>
          <div class="success-title">Prompt is ready</div>
          <div class="success-copy">Review it, copy it, or send it back to the chat box.</div>
        </div>
        <div class="score-delta" id="score-delta">Improved</div>
      </div>
      <div class="editor-card">
        <div class="editor-header">
          <span class="editor-title" id="editor-view-title">Optimized Draft</span>
          <button class="btn btn-secondary" id="toggle-edit-btn" aria-label="Edit optimized prompt text" style="padding: 4px 10px; font-size: 11px;">Edit</button>
        </div>
        <div class="diff-view" id="diff-view"></div>
        <textarea class="optimized-textarea" id="optimized-text" style="display: none;"></textarea>
      </div>
      
      <div class="changes-header" id="changes-header">
        <span class="changes-title">Changes Explained</span>
        <span style="font-size: 12px; color: var(--pi-primary); font-weight: 700;" id="toggle-changes-label">Show Changes</span>
      </div>
      <ul class="changes-list" id="changes-list"></ul>
      
      <!-- Feedback Loop Panel -->
      <div class="feedback-section" id="feedback-section">
        <span class="feedback-title">Was this optimization useful?</span>
        <div class="feedback-buttons" id="feedback-buttons-wrapper">
          <button class="feedback-btn" id="feedback-yes">👍 Yes</button>
          <button class="feedback-btn" id="feedback-no">👎 No</button>
        </div>
        <div class="feedback-thanks" id="feedback-thanks">Thank you! Your feedback helps us improve.</div>
      </div>
      
      <div class="action-row">
        <button class="btn btn-secondary" id="copy-btn" aria-label="Copy optimized prompt">Copy</button>
        <button class="btn btn-ghost" id="retry-btn" aria-label="Retry optimization">Retry</button>
      </div>
      <button class="btn btn-primary" id="use-btn" aria-label="Use optimized prompt" style="width: 100%;">Use Prompt</button>
    </div>
  `,c.appendChild(f);let p=c.getElementById(`optimized-text`),m=c.getElementById(`diff-view`),h=c.getElementById(`toggle-edit-btn`),g=c.getElementById(`changes-list`),_=c.getElementById(`changes-header`),v=c.getElementById(`toggle-changes-label`),y=c.getElementById(`mode-select`),b=c.getElementById(`paywall-overlay`),x=c.getElementById(`optimize-btn`),S=c.getElementById(`loader-shimmer`),C=c.getElementById(`error-panel`),w=c.getElementById(`signin-card`),T=c.getElementById(`copy-btn`),E=c.getElementById(`retry-btn`),D=()=>{let e=f.classList.toggle(`visible`);i.classList.toggle(`panel-open`,e)};d.addEventListener(`click`,D),d.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),D())}),c.getElementById(`close-btn`).addEventListener(`click`,()=>{f.classList.remove(`visible`),i.classList.remove(`panel-open`)});let O=c.getElementById(`logout-sidebar-btn`);O.addEventListener(`click`,()=>{confirm(`Are you sure you want to log out of PromptIQ?`)&&r()}),c.getElementById(`signin-open-popup-btn`).addEventListener(`click`,l),c.getElementById(`error-open-popup-btn`).addEventListener(`click`,l),x.addEventListener(`click`,async()=>{S.style.display=`block`,C.style.display=`none`,c.getElementById(`result-section`).style.display=`none`,x.disabled=!0;try{await e()}catch(e){console.error(`onOptimize failed:`,e)}finally{S.style.display=`none`,a||(x.disabled=!1)}}),y.addEventListener(`change`,()=>{let e=y.value;e!==`turbo`&&s===`free`&&(y.value=`turbo`,A.showPaywall(`mode`,e))}),h.addEventListener(`click`,()=>{let e=c.getElementById(`editor-view-title`);p.style.display===`none`?(p.value=m.textContent,p.style.display=`block`,m.style.display=`none`,h.textContent=`View Diff`,e.textContent=`Edit Mode`):(m.style.display=`block`,p.style.display=`none`,h.textContent=`Edit`,e.textContent=`Optimized Draft`)}),_.addEventListener(`click`,()=>{g.classList.toggle(`expanded`),v.textContent=g.classList.contains(`expanded`)?`Hide`:`Show Changes`});function k(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}c.getElementById(`use-btn`).addEventListener(`click`,()=>{t(p.style.display===`none`?m.textContent:p.value),f.classList.remove(`visible`),i.classList.remove(`panel-open`)}),T.addEventListener(`click`,async()=>{let e=p.style.display===`none`?m.textContent:p.value;try{await navigator.clipboard.writeText(e),T.textContent=`Copied`}catch{T.textContent=`Copy failed`}setTimeout(()=>{T.textContent=`Copy`},1600)}),E.addEventListener(`click`,()=>{x.click()}),c.getElementById(`paywall-close-btn`).addEventListener(`click`,()=>{b.classList.remove(`active`)}),c.getElementById(`paywall-upgrade-btn`).addEventListener(`click`,()=>{l()}),c.getElementById(`feedback-yes`).addEventListener(`click`,async()=>{n&&o&&(await n(o,`helpful`),c.getElementById(`feedback-buttons-wrapper`).style.display=`none`,c.getElementById(`feedback-thanks`).style.display=`block`)}),c.getElementById(`feedback-no`).addEventListener(`click`,async()=>{n&&o&&(await n(o,`unhelpful`),c.getElementById(`feedback-buttons-wrapper`).style.display=`none`,c.getElementById(`feedback-thanks`).style.display=`block`)});let A={container:i,setLoggedState:e=>{O.style.display=e?`block`:`none`,w.classList.toggle(`visible`,!e)},toggleVisibility:()=>{let e=f.classList.toggle(`visible`);i.classList.toggle(`panel-open`,e)},getMode:()=>y.value,setTier:e=>{s=e;let t=c.getElementById(`header-pro-badge`);e===`pro`?(t.textContent=`PRO`,t.className=`status-badge status-pro`,y.options[1].text=`💎 Professional`,y.options[2].text=`📚 Research`,y.options[3].text=`🎨 Creative`,y.options[4].text=`💻 Coding`,y.options[5].text=`💼 Business`):(t.textContent=`FREE`,t.className=`status-badge status-free`,y.options[1].text=`🔒 Professional (Pro)`,y.options[2].text=`🔒 Research (Pro)`,y.options[3].text=`🔒 Creative (Pro)`,y.options[4].text=`🔒 Coding (Pro)`,y.options[5].text=`🔒 Business (Pro)`)},showPaywall:(e,t=null)=>{S.style.display=`none`,x.disabled=!1;let n=c.getElementById(`paywall-title`),r=c.getElementById(`paywall-desc`);e===`limit`?(n.textContent=`Daily Limit Reached`,r.textContent=`Unlock unlimited optimizations and advanced rewrite modes with PromptIQ Pro.`):e===`mode`&&(n.textContent=`Pro Mode Locked`,r.textContent=`The ${t?t.charAt(0).toUpperCase()+t.slice(1):y.options[y.selectedIndex].text.replace(`🔒 `,``).split(` (`)[0]} mode is locked. Unlock advanced rewrite modes and unlimited optimizations with PromptIQ Pro!`),b.classList.add(`active`)},updateScore:e=>{let t=c.getElementById(`score-dot`),n=c.getElementById(`score-text`),r=c.getElementById(`score-ring-bar`),i=c.getElementById(`score-ring-val`),a=c.getElementById(`score-grade`),o=Math.max(0,Math.min(100,e.score||0)),s=`Empty`;o>=76?s=`Strong`:o>=46?s=`Good`:o>0&&(s=`Weak`),i.textContent=o,a.textContent=s,n.textContent=`PromptIQ: ${o}`,r.setAttribute(`stroke-dasharray`,`${o}, 100`),t.className=`score-dot`,r.style.stroke=`var(--pi-muted)`,a.style.color=`var(--pi-text)`;let l=``,u=`var(--pi-muted)`;o>=76?(l=`score-excellent`,u=`var(--pi-success)`,a.style.color=`var(--pi-success)`):o>=46?(l=`score-good`,u=`var(--pi-warning)`,a.style.color=`var(--pi-warning)`):o>0&&(l=`score-weak`,u=`var(--pi-danger)`,a.style.color=`var(--pi-danger)`),l&&t.classList.add(l),r.style.stroke=u,c.querySelectorAll(`.chip`).forEach(t=>{let n=t.getAttribute(`data-dimension`);e.missing&&e.missing.includes(n)?(t.className=`chip chip-missing`,t.innerHTML=`<span class="chip-icon">✗</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`):(t.className=`chip chip-present`,t.innerHTML=`<span class="chip-icon">✓</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`)})},showResult:(e,t,n,r,i=null)=>{o=r,C.style.display=`none`,c.getElementById(`result-section`).style.display=`block`,x.textContent=`Optimize Prompt`,c.getElementById(`feedback-buttons-wrapper`).style.display=`flex`,c.getElementById(`feedback-thanks`).style.display=`none`,p.value=e;let a=c.getElementById(`score-delta`);if(i&&Number.isFinite(i.originalScore)&&Number.isFinite(i.newScore)){let e=i.newScore-i.originalScore;a.textContent=e>=0?`+${e} pts`:`${e} pts`}else a.textContent=`Improved`;m.innerHTML=t.map(e=>e.added?`<span class="diff-added">${k(e.text)}</span>`:k(e.text)).join(``),g.innerHTML=n.map(e=>`
        <li class="change-item">
          <span class="change-icon">${k(e.icon)}</span>
          <div class="change-content">
            <span class="change-label">${k(e.label)}:</span>
            <span>${k(e.description)}</span>
          </div>
        </li>
      `).join(``),g.classList.remove(`expanded`),v.textContent=`Show Changes`,m.style.display=`block`,p.style.display=`none`,h.textContent=`Edit`,c.getElementById(`editor-view-title`).textContent=`Optimized Draft`},showError:e=>{S.style.display=`none`,x.disabled=!1,c.getElementById(`result-section`).style.display=`none`;let t=c.getElementById(`error-panel-icon`),n=c.getElementById(`error-panel-title`),r=c.getElementById(`error-panel-message`);if(e.status===401||e.message.toLowerCase().includes(`log in`)||e.message.toLowerCase().includes(`session`)?(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=`Please log in again or try refreshing the page.`):(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=e.message||`Please log in again or try refreshing the page.`),C.style.display=`block`,e.status===429||e.message.includes(`429`)||e.message.includes(`quota`)){a=!0;let t=e.message.match(/retry in ([\d\.]+)s/i),n=t?Math.ceil(parseFloat(t[1])):60;x.disabled=!0,x.textContent=`Retry in ${n}s`;let r=setInterval(()=>{n--,n<=0?(clearInterval(r),a=!1,x.disabled=!1,x.textContent=`Optimize Prompt`):x.textContent=`Retry in ${n}s`},1e3)}}};return A}function u(e,t){let n=e.split(/(\s+)/),r=t.split(/(\s+)/),i=Array(n.length+1).fill(null).map(()=>Array(r.length+1).fill(0));for(let e=1;e<=n.length;e++)for(let t=1;t<=r.length;t++)n[e-1]===r[t-1]?i[e][t]=i[e-1][t-1]+1:i[e][t]=Math.max(i[e-1][t],i[e][t-1]);let a=[],o=n.length,s=r.length;for(;o>0||s>0;)o>0&&s>0&&n[o-1]===r[s-1]?(a.unshift({text:n[o-1],added:!1}),o--,s--):s>0&&(o===0||i[o][s-1]>=i[o-1][s])?(a.unshift({text:r[s-1],added:!0}),s--):o--;let c=[];for(let e of a)c.length>0&&c[c.length-1].added===e.added?c[c.length-1].text+=e.text:c.push({...e});return c}var d={role:{label:`Role / Persona`,icon:`👤`},task:{label:`Task Definition`,icon:`🎯`},context:{label:`Context / Background`,icon:`📖`},format:{label:`Output Format`,icon:`📊`},constraints:{label:`Constraints`,icon:`⛔`},specificity:{label:`Specificity`,icon:`🔍`},addition:{label:`Added Detail`,icon:`➕`},modification:{label:`Refined Phrasing`,icon:`✏️`},removal:{label:`Removed Clutter`,icon:`➖`}};function f(e){return Array.isArray(e)?e.map(e=>{let t=(e.type||``).toLowerCase(),n=d[t]||{label:`General Optimization`,icon:`⚡`};return{type:t,label:n.label,icon:n.icon,description:e.description||``}}):[]}var p={coding:/\b(code|function|class|bug|api|debug|regex|database|query|compile|github|git|javascript|js|python|html|css|java|c\+\+|rust|typescript|sql|programming|developer)\b/i,marketing:/\b(marketing|seo|copywriting|ad|email campaign|sales|social media|instagram|facebook|audience|target market|ctr|conversion|funnel|landing page|brand|copywriter)\b/i,creative:/\b(story|novel|poem|fiction|creative writing|character|plot|scifi|dialogue|metaphor|brainstorm|ideas|concept art|fable|script|narrative)\b/i,business:/\b(business|strategy|startup|investor|deck|marketing plan|swot|okr|kpi|pitch|revenue|profit|executive|report|slide|meeting|project management|consultant)\b/i,finance:/\b(finance|stock|investment|budget|valuation|crypto|bitcoin|portfolio|market trend|sheet|accounting|tax|audit|cfo|compound interest)\b/i,education:/\b(teach|learn|course|student|explain to|tutorial|curriculum|grade|lesson|exam|test prep|syllabus|homework|math|science|tutor|educator)\b/i,productivity:/\b(productivity|schedule|habit|workflow|automate|calendar|checklist|to-do|time management|efficiency|organize)\b/i,analysis:/\b(analyze|data|trend|graph|chart|statistics|correlation|outlier|hypothesis|excel|dataset|insight|compare|analyst)\b/i,writing:/\b(write|essay|article|blog post|summarize|paraphrase|grammar|tone|prose|revise|edit|proofread|letter|email|author)\b/i};function m(e){let t=e.toLowerCase();for(let[e,n]of Object.entries(p))if(n.test(t))return e;return`general`}function h(e){let t=e.toLowerCase(),n=t.trim().split(/\s+/).filter(Boolean).length,r=/\b(act as|you are|persona|role|specialist|expert|copywriter|developer|designer|analyst|tutor|writer)\b/i.test(t),i=/\b(audience|reader|user|student|customer|client|executive|demographic|viewer)\b/i.test(t),a=/\b(table|markdown|json|bullets|format|structure|list|html|paragraphs|headings|outline|schema)\b/i.test(t),o=/\b(don't|do not|max|limit|avoid|must|restrict|exclude|words|characters|no)\b/i.test(t),s=/\b(write|create|summarize|explain|code|analyze|generate|make|build|list|tweak|improve)\b/i.test(t),c=n>15;return{role:r,audience:i,format:a,constraints:o,objectives:s,context:c,missing:[!r&&`role`,!i&&`audience`,!a&&`format`,!o&&`constraints`,!s&&`objectives`,!c&&`context`].filter(Boolean)}}function g(e){if(!e||e.trim()===``)return{enhancedPrompt:``,intent:`general`,missing:[]};let t=m(e),n=h(e),r={coding:`expert software engineer`,marketing:`senior marketing copywriter and conversion strategist`,research:`rigorous academic researcher and analyst`,business:`expert business consultant and corporate strategist`,creative:`creative writer and narrative designer`,finance:`senior financial analyst`,education:`expert educator and academic tutor`,productivity:`workflow automation and productivity specialist`,analysis:`senior data analyst`,writing:`professional editor and copyeditor`,general:`highly capable expert assistant`},i={coding:`developers and technical review teams`,marketing:`the target consumer demographic`,research:`scholars and subject matter experts`,business:`executive leadership and key business stakeholders`,creative:`engaged general readers`,finance:`investors and corporate decision makers`,education:`students seeking intuitive comprehension`,productivity:`professionals seeking optimized workflows`,analysis:`data-driven managers`,writing:`readers looking for clear and compelling copy`,general:`general readers`},a={coding:`Clean markdown code blocks with line comments, input/output examples, and error handling notes.`,marketing:`High-impact copy structured with bold accents, short paragraphs, and direct bullet-point lists.`,research:`Detailed analysis organized with markdown headers, methodology descriptions, and references.`,business:`Executive summary format with key takeaways, bulleted metrics, and SWOT or ROI tables where applicable.`,creative:`Engaging narrative style with expressive descriptions and paragraph structures.`,education:`Step-by-step breakdown using clear explanations, definitions, and concept analogies.`,productivity:`Clean action checklist or process map with priority indicators.`,analysis:`Structured data summary with findings, key insights, and clear comparison tables.`,writing:`Polished prose matching the requested tone, formatted with appropriate line breaks.`,general:`Clear paragraphs, structured markdown lists, and headers.`},o={coding:`Ensure code runs efficiently, handles basic errors gracefully, and avoids using placeholder functions.`,marketing:`Avoid jargon. Stay highly persuasive, clear, and action-oriented.`,research:`Avoid bias. Base all assertions on logical reasoning and specify limits of analysis.`,business:`Stay objective, focus on KPI metrics, and highlight actionable next steps.`,creative:`Show, don't tell. Maximize sensory detail and ensure natural character voices.`,education:`Avoid overly complex language. Ensure definitions are clear and accessible.`,productivity:`Focus on simplicity and ease of execution. Keep it practical.`,analysis:`Exclude speculative insights not grounded in data. Be precise with comparisons.`,writing:`Avoid passive voice, reduce filler text, and check for tone consistency.`,general:`Avoid boilerplate introductory remarks. Be direct and clear.`},s=``,c=r[t]||r.general;s+=`[ROLE] Act as an ${c}.\n\n`,s+=`[OBJECTIVE] Optimize and fulfill the following task:\n"${e}"\n\n`;let l=i[t]||i.general;s+=`[AUDIENCE] Write specifically for ${l}.\n\n`;let u=a[t]||a.general;s+=`[FORMAT] ${u}\n\n`;let d=o[t]||o.general;return s+=`[CONSTRAINTS] ${d}\n\n`,n.context||(s+=`[CONTEXT] Provide complete, fully elaborated detail for this request. Do not summarize or output placeholders.`),{enhancedPrompt:s.trim(),intent:t,missing:n.missing}}var _=null,v=null,y=null,b=``,x=null;function S(){return typeof chrome>`u`||!chrome.runtime||!chrome.runtime.id?(C(),!1):!0}function C(){try{_&&_.removeEventListener(`input`,E),x&&x.disconnect(),window.removeEventListener(`keydown`,j);let e=document.getElementById(`promptiq-container`);e&&e.remove()}catch{}}function w(){try{typeof chrome<`u`&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,t)=>{if(t===`local`&&e.sessionToken){let t=e.sessionToken.newValue;v&&v.setLoggedState(!!t)}})}catch{}}async function T(){if(y=c(),!y)return;A();let t=await a();if(v){v.setLoggedState(!!t);try{let t=await e();v.setTier(t)}catch{}}let n=y.getInputElement();n&&D(n),O(),M(),N(),w()}function E(){if(!S()||!_||!v)return;let e=y.getText(_),t=n(e);t.missing=h(e).missing,v.updateScore(t)}function D(e){if(!e||!v)return;_&&_!==e&&_.removeEventListener(`input`,E),_=e,_.addEventListener(`input`,E);let t=y.getText(_),r=n(t);r.missing=h(t).missing,v.updateScore(r)}function O(){x=new MutationObserver(()=>{if(!S())return;let e=y.getInputElement();e&&e!==_&&D(e)}),x.observe(document.body,{childList:!0,subtree:!0})}async function k(){await r(),v&&(v.setLoggedState(!1),v.showError(Error(`Logged out. Please log in via the PromptIQ popup in your browser toolbar.`)))}function A(){document.getElementById(`promptiq-container`)||(v=l(P,F,I,k),document.body.appendChild(v.container))}function j(e){S()&&e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()===`p`&&(e.preventDefault(),v&&v.toggleVisibility())}function M(){window.addEventListener(`keydown`,j)}function N(){try{chrome.runtime.onMessage.addListener((e,t,r)=>{if(S()){if(e.action===`OPTIMIZE_SELECTION`)v&&(v.toggleVisibility(),_&&(y.setText(_,e.text),P()));else if(e.action===`INSERT_PROMPT`&&_){y.setText(_,e.text);let t=n(e.text);t.missing=h(e.text).missing,v.updateScore(t)}}})}catch{}}async function P(){if(!S())return;let s=(y.getText(_)||``).trim();if(!s){v.showError(Error(`Prompt is empty.`));return}let c=await a();if(!c){v&&v.setLoggedState(!1),v.showError(Error(`Please log in via the PromptIQ extension popup in your browser toolbar to optimize prompts.`));return}v&&v.setLoggedState(!0);let l=v.getMode()||`turbo`,d=await e();v&&v.setTier(d);let p=await o();if(d===`free`){if(!p.allowed){v.showPaywall(`limit`);return}if(l!==`turbo`){v.showPaywall(`mode`);return}}let m=g(s);try{let e=await chrome.runtime.sendMessage({action:`CALL_OPTIMIZER`,originalPrompt:s,platform:y.platform,locallyEnhancedPrompt:m.enhancedPrompt,detectedIntent:m.intent,mode:l,token:c});if(!e||!e.success){let t=e?.status,n=e?.error||`Failed to optimize prompt.`,r=Error(n);throw r.status=t,r}let r=e.result;b=r.optimized;let a=n(s).score,o=n(r.optimized).score,p=await t(s,r.optimized,o-a,y.platform,m.intent,l,a,o);d===`free`&&await i();let h=u(s,r.optimized),g=f(r.changes);v.showResult(r.optimized,h,g,p,{originalScore:a,newScore:o})}catch(e){if(e.status===403)v.showPaywall(`mode`);else if(e.status===429)v.showPaywall(`limit`);else if(e.status===401)await r(),v&&v.setLoggedState(!1),v.showError(Error(`Session expired. Please log in again via the PromptIQ popup.`));else if(e.message&&e.message.includes(`Extension context invalidated`)){let e=Error(`PromptIQ has been updated. Please refresh the page to continue.`);v.showError(e)}else v.showError(e)}}function F(e){if(!S())return;let t=e||b;if(t){y.setText(_,t);let e=n(t);e.missing=h(t).missing,v.updateScore(e)}}async function I(e,t){if(!S()||!e)return;let n=await a();if(n)try{await fetch(`https://promptiq-theta.vercel.app/api/feedback`,{method:`POST`,headers:{Authorization:`Bearer ${n}`,"Content-Type":`application/json`},body:JSON.stringify({id:e,feedback:t})})}catch(e){console.error(`Failed to submit feedback:`,e)}}T();