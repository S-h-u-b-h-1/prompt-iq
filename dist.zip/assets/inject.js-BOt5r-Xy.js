import{d as e,h as t,i as n,l as r,p as i,r as a}from"./storage-D1nTw1A2.js";import{i as o,n as s}from"./activity-DRLdMFtg.js";import{t as c}from"./scorer-mk_Yd85t.js";var l=[{id:`chatgpt`,matches:[`chatgpt.com`,`chat.openai.com`],selector:`#prompt-textarea, textarea[data-id="root"]`,isContentEditable:!1},{id:`claude`,matches:[`claude.ai`],selector:`div.ProseMirror[contenteditable="true"], div.ProseMirror`,isContentEditable:!0},{id:`gemini`,matches:[`gemini.google.com`],selector:`rich-textarea div[contenteditable="true"], .ql-editor[contenteditable="true"], rich-textarea textarea, .text-input-field`,isContentEditable:!0},{id:`perplexity`,matches:[`www.perplexity.ai`],selector:`textarea, [data-lexical-editor="true"][contenteditable="true"]`,isContentEditable:!1},{id:`copilot`,matches:[`copilot.microsoft.com`],selector:`#searchbox, textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1},{id:`deepseek`,matches:[`chat.deepseek.com`],selector:`#chat-input, textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1}];function u(){let e=window.location.hostname,t=l.find(t=>t.matches.some(t=>e.includes(t)));return t?{platform:t.id,getInputElement:()=>{let e=t.selector.split(`,`).map(e=>e.trim());for(let t of e){let e=document.querySelector(t);if(e)return e}return null},getText:e=>e?e.tagName===`TEXTAREA`||e.tagName===`INPUT`?e.value||``:e.innerText||``:``,setText:(e,t)=>{if(!e)return;e.focus();let n=e.tagName===`TEXTAREA`||e.tagName===`INPUT`;if(n)e.select();else{let t=document.createRange();t.selectNodeContents(e);let n=window.getSelection();n.removeAllRanges(),n.addRange(t)}let r=!1;try{r=document.execCommand(`insertText`,!1,t)}catch(e){console.error(`execCommand failed:`,e)}if(!r)if(!n)e.innerText=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}));else{let n=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}:null}function d(e,t,n,r,i,a){let o=document.createElement(`div`);o.id=`promptiq-container`,o.style.cssText=`position: fixed; bottom: 24px; right: 24px; z-index: 2147483000; font-family: Inter, system-ui, -apple-system, sans-serif;`;let s=!1,c=null,l=`free`,u=!1,d=!1,f=`general`,p=null,m=!1,h=null,g=o.attachShadow({mode:`open`}),_=async()=>{try{if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage){let e=await chrome.runtime.sendMessage({action:`OPEN_ONBOARDING`});if(!e?.success)throw Error(e?.error||`Account page could not be opened.`);return}}catch{window.alert(`PromptIQ was updated. Refresh this page, then try opening the account again.`);return}window.alert(`Open the PromptIQ extension from your browser toolbar.`)},v={chatgpt:`ChatGPT`,claude:`Claude`,gemini:`Gemini`,perplexity:`Perplexity`,copilot:`Copilot`,deepseek:`DeepSeek`,general:`AI assistant`},y=document.createElement(`style`);y.textContent=`
    :host {
      color-scheme: dark;
      --pi-bg: #101414;
      --pi-card: #101414;
      --pi-elevated: #171e1b;
      --pi-border: rgba(159, 255, 200, .08);
      --pi-text: #f1f7f3;
      --pi-muted: #a8b8af;
      --pi-primary: #9fffc8;
      --pi-primary-strong: #9fffc8;
      --pi-success: #9fffc8;
      --pi-warning: #9fffc8;
      --pi-danger: #9fffc8;
      --pi-pro: #9fffc8;
      --pi-glow: rgba(159, 255, 200, 0.08);
      --pi-shadow: rgba(159, 255, 200, 0.06);
      --pi-radius: 8px;
    }


    .badge {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 9px 16px;
      border-radius: 9999px;
      background: var(--pi-elevated);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 25px -5px var(--pi-shadow);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .badge:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 30px -5px var(--pi-shadow);
      border-color: var(--pi-primary);
    }
    :host(.panel-open) .badge {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8) translateY(10px);
    }
    .score-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--pi-muted);
      transition: background 0.3s, box-shadow 0.3s;
    }
    .score-excellent { background: var(--pi-success); box-shadow: none; }
    .score-good { background: var(--pi-warning); box-shadow: none; }
    .score-fair { background: #9fffc8; box-shadow: none; }
    .score-weak { background: var(--pi-danger); box-shadow: none; }
    
    .panel-wrapper {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 24px;
      right: 24px;
      bottom: 24px;
      width: 382px;
      max-width: calc(100vw - 48px);
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: var(--pi-radius);
      box-shadow: 0 28px 60px -18px var(--pi-shadow), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 18px;
      color: var(--pi-text);
      box-sizing: border-box;
      z-index: 1000000;
      backdrop-filter: blur(24px) saturate(120%);
      -webkit-backdrop-filter: blur(24px) saturate(120%);
      overflow: hidden;
      
      transform: translateX(calc(100% + 48px));
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 0;
      pointer-events: none;
    }
    .panel-wrapper.visible {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    .panel-wrapper.has-result .signin-card,
    .panel-wrapper.has-result .score-area,
    .panel-wrapper.has-result .chips-container {
      display: none;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      border-bottom: 1px solid var(--pi-border);
      padding-bottom: 12px;
    }
    .header-logo-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title { 
      font-weight: 800; 
      font-size: 17px; 
      color: var(--pi-text); 
      letter-spacing: 0;
    }
    .status-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 2.5px 8px;
      border-radius: 6px;
      letter-spacing: 0;
    }
    .status-free {
      background: rgba(159, 255, 200, 0.1);
      color: var(--pi-muted);
    }
    .status-premium {
      background: rgba(159, 255, 200, 0.14);
      color: var(--pi-pro);
      border: 1px solid rgba(159, 255, 200, 0.2);
    }
    .signin-card {
      display: none;
      background: rgba(159, 255, 200, 0.08);
      border: 1px solid rgba(159, 255, 200, 0.2);
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 14px;
      color: var(--pi-text);
    }
    .signin-card.visible {
      display: block;
    }
    .signin-title {
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .signin-copy {
      font-size: 11.5px;
      line-height: 1.45;
      color: var(--pi-muted);
      margin-bottom: 10px;
    }
    
    .mode-selector-wrapper {
      margin-bottom: 18px;
    }
    .mode-selector-wrapper label {
      display: block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: var(--pi-muted);
      letter-spacing: 0;
    }
    .settings-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .select-control {
      width: 100%;
      min-height: 38px;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font: inherit;
      font-size: 12px;
      font-weight: 700;
      box-sizing: border-box;
    }
    .platform-pill {
      min-height: 38px;
      display: flex;
      align-items: center;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
      box-sizing: border-box;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .engine-summary {
      padding: 8px 0 0;
      background: var(--pi-card);
    }
    .engine-name {
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
    }
    .engine-copy {
      margin-top: 3px;
      color: var(--pi-muted);
      font-size: 11px;
      line-height: 1.4;
    }

    /* Visual Score Progress Area */
    .score-area {
      background: var(--pi-card);
      border-block: 1px solid var(--pi-border);
      padding: 16px 0;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .score-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      flex-shrink: 0;
    }
    .score-ring {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    .score-ring-bg {
      fill: none;
      stroke: var(--pi-border);
      stroke-width: 4;
    }
    .score-ring-progress {
      fill: none;
      stroke: var(--pi-muted);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.5s ease;
    }
    .score-ring-val {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 15px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .score-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .score-grade {
      font-size: 16px;
      font-weight: 800;
      color: var(--pi-text);
    }

    /* Dimension Chips */
    .chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    .chip-present {
      background: rgba(159, 255, 200, 0.06);
      color: var(--pi-success);
      border-color: rgba(159, 255, 200, 0.12);
    }
    .chip-missing {
      background: rgba(159, 255, 200, 0.05);
      color: var(--pi-muted);
      border-color: var(--pi-border);
      opacity: 1;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 8px;
      border: 1px solid transparent;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
      font-family: inherit;
    }
    .btn:focus-visible,
    .feedback-btn:focus-visible,
    .badge:focus-visible,
    select:focus-visible,
    textarea:focus-visible {
      outline: 2px solid var(--pi-primary);
      outline-offset: 2px;
    }
    .btn-primary {
      background: var(--pi-primary);
      color: #101414;
      box-shadow: 0 4px 12px var(--pi-glow);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px var(--pi-glow);
    }
    .btn-primary:disabled {
      opacity: 0.5;
      transform: none;
      cursor: not-allowed;
    }
    .btn-secondary {
      background: var(--pi-card);
      color: var(--pi-text);
      border-color: var(--pi-border);
    }
    .btn-secondary:hover {
      background: var(--pi-border);
    }
    .btn-ghost {
      background: transparent;
      color: var(--pi-muted);
      border-color: var(--pi-border);
    }
    
    .result-section {
      display: none;
      margin-top: 18px;
      padding-top: 18px;
      border-top: 1px solid var(--pi-border);
      overflow-y: auto;
      flex: 1;
    }
    .success-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      margin-bottom: 12px;
      border-radius: 8px;
      border: 1px solid rgba(159, 255, 200, 0.18);
      background: rgba(159, 255, 200, 0.07);
    }
    .success-summary.pulse {
      animation: successPulse 650ms ease-out;
    }
    @keyframes successPulse {
      0% { transform: scale(0.985); border-color: rgba(159, 255, 200, 0.1); }
      100% { transform: scale(1); border-color: rgba(159, 255, 200, 0.18); }
    }
    .success-title {
      font-size: 13px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .success-copy {
      font-size: 11.5px;
      color: var(--pi-muted);
      margin-top: 2px;
    }
    .score-delta {
      font-size: 12px;
      font-weight: 800;
      color: var(--pi-success);
      white-space: nowrap;
    }
    
    /* Mock Editor Window */
    .editor-card {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.03);
    }
    .editor-header {
      background: rgba(159, 255, 200, 0.03);
      padding: 10px 16px;
      border-bottom: 1px solid var(--pi-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .editor-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }

    .optimized-textarea {
      width: 100%;
      height: 150px;
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      resize: vertical;
      font-family: inherit;
      color: var(--pi-text);
      box-sizing: border-box;
      max-height: 240px;
    }
    .optimized-textarea:focus {
      outline: none;
    }

    .diff-view {
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      max-height: 150px;
      overflow-y: auto;
      margin: 0;
      white-space: pre-wrap;
      color: var(--pi-text);
      box-sizing: border-box;
    }
    .diff-added {
      background: rgba(159, 255, 200, 0.15);
      color: var(--pi-success);
      font-weight: 600;
      padding: 2px 4px;
      border-radius: 4px;
    }
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    .comparison-grid[hidden] {
      display: none;
    }
    .compare-box {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      min-width: 0;
    }
    .compare-title {
      padding: 8px 10px;
      border-bottom: 1px solid var(--pi-border);
      color: var(--pi-muted);
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .compare-text {
      margin: 0;
      padding: 10px;
      min-height: 96px;
      max-height: 150px;
      overflow-y: auto;
      white-space: pre-wrap;
      color: var(--pi-text);
      font: inherit;
      font-size: 11.5px;
      line-height: 1.45;
    }

    .changes-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
    }
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .changes-title {
      font-weight: 700;
      font-size: 13px;
      color: var(--pi-text);
    }
    
    .changes-list {
      font-size: 12px;
      list-style: none;
      padding: 0;
      margin: 0 0 18px 0;
      max-height: 150px;
      overflow-y: auto;
      display: none;
    }
    .changes-list.expanded {
      display: block;
    }
    .change-item {
      display: flex;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid var(--pi-border);
    }
    .change-icon {
      font-size: 14px;
      flex-shrink: 0;
    }
    .change-content {
      line-height: 1.45;
    }
    .change-label {
      font-weight: 700;
      color: var(--pi-text);
    }
    
    /* Loading Shimmer State */
    .loader-shimmer {
      display: none;
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      padding: 20px;
      position: relative;
      overflow: hidden;
      margin-top: 18px;
    }
    .shimmer-line {
      height: 11px;
      background: var(--pi-border);
      margin-bottom: 12px;
      border-radius: 4px;
      position: relative;
      overflow: hidden;
    }
    .shimmer-line::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.5s infinite;
    }

    .shimmer-t { width: 35%; height: 13px; }
    .shimmer-l1 { width: 85%; }
    .shimmer-l2 { width: 95%; }
    .shimmer-l3 { width: 70%; }
    .shimmer-label {
      display: block;
      text-align: center;
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-muted);
      margin-top: 8px;
      letter-spacing: 0;
    }
    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }
    
    /* Paywall Overlay */
    .paywall-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(159, 255, 200, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
      z-index: 1000010;
      padding: 20px;
      box-sizing: border-box;
    }
    .paywall-overlay.active {
      opacity: 1;
      pointer-events: auto;
    }
    .paywall-card {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      padding: 28px;
      text-align: center;
      max-width: 320px;
      box-shadow: 0 20px 40px -10px rgba(159, 255, 200, 0.4);
      box-sizing: border-box;
    }
    .paywall-icon {
      font-size: 36px;
      margin-bottom: 12px;
    }
    .paywall-title {
      font-weight: 800;
      font-size: 18px;
      margin-bottom: 8px;
      color: var(--pi-text);
      letter-spacing: 0;
    }
    .paywall-desc {
      font-size: 12.5px;
      color: var(--pi-muted);
      margin-bottom: 20px;
      line-height: 1.5;
    }
    
    /* Feedback Section */
    .feedback-section {
      background: var(--pi-card);
      border-top: 1px solid var(--pi-border);
      padding: 14px;
      text-align: center;
      margin-top: 14px;
      margin-bottom: 14px;
    }
    .feedback-title {
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-text);
      display: block;
      margin-bottom: 10px;
    }
    .feedback-buttons {
      display: flex;
      gap: 10px;
      justify-content: center;
    }
    .feedback-btn {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 12.5px;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .feedback-btn:hover {
      background: var(--pi-border);
      transform: translateY(-1px);
    }
    .feedback-thanks {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--pi-success);
      display: none;
      margin-top: 4px;
    }

    /* Error and Authentication states */
    .error-panel {
      display: none;
      background: rgba(159, 255, 200, 0.04);
      border: 1px solid rgba(159, 255, 200, 0.18);
      border-radius: 8px;
      padding: 18px;
      text-align: left;
      margin-top: 18px;
    }
    .error-icon {
      font-size: 28px;
      margin-bottom: 10px;
    }
    .error-title {
      font-weight: 800;
      font-size: 15px;
      color: var(--pi-danger);
      margin-bottom: 6px;
    }
    .error-message {
      font-size: 12px;
      color: var(--pi-text);
      line-height: 1.5;
      margin-bottom: 14px;
    }
    *, *::before, *::after { letter-spacing: 0; }
    .panel-wrapper > * { flex-shrink: 0; }
    .panel-wrapper > .result-section { flex-shrink: 1; min-height: 0; }
    .panel-wrapper { overflow-y: auto; }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { animation: none !important; transition: none !important; }
    }
    @media (max-width: 520px) {
      .panel-wrapper {
        top: auto;
        left: 12px;
        right: 12px;
        bottom: 12px;
        width: auto;
        max-width: none;
        max-height: calc(100vh - 24px);
        padding: 16px;
      }
      .action-row {
        grid-template-columns: 1fr;
      }
      .settings-grid {
        grid-template-columns: 1fr 1fr;
        gap: 6px;
      }
      .platform-pill {
        grid-column: 1 / -1;
        min-height: 20px;
        padding: 0;
        border: 0;
        font-size: 10px;
      }
      .comparison-grid {
        grid-template-columns: 1fr;
      }
    }
  `,g.appendChild(y);let b=document.createElement(`div`);b.className=`badge`,b.tabIndex=0,b.setAttribute(`role`,`button`),b.setAttribute(`aria-label`,`Open PromptIQ optimizer`),b.innerHTML=`<div class="score-dot" id="score-dot"></div><span id="score-text">PromptIQ: 0</span>`,g.appendChild(b);let x=document.createElement(`div`);x.className=`panel-wrapper`,x.innerHTML=`
    <div class="header">
      <div class="header-logo-group">
        <svg width="24" height="24" viewBox="0 0 128 128" aria-hidden="true" style="flex-shrink:0"><rect width="128" height="128" rx="26" fill="#9fffc8"/><path fill="#101414" d="M31 31h42l24 25v18L73 98H53l-22 13V31zm17 17v34l17-10h5l12-12-12-12H48z" fill-rule="evenodd"/></svg>
        <div class="title">PromptIQ</div>
        <div class="status-badge status-free" id="header-pro-badge">FREE</div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary" id="logout-sidebar-btn" aria-label="Log out of PromptIQ" style="padding: 4px 8px; font-size: 10px; background: rgba(159, 255, 200, 0.08); color: var(--pi-danger); border-color: rgba(159, 255, 200, 0.12); display: none;">Log Out</button>
        <button class="btn btn-secondary" id="close-btn" aria-label="Close PromptIQ optimizer" style="padding: 6px 12px; font-size: 11px;">Close</button>
      </div>
    </div>
    
    <div class="mode-selector-wrapper">
      <label>Mode, engine, and platform</label>
      <div class="settings-grid">
        <select class="select-control" id="mode-select" aria-label="Optimization mode">
          <option value="standard">Standard</option>
          <option value="concise">Concise</option>
          <option value="detailed">Detailed</option>
          <option value="creative">Creative</option>
          <option value="technical">Technical</option>
        </select>
        <select class="select-control" id="engine-select" aria-label="Optimization engine">
          <option value="smart_template">Local</option>
          <option value="premium_ai">Premium AI</option>
        </select>
        <div class="platform-pill" id="platform-pill">AI assistant</div>
      </div>
      <div class="engine-summary">
        <div class="engine-name" id="engine-name">Smart Template</div>
        <div class="engine-copy" id="engine-copy">Create an account to score, save, and optimize prompts.</div>
      </div>
    </div>

    <div class="signin-card" id="signin-card">
      <div class="signin-title" id="signin-title">Account required</div>
      <div class="signin-copy" id="signin-copy">Create an account or sign in before PromptIQ reads and stores prompt drafts.</div>
      <button class="btn btn-secondary" id="signin-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%; padding: 8px 10px; font-size: 12px;">Continue to Account</button>
    </div>

    <!-- Visual Score Circle & Info -->
    <div class="score-area">
      <div class="score-ring-container">
        <svg class="score-ring" viewBox="0 0 36 36">
          <path class="score-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="score-ring-progress" id="score-ring-bar" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="score-ring-val" id="score-ring-val">0</div>
      </div>
      <div class="score-info">
        <div class="score-label">Draft Quality</div>
        <div class="score-grade" id="score-grade">Empty</div>
      </div>
    </div>

    <!-- Dimension Chips -->
    <div class="chips-container" id="chips-container">
      <div class="chip chip-missing" data-dimension="task"><span class="chip-icon">✗</span> Task</div>
      <div class="chip chip-missing" data-dimension="context"><span class="chip-icon">✗</span> Context</div>
      <div class="chip chip-missing" data-dimension="role"><span class="chip-icon">✗</span> Role</div>
      <div class="chip chip-missing" data-dimension="format"><span class="chip-icon">✗</span> Format</div>
      <div class="chip chip-missing" data-dimension="constraints"><span class="chip-icon">✗</span> Constraints</div>
      <div class="chip chip-missing" data-dimension="specificity"><span class="chip-icon">✗</span> Specificity</div>
    </div>
    
    <button class="btn btn-primary" id="optimize-btn" aria-label="Optimize prompt" style="width: 100%;">Optimize Prompt</button>
    
    <!-- Shimmer Loader State -->
    <div class="loader-shimmer" id="loader-shimmer">
      <div class="shimmer-line shimmer-t"></div>
      <div class="shimmer-line shimmer-l1"></div>
      <div class="shimmer-line shimmer-l2"></div>
      <div class="shimmer-line shimmer-l3"></div>
      <span class="shimmer-label">Optimizing your prompt...</span>
    </div>

    <!-- Error/Auth card panel -->
    <div class="error-panel" id="error-panel">
      <div class="error-icon" id="error-panel-icon">!</div>
      <div class="error-title" id="error-panel-title">Optimization Failed</div>
      <div class="error-message" id="error-panel-message">Please try refreshing the page.</div>
      <button class="btn btn-secondary" id="error-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%;">Open Account</button>
    </div>
    
    <!-- Paywall Overlay -->
    <div class="paywall-overlay" id="paywall-overlay">
      <div class="paywall-card">
        <div class="paywall-icon" id="paywall-icon">AI</div>
        <div class="paywall-title" id="paywall-title">Unlock PromptIQ Premium</div>
        <div class="paywall-desc" id="paywall-desc">Use server-side AI optimization while keeping API keys out of the extension.</div>
        <button class="btn btn-primary" id="paywall-upgrade-btn" aria-label="Open PromptIQ popup to upgrade" style="width: 100%;">Open Upgrade Options</button>
        <button class="btn btn-secondary" id="paywall-close-btn" aria-label="Close upgrade message" style="width: 100%; margin-top: 8px;">Back</button>
      </div>
    </div>
    
    <!-- Result Editor Area -->
    <div class="result-section" id="result-section">
      <div class="success-summary">
        <div>
          <div class="success-title">Prompt is ready</div>
          <div class="success-copy">Review it, copy it, or send it back to the chat box.</div>
        </div>
        <div class="score-delta" id="score-delta">Improved</div>
      </div>
      <div class="editor-card">
        <div class="editor-header">
          <span class="editor-title" id="editor-view-title">Optimized Draft</span>
          <button class="btn btn-secondary" id="toggle-edit-btn" aria-label="Edit optimized prompt text" style="padding: 4px 10px; font-size: 11px;">Edit</button>
        </div>
        <div class="diff-view" id="diff-view"></div>
        <textarea class="optimized-textarea" id="optimized-text" style="display: none;"></textarea>
      </div>

      <div class="comparison-grid" id="comparison-grid" hidden>
        <div class="compare-box">
          <div class="compare-title">Original</div>
          <pre class="compare-text" id="compare-original"></pre>
        </div>
        <div class="compare-box">
          <div class="compare-title">Optimized</div>
          <pre class="compare-text" id="compare-optimized"></pre>
        </div>
      </div>
      
      <div class="changes-header" id="changes-header">
        <span class="changes-title">Changes Explained</span>
        <span style="font-size: 12px; color: var(--pi-primary); font-weight: 700;" id="toggle-changes-label">Show Changes</span>
      </div>
      <ul class="changes-list" id="changes-list"></ul>
      
      <!-- Feedback Loop Panel -->
      <div class="feedback-section" id="feedback-section">
        <span class="feedback-title">Was this optimization useful?</span>
        <div class="feedback-buttons" id="feedback-buttons-wrapper">
          <button class="feedback-btn" id="feedback-yes">Yes</button>
          <button class="feedback-btn" id="feedback-no">No</button>
        </div>
        <div class="feedback-thanks" id="feedback-thanks">Thank you! Your feedback helps us improve.</div>
      </div>
      
      <div class="action-row">
        <button class="btn btn-secondary" id="copy-btn" aria-label="Copy optimized prompt">Copy</button>
        <button class="btn btn-secondary" id="favorite-btn" aria-label="Save optimized prompt as favorite">Favorite</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="compare-btn" aria-label="Compare original and optimized prompt">Compare</button>
        <button class="btn btn-ghost" id="undo-btn" aria-label="Undo the last inserted optimization">Undo</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="retry-btn" aria-label="Retry optimization">Retry</button>
        <button class="btn btn-ghost" id="copy-original-btn" aria-label="Copy original prompt">Copy Original</button>
      </div>
      <button class="btn btn-primary" id="use-btn" aria-label="Use optimized prompt" style="width: 100%;">Use Prompt</button>
    </div>
  `,g.appendChild(x);let S=g.getElementById(`optimized-text`),C=g.getElementById(`diff-view`),w=g.getElementById(`toggle-edit-btn`),T=g.getElementById(`changes-list`),E=g.getElementById(`changes-header`),D=g.getElementById(`toggle-changes-label`),O=g.getElementById(`paywall-overlay`),k=g.getElementById(`optimize-btn`),A=g.getElementById(`loader-shimmer`),j=g.getElementById(`error-panel`),M=g.getElementById(`signin-card`),N=g.getElementById(`copy-btn`),P=g.getElementById(`copy-original-btn`),F=g.getElementById(`retry-btn`),I=g.getElementById(`mode-select`),L=g.getElementById(`engine-select`),R=g.getElementById(`platform-pill`),z=g.getElementById(`favorite-btn`),B=g.getElementById(`compare-btn`),V=g.getElementById(`undo-btn`),H=g.getElementById(`comparison-grid`),U=g.getElementById(`compare-original`),W=g.getElementById(`compare-optimized`);try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get([`optimizationMode`,`optimizationEngine`],e=>{e.optimizationMode&&I.querySelector(`option[value="${e.optimizationMode}"]`)&&(I.value=e.optimizationMode),e.optimizationEngine&&L.querySelector(`option[value="${e.optimizationEngine}"]`)&&(m=!0,h=e.optimizationEngine,L.value=e.optimizationEngine),G()})}catch{}function G(){let e=g.getElementById(`engine-name`),t=g.getElementById(`engine-copy`),n=L.value;if(!u||!d){L.value=`smart_template`,e.textContent=`Account required`,t.textContent=u?`Review prompt storage and finish account setup to continue.`:`Create an account to score, save, and optimize prompts.`;return}let r=n===`premium_ai`?`premium_ai`:`smart_template`;r!==n&&(L.value=r),r===`premium_ai`?(e.textContent=`Premium AI`,t.textContent=l===`premium`?`Uses secure server-side AI. Premium includes 50 optimizations per day.`:`Free account trial: 5 secure server-side AI optimizations per day.`):(e.textContent=`Smart Template`,t.textContent=l===`premium`?`Runs locally. Premium includes 200 Smart Template optimizations per day.`:`Runs locally. Free includes 100 Smart Template optimizations per day.`)}function K(){let e=u&&d;I.disabled=!e,L.disabled=!e,k.disabled=!e||s,M.classList.toggle(`visible`,!e);let t=g.getElementById(`signin-title`),n=g.getElementById(`signin-copy`),r=g.getElementById(`score-text`);u?d?(r.textContent.includes(`Sign in`)||r.textContent.includes(`Finish setup`))&&(r.textContent=`PromptIQ: 0`):(t.textContent=`Finish privacy setup`,n.textContent=`Prompt storage must be enabled before PromptIQ can access the chat composer.`,r.textContent=`PromptIQ: Finish setup`):(t.textContent=`Account required`,n.textContent=`Create an account or sign in before PromptIQ reads and stores prompt drafts.`,r.textContent=`PromptIQ: Sign in`),e?l===`premium`&&!m?L.value=`premium_ai`:h&&L.querySelector(`option[value="${h}"]`)&&(L.value=h):L.value=`smart_template`,G()}let q=()=>{let e=x.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)};b.addEventListener(`click`,q),b.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),q())}),g.getElementById(`close-btn`).addEventListener(`click`,()=>{x.classList.remove(`visible`),o.classList.remove(`panel-open`)});let J=g.getElementById(`logout-sidebar-btn`);J.addEventListener(`click`,()=>{confirm(`Are you sure you want to log out of PromptIQ?`)&&r()}),g.getElementById(`signin-open-popup-btn`).addEventListener(`click`,_),g.getElementById(`error-open-popup-btn`).addEventListener(`click`,_),I.addEventListener(`change`,()=>{try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({optimizationMode:I.value})}catch{}}),L.addEventListener(`change`,()=>{m=!0,h=L.value;try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({optimizationEngine:L.value})}catch{}G()}),k.addEventListener(`click`,async()=>{if(!u||!d){_();return}x.classList.remove(`has-result`),A.style.display=`block`,j.style.display=`none`,g.getElementById(`result-section`).style.display=`none`,k.disabled=!0;try{await e()}catch(e){console.error(`onOptimize failed:`,e)}finally{A.style.display=`none`,!s&&u&&d&&(k.disabled=!1)}}),w.addEventListener(`click`,()=>{let e=g.getElementById(`editor-view-title`);S.style.display===`none`?(S.value=C.textContent,S.style.display=`block`,C.style.display=`none`,w.textContent=`View Diff`,e.textContent=`Edit Mode`):(C.style.display=`block`,S.style.display=`none`,w.textContent=`Edit`,e.textContent=`Optimized Draft`)}),E.addEventListener(`click`,()=>{T.classList.toggle(`expanded`),D.textContent=T.classList.contains(`expanded`)?`Hide`:`Show Changes`});function Y(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}return g.getElementById(`use-btn`).addEventListener(`click`,()=>{t(S.style.display===`none`?C.textContent:S.value),x.classList.remove(`visible`),o.classList.remove(`panel-open`)}),N.addEventListener(`click`,async()=>{let e=S.style.display===`none`?C.textContent:S.value;try{await navigator.clipboard.writeText(e),N.textContent=`Copied`}catch{N.textContent=`Copy failed`}setTimeout(()=>{N.textContent=`Copy`},1600)}),P.addEventListener(`click`,async()=>{let e=p?.original||``;try{await navigator.clipboard.writeText(e),P.textContent=`Copied`}catch{P.textContent=`Copy failed`}setTimeout(()=>{P.textContent=`Copy Original`},1600)}),B.addEventListener(`click`,()=>{H.hidden=!H.hidden,B.textContent=H.hidden?`Compare`:`Hide Compare`}),V.addEventListener(`click`,()=>{V.textContent=typeof i==`function`&&i()?`Undone`:`Nothing to undo`,setTimeout(()=>{V.textContent=`Undo`},1600)}),z.addEventListener(`click`,async()=>{if(!p||typeof a!=`function`)return;let e=S.style.display===`none`?C.textContent:S.value;z.disabled=!0;try{z.textContent=await a({...p,optimized:e,mode:I.value})?`Favorited`:`Favorite`}catch{z.textContent=`Favorite failed`}finally{setTimeout(()=>{z.disabled=!1,z.textContent===`Favorite failed`&&(z.textContent=`Favorite`)},1400)}}),F.addEventListener(`click`,()=>{k.click()}),g.getElementById(`paywall-close-btn`).addEventListener(`click`,()=>{O.classList.remove(`active`)}),g.getElementById(`paywall-upgrade-btn`).addEventListener(`click`,()=>{_()}),g.getElementById(`feedback-yes`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`helpful`),g.getElementById(`feedback-buttons-wrapper`).style.display=`none`,g.getElementById(`feedback-thanks`).style.display=`block`)}),g.getElementById(`feedback-no`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`unhelpful`),g.getElementById(`feedback-buttons-wrapper`).style.display=`none`,g.getElementById(`feedback-thanks`).style.display=`block`)}),{container:o,setLoggedState:e=>{u=!!e,J.style.display=u?`block`:`none`,K()},setStorageReady:e=>{d=!!e,K()},showAccountRequired:(e=`signin`)=>{x.classList.add(`visible`),o.classList.add(`panel-open`),K()},getSettings:()=>({mode:I.value||`standard`,engine:L.value||`smart_template`,platform:f||`general`}),setPlatform:e=>{f=e||`general`,R.textContent=v[f]||v.general},toggleVisibility:()=>{let e=x.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)},setTier:e=>{l=e===`premium`||e===`pro`?`premium`:`free`;let t=g.getElementById(`header-pro-badge`);l===`premium`?(t.textContent=`PREMIUM`,t.className=`status-badge status-premium`):(t.textContent=`FREE`,t.className=`status-badge status-free`),K()},showPaywall:(e,t=null)=>{A.style.display=`none`,k.disabled=!u||!d;let n=g.getElementById(`paywall-title`),r=g.getElementById(`paywall-desc`);n.textContent=`Unlock PromptIQ Premium`,r.textContent=`Premium uses PromptIQ server-side AI for deeper, context-aware optimization.`,O.classList.add(`active`)},updateScore:e=>{let t=g.getElementById(`score-dot`),n=g.getElementById(`score-text`),r=g.getElementById(`score-ring-bar`),i=g.getElementById(`score-ring-val`),a=g.getElementById(`score-grade`),o=Math.max(0,Math.min(100,e.score||0)),s=`Empty`;o>=76?s=`Strong`:o>=46?s=`Good`:o>0&&(s=`Weak`),i.textContent=o,a.textContent=s,n.textContent=`PromptIQ: ${o}`,r.setAttribute(`stroke-dasharray`,`${o}, 100`),t.className=`score-dot`,r.style.stroke=`var(--pi-muted)`,a.style.color=`var(--pi-text)`;let c=``,l=`var(--pi-muted)`;o>=76?(c=`score-excellent`,l=`var(--pi-success)`,a.style.color=`var(--pi-success)`):o>=46?(c=`score-good`,l=`var(--pi-warning)`,a.style.color=`var(--pi-warning)`):o>0&&(c=`score-weak`,l=`var(--pi-danger)`,a.style.color=`var(--pi-danger)`),c&&t.classList.add(c),r.style.stroke=l,g.querySelectorAll(`.chip`).forEach(t=>{let n=t.getAttribute(`data-dimension`);e.missing&&e.missing.includes(n)?(t.className=`chip chip-missing`,t.innerHTML=`<span class="chip-icon">✗</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`):(t.className=`chip chip-present`,t.innerHTML=`<span class="chip-icon">✓</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`)})},showResult:(e,t,n,r,i=null,a={})=>{c=r,x.classList.add(`has-result`),j.style.display=`none`,g.getElementById(`result-section`).style.display=`block`,k.textContent=`Optimize Prompt`,H.hidden=!0,B.textContent=`Compare`,g.getElementById(`feedback-buttons-wrapper`).style.display=`flex`,g.getElementById(`feedback-thanks`).style.display=`none`,z.textContent=`Favorite`,S.value=e;let o=g.getElementById(`score-delta`);if(i&&Number.isFinite(i.originalScore)&&Number.isFinite(i.newScore)){let e=i.newScore-i.originalScore;o.textContent=e>=0?`+${e} pts`:`${e} pts`}else o.textContent=`Improved`;p={original:a.originalPrompt||``,optimized:e,platform:a.platform||f||`general`,intent:a.intent||null,mode:a.mode||I.value||`standard`,scoreOriginal:i?.originalScore??null,scoreOptimized:i?.newScore??null,timestamp:Date.now()},U.textContent=p.original,W.textContent=e,C.innerHTML=t.map(e=>e.added?`<span class="diff-added">${Y(e.text)}</span>`:Y(e.text)).join(``),T.innerHTML=n.map(e=>`
        <li class="change-item">
          <span class="change-icon" aria-hidden="true">+</span>
          <div class="change-content">
            <span class="change-label">${Y(e.label)}:</span>
            <span>${Y(e.description)}</span>
          </div>
        </li>
      `).join(``),T.classList.remove(`expanded`),D.textContent=`Show Changes`,C.style.display=`block`,S.style.display=`none`,w.textContent=`Edit`,g.getElementById(`editor-view-title`).textContent=`Optimized Draft`;let s=g.querySelector(`.success-summary`);s.classList.remove(`pulse`),s.offsetWidth,s.classList.add(`pulse`)},showError:e=>{x.classList.remove(`has-result`),A.style.display=`none`,k.disabled=!u||!d,g.getElementById(`result-section`).style.display=`none`;let t=g.getElementById(`error-panel-icon`),n=g.getElementById(`error-panel-title`),r=g.getElementById(`error-panel-message`);if(e.status===401||e.message.toLowerCase().includes(`log in`)||e.message.toLowerCase().includes(`session`)?(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=`Please log in again or try refreshing the page.`):(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=e.message||`Please log in again or try refreshing the page.`),j.style.display=`block`,!(e.code===`LOCAL_DAILY_LIMIT_REACHED`||e.code===`PREMIUM_DAILY_LIMIT_REACHED`)&&(e.status===429||e.message.includes(`429`)||e.message.includes(`quota`))){s=!0;let t=e.message.match(/retry in ([\d\.]+)s/i),n=t?Math.ceil(parseFloat(t[1])):60;k.disabled=!0,k.textContent=`Retry in ${n}s`;let r=setInterval(()=>{n--,n<=0?(clearInterval(r),s=!1,k.disabled=!1,k.textContent=`Optimize Prompt`):k.textContent=`Retry in ${n}s`},1e3)}}}}function f(e,t=2e3){let n,r,i=0;return{reset(){clearTimeout(n),r=null,i=0},schedule(a,o,s){if(clearTimeout(n),!a.trim()){r=null,i=0;return}if(a.length>6e3)return;r||=crypto.randomUUID();let c={kind:`draft`,clientId:r,text:a,platform:o,mode:s,revision:++i};n=setTimeout(()=>{Promise.resolve(e(c)).catch(()=>{})},t)}}}function p(e,t){let n=e.split(/(\s+)/),r=t.split(/(\s+)/),i=Array(n.length+1).fill(null).map(()=>Array(r.length+1).fill(0));for(let e=1;e<=n.length;e++)for(let t=1;t<=r.length;t++)n[e-1]===r[t-1]?i[e][t]=i[e-1][t-1]+1:i[e][t]=Math.max(i[e-1][t],i[e][t-1]);let a=[],o=n.length,s=r.length;for(;o>0||s>0;)o>0&&s>0&&n[o-1]===r[s-1]?(a.unshift({text:n[o-1],added:!1}),o--,s--):s>0&&(o===0||i[o][s-1]>=i[o-1][s])?(a.unshift({text:r[s-1],added:!0}),s--):o--;let c=[];for(let e of a)c.length>0&&c[c.length-1].added===e.added?c[c.length-1].text+=e.text:c.push({...e});return c}var m={role:{label:`Role / Persona`,icon:`👤`},task:{label:`Task Definition`,icon:`🎯`},context:{label:`Context / Background`,icon:`📖`},format:{label:`Output Format`,icon:`📊`},constraints:{label:`Constraints`,icon:`⛔`},specificity:{label:`Specificity`,icon:`🔍`},addition:{label:`Added Detail`,icon:`➕`},modification:{label:`Refined Phrasing`,icon:`✏️`},removal:{label:`Removed Clutter`,icon:`➖`}};function h(e){return Array.isArray(e)?e.map(e=>{let t=(e.type||``).toLowerCase(),n=m[t]||{label:`General Optimization`,icon:`⚡`};return{type:t,label:n.label,icon:n.icon,description:e.description||``}}):[]}var g={coding:/\b(code|function|class|bug|api|debug|regex|database|query|compile|github|git|javascript|js|python|html|css|java|c\+\+|rust|typescript|sql|programming|developer)\b/i,marketing:/\b(marketing|seo|copywriting|ad|email campaign|sales|social media|instagram|facebook|audience|target market|ctr|conversion|funnel|landing page|brand|copywriter)\b/i,creative:/\b(story|novel|poem|fiction|creative writing|character|plot|scifi|dialogue|metaphor|brainstorm|ideas|concept art|fable|script|narrative)\b/i,business:/\b(business|strategy|startup|investor|deck|marketing plan|swot|okr|kpi|pitch|revenue|profit|executive|report|slide|meeting|project management|consultant)\b/i,finance:/\b(finance|stock|investment|budget|valuation|crypto|bitcoin|portfolio|market trend|sheet|accounting|tax|audit|cfo|compound interest)\b/i,education:/\b(teach|learn|course|student|explain to|tutorial|curriculum|grade|lesson|exam|test prep|syllabus|homework|math|science|tutor|educator)\b/i,productivity:/\b(productivity|schedule|habit|workflow|automate|calendar|checklist|to-do|time management|efficiency|organize)\b/i,analysis:/\b(analyze|data|trend|graph|chart|statistics|correlation|outlier|hypothesis|excel|dataset|insight|compare|analyst)\b/i,writing:/\b(write|essay|article|blog post|summarize|paraphrase|grammar|tone|prose|revise|edit|proofread|letter|email|author)\b/i},_={standard:{label:`Standard`,instruction:`Balance clarity, completeness, and practical structure without making the prompt unnecessarily long.`},concise:{label:`Concise`,instruction:`Make the prompt compact and direct while preserving the full task, constraints, and success criteria.`},detailed:{label:`Detailed`,instruction:`Expand context, acceptance criteria, examples, and evaluation rules so the AI has enough detail to produce a high-quality answer.`},creative:{label:`Creative`,instruction:`Encourage distinctive angles, variations, tone options, and ideation while keeping the request usable and bounded.`},technical:{label:`Technical`,instruction:`Emphasize precision, edge cases, implementation constraints, validation steps, and measurable acceptance criteria.`}},v={chatgpt:{label:`ChatGPT`,instruction:`Use clear role, task, context, output format, and constraints sections. Prefer markdown headings and explicit success criteria.`},claude:{label:`Claude`,instruction:`Use natural language instructions with context first, then desired output, constraints, and examples when useful.`},gemini:{label:`Gemini`,instruction:`Use explicit task steps, source/context boundaries, and a clear final-answer format.`},perplexity:{label:`Perplexity`,instruction:`Ask for source-aware analysis, concise synthesis, and separation between facts, assumptions, and recommendations.`},copilot:{label:`Copilot`,instruction:`Specify the environment, expected implementation, error cases, and verification steps.`},deepseek:{label:`DeepSeek`,instruction:`Use precise technical context, constraints, and a validation checklist for the final answer.`},general:{label:`AI assistant`,instruction:`Use a broadly compatible prompt structure with clear task, context, output format, and constraints.`}};function y(e){return _[e]?e:`standard`}function b(e){return v[e]?e:`general`}function x(e){let t=e.toLowerCase();for(let[e,n]of Object.entries(g))if(n.test(t))return e;return`general`}function S(e){let t=e.toLowerCase(),n=t.trim().split(/\s+/).filter(Boolean).length,r=/\b(act as|you are|persona|role|specialist|expert|copywriter|developer|designer|analyst|tutor|writer)\b/i.test(t),i=/\b(audience|reader|user|student|customer|client|executive|demographic|viewer)\b/i.test(t),a=/\b(table|markdown|json|bullets|format|structure|list|html|paragraphs|headings|outline|schema)\b/i.test(t),o=/\b(don't|do not|max|limit|avoid|must|restrict|exclude|words|characters|no)\b/i.test(t),s=/\b(write|create|summarize|explain|code|analyze|generate|make|build|list|tweak|improve)\b/i.test(t),c=n>15;return{role:r,audience:i,format:a,constraints:o,objectives:s,context:c,missing:[!r&&`role`,!i&&`audience`,!a&&`format`,!o&&`constraints`,!s&&`objectives`,!c&&`context`].filter(Boolean)}}function C(e,t={}){if(!e||e.trim()===``)return{enhancedPrompt:``,intent:`general`,missing:[],mode:`standard`,platform:`general`};let n=x(e),r=S(e),i=y(t.mode),a=b(t.platform),o=_[i],s=v[a],c={coding:`expert software engineer`,marketing:`senior marketing copywriter and conversion strategist`,research:`rigorous academic researcher and analyst`,business:`expert business consultant and corporate strategist`,creative:`creative writer and narrative designer`,finance:`senior financial analyst`,education:`expert educator and academic tutor`,productivity:`workflow automation and productivity specialist`,analysis:`senior data analyst`,writing:`professional editor and copyeditor`,general:`highly capable expert assistant`},l={coding:`Clean markdown code blocks with line comments, input/output examples, and error handling notes.`,marketing:`High-impact copy structured with bold accents, short paragraphs, and direct bullet-point lists.`,research:`Detailed analysis organized with markdown headers, methodology descriptions, and references.`,business:`Executive summary format with key takeaways, bulleted metrics, and SWOT or ROI tables where applicable.`,creative:`Engaging narrative style with expressive descriptions and paragraph structures.`,education:`Step-by-step breakdown using clear explanations, definitions, and concept analogies.`,productivity:`Clean action checklist or process map with priority indicators.`,analysis:`Structured data summary with findings, key insights, and clear comparison tables.`,writing:`Polished prose matching the requested tone, formatted with appropriate line breaks.`,general:`Clear paragraphs, structured markdown lists, and headers.`},u={coding:`Ensure code runs efficiently, handles basic errors gracefully, and avoids using placeholder functions.`,marketing:`Avoid jargon. Stay highly persuasive, clear, and action-oriented.`,research:`Avoid bias. Base all assertions on logical reasoning and specify limits of analysis.`,business:`Stay objective, focus on KPI metrics, and highlight actionable next steps.`,creative:`Show, don't tell. Maximize sensory detail and ensure natural character voices.`,education:`Avoid overly complex language. Ensure definitions are clear and accessible.`,productivity:`Focus on simplicity and ease of execution. Keep it practical.`,analysis:`Exclude speculative insights not grounded in data. Be precise with comparisons.`,writing:`Avoid passive voice, reduce filler text, and check for tone consistency.`,general:`Avoid boilerplate introductory remarks. Be direct and clear.`},d=``,f=c[n]||c.general;d+=`[ROLE]\nWork as the following specialist: ${f}.\n\n`,d+=`[TASK]\nComplete the following request:\n${e.trim()}\n\n`,d+=`[AUDIENCE AND CONTEXT]
Use the audience and context stated in the request. When either is missing, make the smallest reasonable assumption and label it clearly.

`,d+=`[MODE]\n${o.label}: ${o.instruction}\n\n`,d+=`[PLATFORM CALIBRATION]\nOptimize this prompt for ${s.label}. ${s.instruction}\n\n`;let p=l[n]||l.general;d+=`[OUTPUT FORMAT]\n${p}\n\n`;let m=u[n]||u.general;return d+=`[CONSTRAINTS]\n${m}\n\n`,d+=`[QUALITY CHECK]
Address the request directly, preserve the user's intent, make the result actionable, reason internally without exposing hidden chain-of-thought, and do not return placeholders or instructions that bypass an AI service's safety controls.`,{enhancedPrompt:d.trim(),intent:n,missing:r.missing,mode:i,platform:a}}var w=null,T=null,E=null,D=``,O=``,k=null,A=!1,j=f(o);async function M(e){let t=e===void 0?await r():e,n=!1;if(t)try{n=(await s(!0)).saveDrafts===!0}catch{n=!1}A=!!(t&&n),j.reset(),T?.setLoggedState(!!t),T?.setStorageReady(n),A&&w&&L()}function N(){return typeof chrome>`u`||!chrome.runtime||!chrome.runtime.id?(P(),!1):!0}function P(){j.reset();try{w&&w.removeEventListener(`input`,L),k&&k.disconnect(),window.removeEventListener(`keydown`,H);let e=document.getElementById(`promptiq-container`);e&&e.remove()}catch{}}function F(){try{typeof chrome<`u`&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,t)=>{if(!(t!==`local`||!T)){if(e.sessionToken){j.reset();let t=e.sessionToken.newValue;M(t)}e.promptIqCapturePreferencesVersion&&M(),e.userTier&&T.setTier(e.userTier.newValue||`free`)}})}catch{}}async function I(){if(E=u(),!E)return;if(V(),T&&T.setPlatform(E.platform),await M(await r()),T)try{let t=await e();T.setTier(t)}catch{}let t=E.getInputElement();t&&R(t),z(),U(),W(),F()}function L(){if(!N()||!w||!T||!A)return;let e=E.getText(w);typeof e==`string`&&j.schedule(e,E.platform,T.getSettings().mode);let t=c(e);t.missing=S(e).missing,T.updateScore(t)}function R(e){!e||!T||(w&&w!==e&&(j.reset(),w.removeEventListener(`input`,L)),w=e,w.addEventListener(`input`,L),A&&L())}function z(){k=new MutationObserver(()=>{if(!N())return;let e=E.getInputElement();e&&e!==w&&R(e)}),k.observe(document.body,{childList:!0,subtree:!0})}async function B(){await a(),A=!1,j.reset(),T&&(T.setLoggedState(!1),T.setStorageReady(!1),T.setTier(`free`),T.showError(Error(`Signed out. Create an account or sign in to use PromptIQ.`)))}function V(){document.getElementById(`promptiq-container`)||(T=d(G,q,X,B,J,Y),document.body.appendChild(T.container))}function H(e){N()&&e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()===`p`&&(e.preventDefault(),T&&T.toggleVisibility())}function U(){window.addEventListener(`keydown`,H)}function W(){try{chrome.runtime.onMessage.addListener((e,t,n)=>{if(N()){if(e.action===`OPTIMIZE_SELECTION`)T&&(T.toggleVisibility(),w&&(E.setText(w,e.text),G()));else if(e.action===`INSERT_PROMPT`&&w){E.setText(w,e.text);let t=c(e.text);t.missing=S(e.text).missing,T.updateScore(t)}}})}catch{}}async function G(){if(!N())return;let t=await r();if(!t||!A){T.showAccountRequired(t?`consent`:`signin`);return}let o=(E.getText(w)||``).trim();if(!o){T.showError(Error(`Prompt is empty.`));return}let s=await e(),l=T.getSettings?T.getSettings():{mode:`standard`,platform:E.platform},u=l.mode||`standard`,d=l.engine||`smart_template`;T&&(T.setLoggedState(!0),T.setStorageReady(!0),T.setTier(s));let f=C(o,{mode:u,platform:E.platform}),m,g=s;try{let e=!!t&&d===`premium_ai`;if(e){let e=await chrome.runtime.sendMessage({action:`CALL_OPTIMIZER`,originalPrompt:o,platform:E.platform,locallyEnhancedPrompt:f.enhancedPrompt,detectedIntent:f.intent,mode:u,token:t});if(!e||!e.success){let t=Error(e?.error||`Failed to optimize prompt.`);throw t.status=e?.status,t.code=e?.code,t}m=e.result}else await n(s),m=K(f);D=m.optimized;let r=c(o).score,a=c(m.optimized).score,l=await i(o,m.optimized,a-r,E.platform,f.intent,u,r,a,e?`premium_ai`:`smart_template`),_=p(o,m.optimized),v=h(m.changes);T.showResult(m.optimized,_,v,l,{originalScore:r,newScore:a},{originalPrompt:o,platform:E.platform,intent:f.intent,mode:u,engine:e?`premium_ai`:`smart_template`,tier:g})}catch(e){if(e.code===`PREMIUM_LIMIT_REACHED`||e.code===`PREMIUM_DAILY_LIMIT_REACHED`||e.code===`LOCAL_DAILY_LIMIT_REACHED`)T&&T.showError(e);else if(e.status===401||e.status===403)await a(),A=!1,j.reset(),T&&(T.setLoggedState(!1),T.setStorageReady(!1),T.setTier(`free`)),T.showError(Error(`Your account session expired. Sign in again to continue.`));else if(e.message&&e.message.includes(`Extension context invalidated`)){let e=Error(`PromptIQ has been updated. Please refresh the page to continue.`);T.showError(e)}else T&&T.showError(e)}}function K(e){let t={role:`Added an expert role to guide tone and decision quality.`,task:`Clarified the objective and preserved the original request.`,context:`Added context guidance so the response is complete and useful.`,format:`Specified a structured output format for easier use.`,constraints:`Added practical boundaries to reduce vague or generic output.`,specificity:`Expanded the request with audience and delivery details.`};return{optimized:e.enhancedPrompt,changes:[`role`,`task`,`context`,`format`,`constraints`,`specificity`].map(e=>({type:e,description:t[e]}))}}function q(e){if(!N())return;let t=e||D;if(t){O=E.getText(w)||``,E.setText(w,t);let e=c(t);e.missing=S(t).missing,T.updateScore(e)}}function J(){if(!N()||!O||!w)return!1;E.setText(w,O);let e=c(O);return e.missing=S(O).missing,T.updateScore(e),O=``,!0}async function Y(e){return N()?(await t(e)).favorite:!1}async function X(e,t){if(!N()||!e)return;let n=await r();if(n)try{await fetch(`https://promptiq-theta.vercel.app/api/feedback`,{method:`POST`,headers:{Authorization:`Bearer ${n}`,"Content-Type":`application/json`},body:JSON.stringify({id:e,feedback:t})})}catch(e){console.error(`Failed to submit feedback:`,e)}}I();