import './assets/service-worker.js-DTgcAvrC.js';
