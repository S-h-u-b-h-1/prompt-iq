import{c as e,f as t,r as n,s as r,u as i}from"./storage-fmw_tm1s.js";import{t as a}from"./scorer-mk_Yd85t.js";var o=[{id:`chatgpt`,matches:[`chatgpt.com`,`chat.openai.com`],selector:`#prompt-textarea`,isContentEditable:!1},{id:`claude`,matches:[`claude.ai`],selector:`div.ProseMirror`,isContentEditable:!0},{id:`gemini`,matches:[`gemini.google.com`],selector:`rich-textarea p, .ql-editor p, rich-textarea, .text-input-field`,isContentEditable:!0},{id:`perplexity`,matches:[`www.perplexity.ai`],selector:`textarea`,isContentEditable:!1},{id:`copilot`,matches:[`copilot.microsoft.com`],selector:`#searchbox, textarea`,isContentEditable:!1},{id:`deepseek`,matches:[`chat.deepseek.com`],selector:`#chat-input, textarea`,isContentEditable:!1}];function s(){let e=window.location.hostname,t=o.find(t=>t.matches.some(t=>e.includes(t)));return t?{platform:t.id,getInputElement:()=>{let e=t.selector.split(`,`).map(e=>e.trim());for(let t of e){let e=document.querySelector(t);if(e)return e}return null},getText:e=>e?e.tagName===`TEXTAREA`||e.tagName===`INPUT`?e.value||``:e.innerText||``:``,setText:(e,t)=>{if(!e)return;e.focus();let n=e.tagName===`TEXTAREA`||e.tagName===`INPUT`;if(n)e.select();else{let t=document.createRange();t.selectNodeContents(e);let n=window.getSelection();n.removeAllRanges(),n.addRange(t)}let r=!1;try{r=document.execCommand(`insertText`,!1,t)}catch(e){console.error(`execCommand failed:`,e)}if(!r)if(!n)e.innerText=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}));else{let n=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}:null}function c(e,t,n,r,i,a){let o=document.createElement(`div`);o.id=`promptiq-container`,o.style.cssText=`position: fixed; bottom: 24px; right: 24px; z-index: 999999; font-family: "Plus Jakarta Sans", system-ui, -apple-system, sans-serif;`;let s=!1,c=null,l=`free`,u=!1,d=`general`,f=null;(document.documentElement.classList.contains(`dark`)||document.body.classList.contains(`dark`)||document.documentElement.getAttribute(`data-theme`)===`dark`||window.matchMedia(`(prefers-color-scheme: dark)`).matches)&&o.classList.add(`dark-mode`);let p=o.attachShadow({mode:`open`}),m=()=>{try{if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage){chrome.runtime.sendMessage({action:`OPEN_ONBOARDING`});return}}catch{}window.alert(`Open the PromptIQ extension from your browser toolbar.`)},h={chatgpt:`ChatGPT`,claude:`Claude`,gemini:`Gemini`,perplexity:`Perplexity`,copilot:`Copilot`,deepseek:`DeepSeek`,general:`AI assistant`},g=document.createElement(`style`);g.textContent=`
    :host {
      --pi-bg: #ffffff;
      --pi-card: #f8fafc;
      --pi-elevated: rgba(255, 255, 255, 0.88);
      --pi-border: #dbe3ee;
      --pi-text: #0f172a;
      --pi-muted: #64748b;
      --pi-primary: #2563eb;
      --pi-primary-strong: #1d4ed8;
      --pi-success: #10b981;
      --pi-warning: #f59e0b;
      --pi-danger: #ef4444;
      --pi-pro: #7c3aed;
      --pi-glow: rgba(37, 99, 235, 0.08);
      --pi-shadow: rgba(0, 0, 0, 0.06);
      --pi-radius: 18px;
    }
    :host(.dark-mode) {
      --pi-bg: rgba(9, 14, 26, 0.94);
      --pi-card: rgba(18, 27, 44, 0.82);
      --pi-elevated: rgba(15, 23, 42, 0.94);
      --pi-border: rgba(148, 163, 184, 0.18);
      --pi-text: #f8fafc;
      --pi-muted: #94a3b8;
      --pi-primary: #38bdf8;
      --pi-primary-strong: #0ea5e9;
      --pi-success: #34d399;
      --pi-warning: #fbbf24;
      --pi-danger: #f87171;
      --pi-pro: #a78bfa;
      --pi-glow: rgba(56, 189, 248, 0.18);
      --pi-shadow: rgba(0, 0, 0, 0.35);
    }

    .badge {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 9px 16px;
      border-radius: 9999px;
      background: var(--pi-elevated);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 25px -5px var(--pi-shadow);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .badge:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 30px -5px var(--pi-shadow);
      border-color: var(--pi-primary);
    }
    :host(.panel-open) .badge {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8) translateY(10px);
    }
    .score-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--pi-muted);
      transition: background 0.3s, box-shadow 0.3s;
    }
    .score-excellent { background: var(--pi-success); box-shadow: 0 0 10px var(--pi-success); }
    .score-good { background: var(--pi-warning); box-shadow: 0 0 10px var(--pi-warning); }
    .score-fair { background: #f97316; box-shadow: 0 0 10px #f97316; }
    .score-weak { background: var(--pi-danger); box-shadow: 0 0 10px var(--pi-danger); }
    
    .panel-wrapper {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 24px;
      right: 24px;
      bottom: 24px;
      width: 382px;
      max-width: calc(100vw - 48px);
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: var(--pi-radius);
      box-shadow: 0 28px 60px -18px var(--pi-shadow), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 18px;
      color: var(--pi-text);
      box-sizing: border-box;
      z-index: 1000000;
      backdrop-filter: blur(24px) saturate(120%);
      -webkit-backdrop-filter: blur(24px) saturate(120%);
      overflow: hidden;
      
      transform: translateX(calc(100% + 48px));
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 0;
      pointer-events: none;
    }
    .panel-wrapper.visible {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      border-bottom: 1px solid var(--pi-border);
      padding-bottom: 12px;
    }
    .header-logo-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title { 
      font-weight: 800; 
      font-size: 17px; 
      color: var(--pi-text); 
      letter-spacing: 0;
    }
    .status-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 2.5px 8px;
      border-radius: 6px;
      letter-spacing: 0.05em;
    }
    .status-free {
      background: rgba(100, 116, 139, 0.1);
      color: var(--pi-muted);
    }
    .status-premium {
      background: rgba(124, 58, 237, 0.14);
      color: var(--pi-pro);
      border: 1px solid rgba(139, 92, 246, 0.2);
    }
    .signin-card {
      display: none;
      background: rgba(245, 158, 11, 0.08);
      border: 1px solid rgba(245, 158, 11, 0.2);
      border-radius: 14px;
      padding: 12px;
      margin-bottom: 14px;
      color: var(--pi-text);
    }
    .signin-card.visible {
      display: block;
    }
    .signin-title {
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .signin-copy {
      font-size: 11.5px;
      line-height: 1.45;
      color: var(--pi-muted);
      margin-bottom: 10px;
    }
    
    .mode-selector-wrapper {
      margin-bottom: 18px;
    }
    .mode-selector-wrapper label {
      display: block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: var(--pi-muted);
      letter-spacing: 0.05em;
    }
    .settings-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .select-control {
      width: 100%;
      min-height: 38px;
      padding: 0 10px;
      border-radius: 10px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font: inherit;
      font-size: 12px;
      font-weight: 700;
      box-sizing: border-box;
    }
    .platform-pill {
      min-height: 38px;
      display: flex;
      align-items: center;
      padding: 0 10px;
      border-radius: 10px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
      box-sizing: border-box;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .engine-summary {
      padding: 10px 12px;
      border-radius: 12px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
    }
    .engine-name {
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
    }
    .engine-copy {
      margin-top: 3px;
      color: var(--pi-muted);
      font-size: 11px;
      line-height: 1.4;
    }

    /* Visual Score Progress Area */
    .score-area {
      background: linear-gradient(180deg, var(--pi-card), transparent);
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      padding: 16px;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .score-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      flex-shrink: 0;
    }
    .score-ring {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    .score-ring-bg {
      fill: none;
      stroke: var(--pi-border);
      stroke-width: 4;
    }
    .score-ring-progress {
      fill: none;
      stroke: var(--pi-muted);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.5s ease;
    }
    .score-ring-val {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 15px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .score-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .score-grade {
      font-size: 16px;
      font-weight: 800;
      color: var(--pi-text);
    }

    /* Dimension Chips */
    .chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    .chip-present {
      background: rgba(16, 185, 129, 0.06);
      color: var(--pi-success);
      border-color: rgba(16, 185, 129, 0.12);
    }
    .chip-missing {
      background: rgba(100, 116, 139, 0.05);
      color: var(--pi-muted);
      border-color: var(--pi-border);
      opacity: 0.65;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 12px;
      border: 1px solid transparent;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
      font-family: inherit;
    }
    .btn:focus-visible,
    .feedback-btn:focus-visible,
    .badge:focus-visible,
    select:focus-visible,
    textarea:focus-visible {
      outline: 2px solid var(--pi-primary);
      outline-offset: 2px;
    }
    .btn-primary {
      background: linear-gradient(135deg, var(--pi-primary), var(--pi-primary-strong));
      color: #ffffff;
      box-shadow: 0 4px 12px var(--pi-glow);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px var(--pi-glow);
    }
    .btn-primary:disabled {
      opacity: 0.5;
      transform: none;
      cursor: not-allowed;
    }
    .btn-secondary {
      background: var(--pi-card);
      color: var(--pi-text);
      border-color: var(--pi-border);
    }
    .btn-secondary:hover {
      background: var(--pi-border);
    }
    .btn-ghost {
      background: transparent;
      color: var(--pi-muted);
      border-color: var(--pi-border);
    }
    
    .result-section {
      display: none;
      margin-top: 18px;
      padding-top: 18px;
      border-top: 1px solid var(--pi-border);
      overflow-y: auto;
      flex: 1;
    }
    .success-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      margin-bottom: 12px;
      border-radius: 14px;
      border: 1px solid rgba(16, 185, 129, 0.18);
      background: rgba(16, 185, 129, 0.07);
    }
    .success-summary.pulse {
      animation: successPulse 650ms ease-out;
    }
    @keyframes successPulse {
      0% { transform: scale(0.985); border-color: rgba(16, 185, 129, 0.1); }
      100% { transform: scale(1); border-color: rgba(16, 185, 129, 0.18); }
    }
    .success-title {
      font-size: 13px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .success-copy {
      font-size: 11.5px;
      color: var(--pi-muted);
      margin-top: 2px;
    }
    .score-delta {
      font-size: 12px;
      font-weight: 800;
      color: var(--pi-success);
      white-space: nowrap;
    }
    
    /* Mock Editor Window */
    .editor-card {
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      background: var(--pi-card);
      overflow: hidden;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.03);
    }
    .editor-header {
      background: rgba(15, 23, 42, 0.03);
      padding: 10px 16px;
      border-bottom: 1px solid var(--pi-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .editor-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .optimized-textarea {
      width: 100%;
      height: 150px;
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      resize: vertical;
      font-family: inherit;
      color: var(--pi-text);
      box-sizing: border-box;
      max-height: 240px;
    }
    .optimized-textarea:focus {
      outline: none;
    }

    .diff-view {
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      max-height: 150px;
      overflow-y: auto;
      margin: 0;
      white-space: pre-wrap;
      color: var(--pi-text);
      box-sizing: border-box;
    }
    .diff-added {
      background: rgba(16, 185, 129, 0.15);
      color: var(--pi-success);
      font-weight: 600;
      padding: 2px 4px;
      border-radius: 4px;
    }
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    .comparison-grid[hidden] {
      display: none;
    }
    .compare-box {
      border: 1px solid var(--pi-border);
      border-radius: 12px;
      background: var(--pi-card);
      overflow: hidden;
      min-width: 0;
    }
    .compare-title {
      padding: 8px 10px;
      border-bottom: 1px solid var(--pi-border);
      color: var(--pi-muted);
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .compare-text {
      margin: 0;
      padding: 10px;
      min-height: 96px;
      max-height: 150px;
      overflow-y: auto;
      white-space: pre-wrap;
      color: var(--pi-text);
      font: inherit;
      font-size: 11.5px;
      line-height: 1.45;
    }

    .changes-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
    }
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .changes-title {
      font-weight: 700;
      font-size: 13px;
      color: var(--pi-text);
    }
    
    .changes-list {
      font-size: 12px;
      list-style: none;
      padding: 0;
      margin: 0 0 18px 0;
      max-height: 150px;
      overflow-y: auto;
      display: none;
    }
    .changes-list.expanded {
      display: block;
    }
    .change-item {
      display: flex;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid var(--pi-border);
    }
    .change-icon {
      font-size: 14px;
      flex-shrink: 0;
    }
    .change-content {
      line-height: 1.45;
    }
    .change-label {
      font-weight: 700;
      color: var(--pi-text);
    }
    
    /* Loading Shimmer State */
    .loader-shimmer {
      display: none;
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 16px;
      padding: 20px;
      position: relative;
      overflow: hidden;
      margin-top: 18px;
    }
    .shimmer-line {
      height: 11px;
      background: var(--pi-border);
      margin-bottom: 12px;
      border-radius: 4px;
      position: relative;
      overflow: hidden;
    }
    .shimmer-line::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.5s infinite;
    }
    :host(.dark-mode) .shimmer-line::after {
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.05), transparent);
    }
    .shimmer-t { width: 35%; height: 13px; }
    .shimmer-l1 { width: 85%; }
    .shimmer-l2 { width: 95%; }
    .shimmer-l3 { width: 70%; }
    .shimmer-label {
      display: block;
      text-align: center;
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-muted);
      margin-top: 8px;
      letter-spacing: 0.02em;
    }
    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }
    
    /* Paywall Overlay */
    .paywall-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(15, 23, 42, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
      z-index: 1000010;
      padding: 20px;
      box-sizing: border-box;
    }
    .paywall-overlay.active {
      opacity: 1;
      pointer-events: auto;
    }
    .paywall-card {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: 20px;
      padding: 28px;
      text-align: center;
      max-width: 320px;
      box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.4);
      box-sizing: border-box;
    }
    .paywall-icon {
      font-size: 36px;
      margin-bottom: 12px;
    }
    .paywall-title {
      font-weight: 800;
      font-size: 18px;
      margin-bottom: 8px;
      color: var(--pi-text);
      letter-spacing: 0;
    }
    .paywall-desc {
      font-size: 12.5px;
      color: var(--pi-muted);
      margin-bottom: 20px;
      line-height: 1.5;
    }
    
    /* Feedback Section */
    .feedback-section {
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 12px;
      padding: 14px;
      text-align: center;
      margin-top: 14px;
      margin-bottom: 14px;
    }
    .feedback-title {
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-text);
      display: block;
      margin-bottom: 10px;
    }
    .feedback-buttons {
      display: flex;
      gap: 10px;
      justify-content: center;
    }
    .feedback-btn {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 12.5px;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .feedback-btn:hover {
      background: var(--pi-border);
      transform: translateY(-1px);
    }
    .feedback-thanks {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--pi-success);
      display: none;
      margin-top: 4px;
    }

    /* Error and Authentication states */
    .error-panel {
      display: none;
      background: linear-gradient(180deg, rgba(239, 68, 68, 0.08), rgba(239, 68, 68, 0.03));
      border: 1px solid rgba(239, 68, 68, 0.18);
      border-radius: 16px;
      padding: 18px;
      text-align: left;
      margin-top: 18px;
    }
    .error-icon {
      font-size: 28px;
      margin-bottom: 10px;
    }
    .error-title {
      font-weight: 800;
      font-size: 15px;
      color: var(--pi-danger);
      margin-bottom: 6px;
    }
    .error-message {
      font-size: 12px;
      color: var(--pi-text);
      line-height: 1.5;
      margin-bottom: 14px;
    }
    @media (max-width: 520px) {
      .panel-wrapper {
        top: auto;
        left: 12px;
        right: 12px;
        bottom: 12px;
        width: auto;
        max-width: none;
        max-height: calc(100vh - 24px);
        padding: 16px;
      }
      .action-row {
        grid-template-columns: 1fr;
      }
      .settings-grid,
      .comparison-grid {
        grid-template-columns: 1fr;
      }
    }
  `,p.appendChild(g);let _=document.createElement(`div`);_.className=`badge`,_.tabIndex=0,_.setAttribute(`role`,`button`),_.setAttribute(`aria-label`,`Open PromptIQ optimizer`),_.innerHTML=`<div class="score-dot" id="score-dot"></div><span id="score-text">PromptIQ: 0</span>`,p.appendChild(_);let v=document.createElement(`div`);v.className=`panel-wrapper`,v.innerHTML=`
    <div class="header">
      <div class="header-logo-group">
        <div class="title">PromptIQ Optimizer</div>
        <div class="status-badge status-free" id="header-pro-badge">FREE</div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary" id="logout-sidebar-btn" aria-label="Log out of PromptIQ" style="padding: 4px 8px; font-size: 10px; background: rgba(239, 68, 68, 0.08); color: var(--pi-danger); border-color: rgba(239, 68, 68, 0.12); display: none;">Log Out</button>
        <button class="btn btn-secondary" id="close-btn" aria-label="Close PromptIQ optimizer" style="padding: 6px 12px; font-size: 11px;">Close</button>
      </div>
    </div>
    
    <div class="mode-selector-wrapper">
      <label>Mode and Platform</label>
      <div class="settings-grid">
        <select class="select-control" id="mode-select" aria-label="Optimization mode">
          <option value="standard">Standard</option>
          <option value="concise">Concise</option>
          <option value="detailed">Detailed</option>
          <option value="creative">Creative</option>
          <option value="technical">Technical</option>
        </select>
        <div class="platform-pill" id="platform-pill">AI assistant</div>
      </div>
      <div class="engine-summary">
        <div class="engine-name" id="engine-name">Smart Template</div>
        <div class="engine-copy" id="engine-copy">Runs locally without an account or API call.</div>
      </div>
    </div>

    <div class="signin-card" id="signin-card">
      <div class="signin-title">Free mode is ready</div>
      <div class="signin-copy">Sign in only when you want Premium cloud AI optimization.</div>
      <button class="btn btn-secondary" id="signin-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%; padding: 8px 10px; font-size: 12px;">Open Account</button>
    </div>

    <!-- Visual Score Circle & Info -->
    <div class="score-area">
      <div class="score-ring-container">
        <svg class="score-ring" viewBox="0 0 36 36">
          <path class="score-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="score-ring-progress" id="score-ring-bar" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="score-ring-val" id="score-ring-val">0</div>
      </div>
      <div class="score-info">
        <div class="score-label">Draft Quality</div>
        <div class="score-grade" id="score-grade">Empty</div>
      </div>
    </div>

    <!-- Dimension Chips -->
    <div class="chips-container" id="chips-container">
      <div class="chip chip-missing" data-dimension="task"><span class="chip-icon">✗</span> Task</div>
      <div class="chip chip-missing" data-dimension="context"><span class="chip-icon">✗</span> Context</div>
      <div class="chip chip-missing" data-dimension="role"><span class="chip-icon">✗</span> Role</div>
      <div class="chip chip-missing" data-dimension="format"><span class="chip-icon">✗</span> Format</div>
      <div class="chip chip-missing" data-dimension="constraints"><span class="chip-icon">✗</span> Constraints</div>
      <div class="chip chip-missing" data-dimension="specificity"><span class="chip-icon">✗</span> Specificity</div>
    </div>
    
    <button class="btn btn-primary" id="optimize-btn" aria-label="Optimize prompt" style="width: 100%;">Optimize Prompt</button>
    
    <!-- Shimmer Loader State -->
    <div class="loader-shimmer" id="loader-shimmer">
      <div class="shimmer-line shimmer-t"></div>
      <div class="shimmer-line shimmer-l1"></div>
      <div class="shimmer-line shimmer-l2"></div>
      <div class="shimmer-line shimmer-l3"></div>
      <span class="shimmer-label">Optimizing your prompt...</span>
    </div>

    <!-- Error/Auth card panel -->
    <div class="error-panel" id="error-panel">
      <div class="error-icon" id="error-panel-icon">!</div>
      <div class="error-title" id="error-panel-title">Optimization Failed</div>
      <div class="error-message" id="error-panel-message">Please try refreshing the page.</div>
      <button class="btn btn-secondary" id="error-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%;">Open Account</button>
    </div>
    
    <!-- Paywall Overlay -->
    <div class="paywall-overlay" id="paywall-overlay">
      <div class="paywall-card">
        <div class="paywall-icon" id="paywall-icon">AI</div>
        <div class="paywall-title" id="paywall-title">Unlock PromptIQ Premium</div>
        <div class="paywall-desc" id="paywall-desc">Use server-side AI optimization while keeping API keys out of the extension.</div>
        <button class="btn btn-primary" id="paywall-upgrade-btn" aria-label="Open PromptIQ popup to upgrade" style="width: 100%;">Open Upgrade Options</button>
        <button class="btn btn-secondary" id="paywall-close-btn" aria-label="Close upgrade message" style="width: 100%; margin-top: 8px;">Back</button>
      </div>
    </div>
    
    <!-- Result Editor Area -->
    <div class="result-section" id="result-section">
      <div class="success-summary">
        <div>
          <div class="success-title">Prompt is ready</div>
          <div class="success-copy">Review it, copy it, or send it back to the chat box.</div>
        </div>
        <div class="score-delta" id="score-delta">Improved</div>
      </div>
      <div class="editor-card">
        <div class="editor-header">
          <span class="editor-title" id="editor-view-title">Optimized Draft</span>
          <button class="btn btn-secondary" id="toggle-edit-btn" aria-label="Edit optimized prompt text" style="padding: 4px 10px; font-size: 11px;">Edit</button>
        </div>
        <div class="diff-view" id="diff-view"></div>
        <textarea class="optimized-textarea" id="optimized-text" style="display: none;"></textarea>
      </div>

      <div class="comparison-grid" id="comparison-grid" hidden>
        <div class="compare-box">
          <div class="compare-title">Original</div>
          <pre class="compare-text" id="compare-original"></pre>
        </div>
        <div class="compare-box">
          <div class="compare-title">Optimized</div>
          <pre class="compare-text" id="compare-optimized"></pre>
        </div>
      </div>
      
      <div class="changes-header" id="changes-header">
        <span class="changes-title">Changes Explained</span>
        <span style="font-size: 12px; color: var(--pi-primary); font-weight: 700;" id="toggle-changes-label">Show Changes</span>
      </div>
      <ul class="changes-list" id="changes-list"></ul>
      
      <!-- Feedback Loop Panel -->
      <div class="feedback-section" id="feedback-section">
        <span class="feedback-title">Was this optimization useful?</span>
        <div class="feedback-buttons" id="feedback-buttons-wrapper">
          <button class="feedback-btn" id="feedback-yes">👍 Yes</button>
          <button class="feedback-btn" id="feedback-no">👎 No</button>
        </div>
        <div class="feedback-thanks" id="feedback-thanks">Thank you! Your feedback helps us improve.</div>
      </div>
      
      <div class="action-row">
        <button class="btn btn-secondary" id="copy-btn" aria-label="Copy optimized prompt">Copy</button>
        <button class="btn btn-secondary" id="favorite-btn" aria-label="Save optimized prompt as favorite">Favorite</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="compare-btn" aria-label="Compare original and optimized prompt">Compare</button>
        <button class="btn btn-ghost" id="undo-btn" aria-label="Undo the last inserted optimization">Undo</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="retry-btn" aria-label="Retry optimization">Retry</button>
        <button class="btn btn-ghost" id="copy-original-btn" aria-label="Copy original prompt">Copy Original</button>
      </div>
      <button class="btn btn-primary" id="use-btn" aria-label="Use optimized prompt" style="width: 100%;">Use Prompt</button>
    </div>
  `,p.appendChild(v);let y=p.getElementById(`optimized-text`),b=p.getElementById(`diff-view`),x=p.getElementById(`toggle-edit-btn`),S=p.getElementById(`changes-list`),C=p.getElementById(`changes-header`),w=p.getElementById(`toggle-changes-label`),T=p.getElementById(`paywall-overlay`),E=p.getElementById(`optimize-btn`),D=p.getElementById(`loader-shimmer`),O=p.getElementById(`error-panel`),k=p.getElementById(`signin-card`),A=p.getElementById(`copy-btn`),j=p.getElementById(`copy-original-btn`),M=p.getElementById(`retry-btn`),N=p.getElementById(`mode-select`),P=p.getElementById(`platform-pill`),F=p.getElementById(`favorite-btn`),I=p.getElementById(`compare-btn`),L=p.getElementById(`undo-btn`),R=p.getElementById(`comparison-grid`),z=p.getElementById(`compare-original`),B=p.getElementById(`compare-optimized`);try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(`optimizationMode`,e=>{e.optimizationMode&&N.querySelector(`option[value="${e.optimizationMode}"]`)&&(N.value=e.optimizationMode)})}catch{}let V=()=>{let e=v.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)};_.addEventListener(`click`,V),_.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),V())}),p.getElementById(`close-btn`).addEventListener(`click`,()=>{v.classList.remove(`visible`),o.classList.remove(`panel-open`)});let H=p.getElementById(`logout-sidebar-btn`);H.addEventListener(`click`,()=>{confirm(`Are you sure you want to log out of PromptIQ?`)&&r()}),p.getElementById(`signin-open-popup-btn`).addEventListener(`click`,m),p.getElementById(`error-open-popup-btn`).addEventListener(`click`,m),N.addEventListener(`change`,()=>{try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({optimizationMode:N.value})}catch{}}),E.addEventListener(`click`,async()=>{D.style.display=`block`,O.style.display=`none`,p.getElementById(`result-section`).style.display=`none`,E.disabled=!0;try{await e()}catch(e){console.error(`onOptimize failed:`,e)}finally{D.style.display=`none`,s||(E.disabled=!1)}}),x.addEventListener(`click`,()=>{let e=p.getElementById(`editor-view-title`);y.style.display===`none`?(y.value=b.textContent,y.style.display=`block`,b.style.display=`none`,x.textContent=`View Diff`,e.textContent=`Edit Mode`):(b.style.display=`block`,y.style.display=`none`,x.textContent=`Edit`,e.textContent=`Optimized Draft`)}),C.addEventListener(`click`,()=>{S.classList.toggle(`expanded`),w.textContent=S.classList.contains(`expanded`)?`Hide`:`Show Changes`});function U(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}return p.getElementById(`use-btn`).addEventListener(`click`,()=>{t(y.style.display===`none`?b.textContent:y.value),v.classList.remove(`visible`),o.classList.remove(`panel-open`)}),A.addEventListener(`click`,async()=>{let e=y.style.display===`none`?b.textContent:y.value;try{await navigator.clipboard.writeText(e),A.textContent=`Copied`}catch{A.textContent=`Copy failed`}setTimeout(()=>{A.textContent=`Copy`},1600)}),j.addEventListener(`click`,async()=>{let e=f?.original||``;try{await navigator.clipboard.writeText(e),j.textContent=`Copied`}catch{j.textContent=`Copy failed`}setTimeout(()=>{j.textContent=`Copy Original`},1600)}),I.addEventListener(`click`,()=>{R.hidden=!R.hidden,I.textContent=R.hidden?`Compare`:`Hide Compare`}),L.addEventListener(`click`,()=>{L.textContent=typeof i==`function`&&i()?`Undone`:`Nothing to undo`,setTimeout(()=>{L.textContent=`Undo`},1600)}),F.addEventListener(`click`,async()=>{if(!f||typeof a!=`function`)return;let e=y.style.display===`none`?b.textContent:y.value;F.disabled=!0;try{F.textContent=await a({...f,optimized:e,mode:N.value})?`Favorited`:`Favorite`}catch{F.textContent=`Favorite failed`}finally{setTimeout(()=>{F.disabled=!1,F.textContent===`Favorite failed`&&(F.textContent=`Favorite`)},1400)}}),M.addEventListener(`click`,()=>{E.click()}),p.getElementById(`paywall-close-btn`).addEventListener(`click`,()=>{T.classList.remove(`active`)}),p.getElementById(`paywall-upgrade-btn`).addEventListener(`click`,()=>{m()}),p.getElementById(`feedback-yes`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`helpful`),p.getElementById(`feedback-buttons-wrapper`).style.display=`none`,p.getElementById(`feedback-thanks`).style.display=`block`)}),p.getElementById(`feedback-no`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`unhelpful`),p.getElementById(`feedback-buttons-wrapper`).style.display=`none`,p.getElementById(`feedback-thanks`).style.display=`block`)}),{container:o,setLoggedState:e=>{u=!!e,H.style.display=u?`block`:`none`,k.classList.toggle(`visible`,!u)},getSettings:()=>({mode:N.value||`standard`,platform:d||`general`}),setPlatform:e=>{d=e||`general`,P.textContent=h[d]||h.general},toggleVisibility:()=>{let e=v.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)},setTier:e=>{l=e===`premium`||e===`pro`?`premium`:`free`;let t=p.getElementById(`header-pro-badge`),n=p.getElementById(`engine-name`),r=p.getElementById(`engine-copy`);l===`premium`?(t.textContent=`PREMIUM`,t.className=`status-badge status-premium`,n.textContent=`Premium AI`,r.textContent=`Uses PromptIQ server-side AI for deeper optimization.`):(t.textContent=`FREE`,t.className=`status-badge status-free`,n.textContent=`Smart Template`,r.textContent=`Runs locally without an account or API call.`)},showPaywall:(e,t=null)=>{D.style.display=`none`,E.disabled=!1;let n=p.getElementById(`paywall-title`),r=p.getElementById(`paywall-desc`);n.textContent=`Unlock PromptIQ Premium`,r.textContent=`Premium uses PromptIQ server-side AI for deeper, context-aware optimization.`,T.classList.add(`active`)},updateScore:e=>{let t=p.getElementById(`score-dot`),n=p.getElementById(`score-text`),r=p.getElementById(`score-ring-bar`),i=p.getElementById(`score-ring-val`),a=p.getElementById(`score-grade`),o=Math.max(0,Math.min(100,e.score||0)),s=`Empty`;o>=76?s=`Strong`:o>=46?s=`Good`:o>0&&(s=`Weak`),i.textContent=o,a.textContent=s,n.textContent=`PromptIQ: ${o}`,r.setAttribute(`stroke-dasharray`,`${o}, 100`),t.className=`score-dot`,r.style.stroke=`var(--pi-muted)`,a.style.color=`var(--pi-text)`;let c=``,l=`var(--pi-muted)`;o>=76?(c=`score-excellent`,l=`var(--pi-success)`,a.style.color=`var(--pi-success)`):o>=46?(c=`score-good`,l=`var(--pi-warning)`,a.style.color=`var(--pi-warning)`):o>0&&(c=`score-weak`,l=`var(--pi-danger)`,a.style.color=`var(--pi-danger)`),c&&t.classList.add(c),r.style.stroke=l,p.querySelectorAll(`.chip`).forEach(t=>{let n=t.getAttribute(`data-dimension`);e.missing&&e.missing.includes(n)?(t.className=`chip chip-missing`,t.innerHTML=`<span class="chip-icon">✗</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`):(t.className=`chip chip-present`,t.innerHTML=`<span class="chip-icon">✓</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`)})},showResult:(e,t,n,r,i=null,a={})=>{c=r,O.style.display=`none`,p.getElementById(`result-section`).style.display=`block`,E.textContent=`Optimize Prompt`,R.hidden=!0,I.textContent=`Compare`,p.getElementById(`feedback-buttons-wrapper`).style.display=`flex`,p.getElementById(`feedback-thanks`).style.display=`none`,F.textContent=`Favorite`,y.value=e;let o=p.getElementById(`score-delta`);if(i&&Number.isFinite(i.originalScore)&&Number.isFinite(i.newScore)){let e=i.newScore-i.originalScore;o.textContent=e>=0?`+${e} pts`:`${e} pts`}else o.textContent=`Improved`;f={original:a.originalPrompt||``,optimized:e,platform:a.platform||d||`general`,intent:a.intent||null,mode:a.mode||N.value||`standard`,scoreOriginal:i?.originalScore??null,scoreOptimized:i?.newScore??null,timestamp:Date.now()},z.textContent=f.original,B.textContent=e,b.innerHTML=t.map(e=>e.added?`<span class="diff-added">${U(e.text)}</span>`:U(e.text)).join(``),S.innerHTML=n.map(e=>`
        <li class="change-item">
          <span class="change-icon">${U(e.icon)}</span>
          <div class="change-content">
            <span class="change-label">${U(e.label)}:</span>
            <span>${U(e.description)}</span>
          </div>
        </li>
      `).join(``),S.classList.remove(`expanded`),w.textContent=`Show Changes`,b.style.display=`block`,y.style.display=`none`,x.textContent=`Edit`,p.getElementById(`editor-view-title`).textContent=`Optimized Draft`;let s=p.querySelector(`.success-summary`);s.classList.remove(`pulse`),s.offsetWidth,s.classList.add(`pulse`)},showError:e=>{D.style.display=`none`,E.disabled=!1,p.getElementById(`result-section`).style.display=`none`;let t=p.getElementById(`error-panel-icon`),n=p.getElementById(`error-panel-title`),r=p.getElementById(`error-panel-message`);if(e.status===401||e.message.toLowerCase().includes(`log in`)||e.message.toLowerCase().includes(`session`)?(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=`Please log in again or try refreshing the page.`):(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=e.message||`Please log in again or try refreshing the page.`),O.style.display=`block`,e.status===429||e.message.includes(`429`)||e.message.includes(`quota`)){s=!0;let t=e.message.match(/retry in ([\d\.]+)s/i),n=t?Math.ceil(parseFloat(t[1])):60;E.disabled=!0,E.textContent=`Retry in ${n}s`;let r=setInterval(()=>{n--,n<=0?(clearInterval(r),s=!1,E.disabled=!1,E.textContent=`Optimize Prompt`):E.textContent=`Retry in ${n}s`},1e3)}}}}function l(e,t){let n=e.split(/(\s+)/),r=t.split(/(\s+)/),i=Array(n.length+1).fill(null).map(()=>Array(r.length+1).fill(0));for(let e=1;e<=n.length;e++)for(let t=1;t<=r.length;t++)n[e-1]===r[t-1]?i[e][t]=i[e-1][t-1]+1:i[e][t]=Math.max(i[e-1][t],i[e][t-1]);let a=[],o=n.length,s=r.length;for(;o>0||s>0;)o>0&&s>0&&n[o-1]===r[s-1]?(a.unshift({text:n[o-1],added:!1}),o--,s--):s>0&&(o===0||i[o][s-1]>=i[o-1][s])?(a.unshift({text:r[s-1],added:!0}),s--):o--;let c=[];for(let e of a)c.length>0&&c[c.length-1].added===e.added?c[c.length-1].text+=e.text:c.push({...e});return c}var u={role:{label:`Role / Persona`,icon:`👤`},task:{label:`Task Definition`,icon:`🎯`},context:{label:`Context / Background`,icon:`📖`},format:{label:`Output Format`,icon:`📊`},constraints:{label:`Constraints`,icon:`⛔`},specificity:{label:`Specificity`,icon:`🔍`},addition:{label:`Added Detail`,icon:`➕`},modification:{label:`Refined Phrasing`,icon:`✏️`},removal:{label:`Removed Clutter`,icon:`➖`}};function d(e){return Array.isArray(e)?e.map(e=>{let t=(e.type||``).toLowerCase(),n=u[t]||{label:`General Optimization`,icon:`⚡`};return{type:t,label:n.label,icon:n.icon,description:e.description||``}}):[]}var f={coding:/\b(code|function|class|bug|api|debug|regex|database|query|compile|github|git|javascript|js|python|html|css|java|c\+\+|rust|typescript|sql|programming|developer)\b/i,marketing:/\b(marketing|seo|copywriting|ad|email campaign|sales|social media|instagram|facebook|audience|target market|ctr|conversion|funnel|landing page|brand|copywriter)\b/i,creative:/\b(story|novel|poem|fiction|creative writing|character|plot|scifi|dialogue|metaphor|brainstorm|ideas|concept art|fable|script|narrative)\b/i,business:/\b(business|strategy|startup|investor|deck|marketing plan|swot|okr|kpi|pitch|revenue|profit|executive|report|slide|meeting|project management|consultant)\b/i,finance:/\b(finance|stock|investment|budget|valuation|crypto|bitcoin|portfolio|market trend|sheet|accounting|tax|audit|cfo|compound interest)\b/i,education:/\b(teach|learn|course|student|explain to|tutorial|curriculum|grade|lesson|exam|test prep|syllabus|homework|math|science|tutor|educator)\b/i,productivity:/\b(productivity|schedule|habit|workflow|automate|calendar|checklist|to-do|time management|efficiency|organize)\b/i,analysis:/\b(analyze|data|trend|graph|chart|statistics|correlation|outlier|hypothesis|excel|dataset|insight|compare|analyst)\b/i,writing:/\b(write|essay|article|blog post|summarize|paraphrase|grammar|tone|prose|revise|edit|proofread|letter|email|author)\b/i},p={standard:{label:`Standard`,instruction:`Balance clarity, completeness, and practical structure without making the prompt unnecessarily long.`},concise:{label:`Concise`,instruction:`Make the prompt compact and direct while preserving the full task, constraints, and success criteria.`},detailed:{label:`Detailed`,instruction:`Expand context, acceptance criteria, examples, and evaluation rules so the AI has enough detail to produce a high-quality answer.`},creative:{label:`Creative`,instruction:`Encourage distinctive angles, variations, tone options, and ideation while keeping the request usable and bounded.`},technical:{label:`Technical`,instruction:`Emphasize precision, edge cases, implementation constraints, validation steps, and measurable acceptance criteria.`}},m={chatgpt:{label:`ChatGPT`,instruction:`Use clear role, task, context, output format, and constraints sections. Prefer markdown headings and explicit success criteria.`},claude:{label:`Claude`,instruction:`Use natural language instructions with context first, then desired output, constraints, and examples when useful.`},gemini:{label:`Gemini`,instruction:`Use explicit task steps, source/context boundaries, and a clear final-answer format.`},perplexity:{label:`Perplexity`,instruction:`Ask for source-aware analysis, concise synthesis, and separation between facts, assumptions, and recommendations.`},copilot:{label:`Copilot`,instruction:`Specify the environment, expected implementation, error cases, and verification steps.`},deepseek:{label:`DeepSeek`,instruction:`Use precise technical context, constraints, and a validation checklist for the final answer.`},general:{label:`AI assistant`,instruction:`Use a broadly compatible prompt structure with clear task, context, output format, and constraints.`}};function h(e){return p[e]?e:`standard`}function g(e){return m[e]?e:`general`}function _(e){let t=e.toLowerCase();for(let[e,n]of Object.entries(f))if(n.test(t))return e;return`general`}function v(e){let t=e.toLowerCase(),n=t.trim().split(/\s+/).filter(Boolean).length,r=/\b(act as|you are|persona|role|specialist|expert|copywriter|developer|designer|analyst|tutor|writer)\b/i.test(t),i=/\b(audience|reader|user|student|customer|client|executive|demographic|viewer)\b/i.test(t),a=/\b(table|markdown|json|bullets|format|structure|list|html|paragraphs|headings|outline|schema)\b/i.test(t),o=/\b(don't|do not|max|limit|avoid|must|restrict|exclude|words|characters|no)\b/i.test(t),s=/\b(write|create|summarize|explain|code|analyze|generate|make|build|list|tweak|improve)\b/i.test(t),c=n>15;return{role:r,audience:i,format:a,constraints:o,objectives:s,context:c,missing:[!r&&`role`,!i&&`audience`,!a&&`format`,!o&&`constraints`,!s&&`objectives`,!c&&`context`].filter(Boolean)}}function y(e,t={}){if(!e||e.trim()===``)return{enhancedPrompt:``,intent:`general`,missing:[],mode:`standard`,platform:`general`};let n=_(e),r=v(e),i=h(t.mode),a=g(t.platform),o=p[i],s=m[a],c={coding:`expert software engineer`,marketing:`senior marketing copywriter and conversion strategist`,research:`rigorous academic researcher and analyst`,business:`expert business consultant and corporate strategist`,creative:`creative writer and narrative designer`,finance:`senior financial analyst`,education:`expert educator and academic tutor`,productivity:`workflow automation and productivity specialist`,analysis:`senior data analyst`,writing:`professional editor and copyeditor`,general:`highly capable expert assistant`},l={coding:`Clean markdown code blocks with line comments, input/output examples, and error handling notes.`,marketing:`High-impact copy structured with bold accents, short paragraphs, and direct bullet-point lists.`,research:`Detailed analysis organized with markdown headers, methodology descriptions, and references.`,business:`Executive summary format with key takeaways, bulleted metrics, and SWOT or ROI tables where applicable.`,creative:`Engaging narrative style with expressive descriptions and paragraph structures.`,education:`Step-by-step breakdown using clear explanations, definitions, and concept analogies.`,productivity:`Clean action checklist or process map with priority indicators.`,analysis:`Structured data summary with findings, key insights, and clear comparison tables.`,writing:`Polished prose matching the requested tone, formatted with appropriate line breaks.`,general:`Clear paragraphs, structured markdown lists, and headers.`},u={coding:`Ensure code runs efficiently, handles basic errors gracefully, and avoids using placeholder functions.`,marketing:`Avoid jargon. Stay highly persuasive, clear, and action-oriented.`,research:`Avoid bias. Base all assertions on logical reasoning and specify limits of analysis.`,business:`Stay objective, focus on KPI metrics, and highlight actionable next steps.`,creative:`Show, don't tell. Maximize sensory detail and ensure natural character voices.`,education:`Avoid overly complex language. Ensure definitions are clear and accessible.`,productivity:`Focus on simplicity and ease of execution. Keep it practical.`,analysis:`Exclude speculative insights not grounded in data. Be precise with comparisons.`,writing:`Avoid passive voice, reduce filler text, and check for tone consistency.`,general:`Avoid boilerplate introductory remarks. Be direct and clear.`},d=``,f=c[n]||c.general;d+=`[ROLE]\nWork as the following specialist: ${f}.\n\n`,d+=`[TASK]\nComplete the following request:\n${e.trim()}\n\n`,d+=`[AUDIENCE AND CONTEXT]
Use the audience and context stated in the request. When either is missing, make the smallest reasonable assumption and label it clearly.

`,d+=`[MODE]\n${o.label}: ${o.instruction}\n\n`,d+=`[PLATFORM CALIBRATION]\nOptimize this prompt for ${s.label}. ${s.instruction}\n\n`;let y=l[n]||l.general;d+=`[OUTPUT FORMAT]\n${y}\n\n`;let b=u[n]||u.general;return d+=`[CONSTRAINTS]\n${b}\n\n`,d+=`[QUALITY CHECK]
Address the request directly, preserve the user's intent, make the result actionable, reason internally without exposing hidden chain-of-thought, and do not return placeholders or instructions that bypass an AI service's safety controls.`,{enhancedPrompt:d.trim(),intent:n,missing:r.missing,mode:i,platform:a}}var b=null,x=null,S=null,C=``,w=``,T=null;function E(){return typeof chrome>`u`||!chrome.runtime||!chrome.runtime.id?(D(),!1):!0}function D(){try{b&&b.removeEventListener(`input`,A),T&&T.disconnect(),window.removeEventListener(`keydown`,F);let e=document.getElementById(`promptiq-container`);e&&e.remove()}catch{}}function O(){try{typeof chrome<`u`&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,t)=>{if(!(t!==`local`||!x)){if(e.sessionToken){let t=e.sessionToken.newValue;x&&x.setLoggedState(!!t)}e.userTier&&x.setTier(e.userTier.newValue||`free`)}})}catch{}}async function k(){if(S=s(),!S)return;P(),x&&x.setPlatform(S.platform);let t=await r();if(x){x.setLoggedState(!!t);try{let t=await e();x.setTier(t)}catch{}}let n=S.getInputElement();n&&j(n),M(),I(),L(),O()}function A(){if(!E()||!b||!x)return;let e=S.getText(b),t=a(e);t.missing=v(e).missing,x.updateScore(t)}function j(e){if(!e||!x)return;b&&b!==e&&b.removeEventListener(`input`,A),b=e,b.addEventListener(`input`,A);let t=S.getText(b),n=a(t);n.missing=v(t).missing,x.updateScore(n)}function M(){T=new MutationObserver(()=>{if(!E())return;let e=S.getInputElement();e&&e!==b&&j(e)}),T.observe(document.body,{childList:!0,subtree:!0})}async function N(){await n(),x&&(x.setLoggedState(!1),x.setTier(`free`),x.showError(Error(`Signed out. Free Smart Template optimization remains available.`)))}function P(){document.getElementById(`promptiq-container`)||(x=c(R,B,U,N,V,H),document.body.appendChild(x.container))}function F(e){E()&&e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()===`p`&&(e.preventDefault(),x&&x.toggleVisibility())}function I(){window.addEventListener(`keydown`,F)}function L(){try{chrome.runtime.onMessage.addListener((e,t,n)=>{if(E()){if(e.action===`OPTIMIZE_SELECTION`)x&&(x.toggleVisibility(),b&&(S.setText(b,e.text),R()));else if(e.action===`INSERT_PROMPT`&&b){S.setText(b,e.text);let t=a(e.text);t.missing=v(e.text).missing,x.updateScore(t)}}})}catch{}}async function R(){if(!E())return;let t=(S.getText(b)||``).trim();if(!t){x.showError(Error(`Prompt is empty.`));return}let o=await r(),s=await e(),c=(x.getSettings?x.getSettings():{mode:`standard`,platform:S.platform}).mode||`standard`;!o&&s===`premium`&&(s=`free`),x&&(x.setLoggedState(!!o),x.setTier(s));let u=y(t,{mode:c,platform:S.platform}),f,p=s;try{if(s===`premium`&&o){let e=await chrome.runtime.sendMessage({action:`CALL_OPTIMIZER`,originalPrompt:t,platform:S.platform,locallyEnhancedPrompt:u.enhancedPrompt,detectedIntent:u.intent,mode:c,token:o});if(!e||!e.success){let t=Error(e?.error||`Failed to optimize prompt.`);throw t.status=e?.status,t}f=e.result}else f=z(u);C=f.optimized;let e=a(t).score,n=a(f.optimized).score,r=await i(t,f.optimized,n-e,S.platform,u.intent,c,e,n),m=l(t,f.optimized),h=d(f.changes);x.showResult(f.optimized,m,h,r,{originalScore:e,newScore:n},{originalPrompt:t,platform:S.platform,intent:u.intent,mode:c,tier:p})}catch(e){if(e.code===`PREMIUM_LIMIT_REACHED`)x&&x.showError(e);else if(e.status===401||e.status===403)await n(),x&&(x.setLoggedState(!1),x.setTier(`free`)),x.showError(Error(`Premium access could not be verified. Sign in again, or continue with Free Smart Template.`));else if(e.message&&e.message.includes(`Extension context invalidated`)){let e=Error(`PromptIQ has been updated. Please refresh the page to continue.`);x.showError(e)}else x&&x.showError(e)}}function z(e){let t={role:`Added an expert role to guide tone and decision quality.`,task:`Clarified the objective and preserved the original request.`,context:`Added context guidance so the response is complete and useful.`,format:`Specified a structured output format for easier use.`,constraints:`Added practical boundaries to reduce vague or generic output.`,specificity:`Expanded the request with audience and delivery details.`};return{optimized:e.enhancedPrompt,changes:[`role`,`task`,`context`,`format`,`constraints`,`specificity`].map(e=>({type:e,description:t[e]}))}}function B(e){if(!E())return;let t=e||C;if(t){w=S.getText(b)||``,S.setText(b,t);let e=a(t);e.missing=v(t).missing,x.updateScore(e)}}function V(){if(!E()||!w||!b)return!1;S.setText(b,w);let e=a(w);return e.missing=v(w).missing,x.updateScore(e),w=``,!0}async function H(e){return E()?(await t(e)).favorite:!1}async function U(e,t){if(!E()||!e)return;let n=await r();if(n)try{await fetch(`https://promptiq-theta.vercel.app/api/feedback`,{method:`POST`,headers:{Authorization:`Bearer ${n}`,"Content-Type":`application/json`},body:JSON.stringify({id:e,feedback:t})})}catch(e){console.error(`Failed to submit feedback:`,e)}}k();