import{_ as e,a as t,b as n,c as r,l as i,p as a,r as o,y as s}from"./activity-Dnvq2ntp.js";import{t as c}from"./optimizer-BL7sNSRc.js";import{t as l}from"./scorer-mk_Yd85t.js";var u=[{id:`chatgpt`,matches:[`chatgpt.com`,`chat.openai.com`],selector:`#prompt-textarea, textarea[data-id="root"]`,isContentEditable:!1},{id:`claude`,matches:[`claude.ai`],selector:`div.ProseMirror[contenteditable="true"]`,isContentEditable:!0},{id:`gemini`,matches:[`gemini.google.com`],selector:`rich-textarea div[contenteditable="true"], .ql-editor[contenteditable="true"], rich-textarea textarea, .text-input-field`,isContentEditable:!0},{id:`perplexity`,matches:[`www.perplexity.ai`],selector:`textarea, [data-lexical-editor="true"][contenteditable="true"]`,isContentEditable:!1},{id:`copilot`,matches:[`copilot.microsoft.com`],selector:`#searchbox, textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1},{id:`deepseek`,matches:[`chat.deepseek.com`],selector:`#chat-input, textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1},{id:`grok`,matches:[`grok.com`],selector:`textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1},{id:`mistral`,matches:[`chat.mistral.ai`],selector:`textarea, div.ProseMirror[contenteditable="true"], [contenteditable="true"][role="textbox"]`,isContentEditable:!1},{id:`meta`,matches:[`meta.ai`,`www.meta.ai`],selector:`[contenteditable="true"][role="textbox"], textarea`,isContentEditable:!1},{id:`poe`,matches:[`poe.com`],selector:`textarea, [contenteditable="true"][role="textbox"], div.ProseMirror[contenteditable="true"]`,isContentEditable:!1},{id:`you`,matches:[`you.com`],selector:`textarea, [contenteditable="true"][role="textbox"]`,isContentEditable:!1}];function d(e,t){return e===t||e.endsWith(`.${t}`)}function f(e){return e.split(`,`).flatMap(e=>[...document.querySelectorAll(e.trim())]).filter((e,t,n)=>n.indexOf(e)===t).filter(e=>{if(e.disabled||e.readOnly||e.closest(`dialog, [role="dialog"], [hidden], [aria-hidden="true"]`)||!e.isContentEditable&&!e.matches(`textarea, input[type="text"], input[type="search"], input:not([type])`))return!1;let t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>=120&&t.height>=24&&n.display!==`none`&&n.visibility!==`hidden`}).sort((e,t)=>{let n=e.getBoundingClientRect(),r=t.getBoundingClientRect();return r.bottom-n.bottom||r.width*r.height-n.width*n.height})[0]||null}function p(){let e=window.location.hostname,t=u.find(t=>t.matches.some(t=>d(e,t)));return t?{platform:t.id,getInputElement:()=>f(t.selector),getText:e=>e?e.tagName===`TEXTAREA`||e.tagName===`INPUT`?e.value||``:e.innerText||``:``,setText:(e,t)=>{if(!e)return;e.focus();let n=e.tagName===`TEXTAREA`||e.tagName===`INPUT`;if(n)e.select();else{let t=document.createRange();t.selectNodeContents(e);let n=window.getSelection();n.removeAllRanges(),n.addRange(t)}let r=!1;try{r=document.execCommand(`insertText`,!1,t)}catch(e){console.error(`execCommand failed:`,e)}if(!r)if(!n)e.innerText=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}));else{let n=e.tagName===`INPUT`?window.HTMLInputElement.prototype:window.HTMLTextAreaElement.prototype,r=Object.getOwnPropertyDescriptor(n,`value`)?.set;r?r.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0}))}}}:null}function m(e,t,n,r,i,a){let o=document.createElement(`div`);o.id=`promptiq-container`,o.style.cssText=`position: fixed; bottom: 24px; right: 24px; z-index: 2147483000; font-family: Inter, system-ui, -apple-system, sans-serif;`;let s=!1,c=null,l=!1,u=!1,d=`general`,f=null,p=null,m=o.attachShadow({mode:`closed`}),h=async()=>{try{if(typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage){let e=await chrome.runtime.sendMessage({action:`OPEN_ONBOARDING`});if(!e?.success)throw Error(e?.error||`Account page could not be opened.`);return}}catch{window.alert(`PromptIQ was updated. Refresh this page, then try opening the account again.`);return}window.alert(`Open the PromptIQ extension from your browser toolbar.`)},g={chatgpt:`ChatGPT`,claude:`Claude`,gemini:`Gemini`,perplexity:`Perplexity`,copilot:`Copilot`,deepseek:`DeepSeek`,grok:`Grok`,mistral:`Le Chat`,meta:`Meta AI`,poe:`Poe`,you:`You.com`,general:`AI assistant`},_=document.createElement(`style`);_.textContent=`
    :host {
      color-scheme: dark;
      --pi-bg: #101414;
      --pi-card: #101414;
      --pi-elevated: #171e1b;
      --pi-border: rgba(159, 255, 200, .08);
      --pi-text: #f1f7f3;
      --pi-muted: #a8b8af;
      --pi-primary: #9fffc8;
      --pi-primary-strong: #9fffc8;
      --pi-success: #9fffc8;
      --pi-warning: #9fffc8;
      --pi-danger: #9fffc8;
      --pi-pro: #9fffc8;
      --pi-glow: rgba(159, 255, 200, 0.08);
      --pi-shadow: rgba(159, 255, 200, 0.06);
      --pi-radius: 8px;
    }


    .badge {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 9px 16px;
      border-radius: 9999px;
      background: var(--pi-elevated);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      user-select: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 25px -5px var(--pi-shadow);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
    }
    .badge:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 30px -5px var(--pi-shadow);
      border-color: var(--pi-primary);
    }
    :host(.panel-open) .badge {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8) translateY(10px);
    }
    .score-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--pi-muted);
      transition: background 0.3s, box-shadow 0.3s;
    }
    .score-excellent { background: var(--pi-success); box-shadow: none; }
    .score-good { background: var(--pi-warning); box-shadow: none; }
    .score-fair { background: #9fffc8; box-shadow: none; }
    .score-weak { background: var(--pi-danger); box-shadow: none; }
    
    .panel-wrapper {
      display: flex;
      flex-direction: column;
      position: fixed;
      top: 24px;
      right: 24px;
      bottom: 24px;
      width: 382px;
      max-width: calc(100vw - 48px);
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      border-radius: var(--pi-radius);
      box-shadow: 0 28px 60px -18px var(--pi-shadow), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 18px;
      color: var(--pi-text);
      box-sizing: border-box;
      z-index: 1000000;
      backdrop-filter: blur(24px) saturate(120%);
      -webkit-backdrop-filter: blur(24px) saturate(120%);
      overflow: hidden;
      
      transform: translateX(calc(100% + 48px));
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.3s ease;
      opacity: 0;
      pointer-events: none;
    }
    .panel-wrapper.visible {
      transform: translateX(0);
      opacity: 1;
      pointer-events: auto;
    }
    .panel-wrapper.has-result .signin-card,
    .panel-wrapper.has-result .score-area,
    .panel-wrapper.has-result .chips-container {
      display: none;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 18px;
      border-bottom: 1px solid var(--pi-border);
      padding-bottom: 12px;
    }
    .header-logo-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .title { 
      font-weight: 800; 
      font-size: 17px; 
      color: var(--pi-text); 
      letter-spacing: 0;
    }
    .status-badge {
      font-size: 9px;
      font-weight: 800;
      padding: 2.5px 8px;
      border-radius: 6px;
      letter-spacing: 0;
    }
    .status-free {
      background: rgba(159, 255, 200, 0.1);
      color: var(--pi-muted);
    }
    .signin-card {
      display: none;
      background: rgba(159, 255, 200, 0.08);
      border: 1px solid rgba(159, 255, 200, 0.2);
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 14px;
      color: var(--pi-text);
    }
    .signin-card.visible {
      display: block;
    }
    .signin-title {
      font-size: 12px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .signin-copy {
      font-size: 11.5px;
      line-height: 1.45;
      color: var(--pi-muted);
      margin-bottom: 10px;
    }
    
    .mode-selector-wrapper {
      margin-bottom: 18px;
    }
    .mode-selector-wrapper label {
      display: block;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 6px;
      color: var(--pi-muted);
      letter-spacing: 0;
    }
    .settings-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1.2fr) minmax(0, .9fr);
      gap: 8px;
      margin-bottom: 10px;
    }
    .select-control {
      width: 100%;
      min-height: 38px;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font: inherit;
      font-size: 12px;
      font-weight: 700;
      box-sizing: border-box;
    }
    .platform-pill {
      min-height: 38px;
      display: flex;
      align-items: center;
      padding: 0 10px;
      border-radius: 8px;
      border: 1px solid var(--pi-border);
      background: var(--pi-card);
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
      box-sizing: border-box;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .engine-summary {
      padding: 8px 0 0;
      background: var(--pi-card);
    }
    .engine-name {
      color: var(--pi-text);
      font-size: 12px;
      font-weight: 800;
    }
    .engine-copy {
      margin-top: 3px;
      color: var(--pi-muted);
      font-size: 11px;
      line-height: 1.4;
    }

    /* Visual Score Progress Area */
    .score-area {
      background: var(--pi-card);
      border-block: 1px solid var(--pi-border);
      padding: 16px 0;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .score-ring-container {
      position: relative;
      width: 56px;
      height: 56px;
      flex-shrink: 0;
    }
    .score-ring {
      width: 100%;
      height: 100%;
      transform: rotate(-90deg);
    }
    .score-ring-bg {
      fill: none;
      stroke: var(--pi-border);
      stroke-width: 4;
    }
    .score-ring-progress {
      fill: none;
      stroke: var(--pi-muted);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.5s ease;
    }
    .score-ring-val {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 15px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .score-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .score-label {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .score-grade {
      font-size: 16px;
      font-weight: 800;
      color: var(--pi-text);
    }

    /* Dimension Chips */
    .chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-bottom: 18px;
    }
    .chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      transition: all 0.2s ease;
      border: 1px solid transparent;
    }
    .chip-present {
      background: rgba(159, 255, 200, 0.06);
      color: var(--pi-success);
      border-color: rgba(159, 255, 200, 0.12);
    }
    .chip-missing {
      background: rgba(159, 255, 200, 0.05);
      color: var(--pi-muted);
      border-color: var(--pi-border);
      opacity: 1;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 8px;
      border: 1px solid transparent;
      font-size: 13.5px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      display: inline-flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
      font-family: inherit;
    }
    .btn:focus-visible,
    .feedback-btn:focus-visible,
    .badge:focus-visible,
    select:focus-visible,
    textarea:focus-visible {
      outline: 2px solid var(--pi-primary);
      outline-offset: 2px;
    }
    .btn-primary {
      background: var(--pi-primary);
      color: #101414;
      box-shadow: 0 4px 12px var(--pi-glow);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 16px var(--pi-glow);
    }
    .btn-primary:disabled {
      opacity: 0.5;
      transform: none;
      cursor: not-allowed;
    }
    .btn-secondary {
      background: var(--pi-card);
      color: var(--pi-text);
      border-color: var(--pi-border);
    }
    .btn-secondary:hover {
      background: var(--pi-border);
    }
    .btn-ghost {
      background: transparent;
      color: var(--pi-muted);
      border-color: var(--pi-border);
    }
    
    .result-section {
      display: none;
      margin-top: 18px;
      padding-top: 18px;
      border-top: 1px solid var(--pi-border);
      overflow-y: auto;
      flex: 1;
    }
    .success-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      margin-bottom: 12px;
      border-radius: 8px;
      border: 1px solid rgba(159, 255, 200, 0.18);
      background: rgba(159, 255, 200, 0.07);
    }
    .success-summary.pulse {
      animation: successPulse 650ms ease-out;
    }
    @keyframes successPulse {
      0% { transform: scale(0.985); border-color: rgba(159, 255, 200, 0.1); }
      100% { transform: scale(1); border-color: rgba(159, 255, 200, 0.18); }
    }
    .success-title {
      font-size: 13px;
      font-weight: 800;
      color: var(--pi-text);
    }
    .success-copy {
      font-size: 11.5px;
      color: var(--pi-muted);
      margin-top: 2px;
    }
    .score-delta {
      font-size: 12px;
      font-weight: 800;
      color: var(--pi-success);
      white-space: nowrap;
    }
    
    /* Mock Editor Window */
    .editor-card {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      margin-bottom: 14px;
      box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.03);
    }
    .editor-header {
      background: rgba(159, 255, 200, 0.03);
      padding: 10px 16px;
      border-bottom: 1px solid var(--pi-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .editor-title {
      font-size: 11px;
      font-weight: 700;
      color: var(--pi-muted);
      text-transform: uppercase;
      letter-spacing: 0;
    }

    .optimized-textarea {
      width: 100%;
      height: 150px;
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      resize: vertical;
      font-family: inherit;
      color: var(--pi-text);
      box-sizing: border-box;
      max-height: 240px;
    }
    .optimized-textarea:focus {
      outline: none;
    }

    .diff-view {
      font-size: 13px;
      line-height: 1.55;
      background: transparent;
      border: none;
      padding: 14px;
      max-height: 150px;
      overflow-y: auto;
      margin: 0;
      white-space: pre-wrap;
      color: var(--pi-text);
      box-sizing: border-box;
    }
    .diff-added {
      background: rgba(159, 255, 200, 0.15);
      color: var(--pi-success);
      font-weight: 600;
      padding: 2px 4px;
      border-radius: 4px;
    }
    .comparison-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 14px;
    }
    .comparison-grid[hidden] {
      display: none;
    }
    .compare-box {
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      background: var(--pi-card);
      overflow: hidden;
      min-width: 0;
    }
    .compare-title {
      padding: 8px 10px;
      border-bottom: 1px solid var(--pi-border);
      color: var(--pi-muted);
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0;
    }
    .compare-text {
      margin: 0;
      padding: 10px;
      min-height: 96px;
      max-height: 150px;
      overflow-y: auto;
      white-space: pre-wrap;
      color: var(--pi-text);
      font: inherit;
      font-size: 11.5px;
      line-height: 1.45;
    }

    .changes-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      user-select: none;
    }
    .action-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 10px;
    }
    .changes-title {
      font-weight: 700;
      font-size: 13px;
      color: var(--pi-text);
    }
    
    .changes-list {
      font-size: 12px;
      list-style: none;
      padding: 0;
      margin: 0 0 18px 0;
      max-height: 150px;
      overflow-y: auto;
      display: none;
    }
    .changes-list.expanded {
      display: block;
    }
    .change-item {
      display: flex;
      gap: 10px;
      padding: 8px 0;
      border-bottom: 1px solid var(--pi-border);
    }
    .change-icon {
      font-size: 14px;
      flex-shrink: 0;
    }
    .change-content {
      line-height: 1.45;
    }
    .change-label {
      font-weight: 700;
      color: var(--pi-text);
    }
    
    /* Loading Shimmer State */
    .loader-shimmer {
      display: none;
      background: var(--pi-card);
      border: 1px solid var(--pi-border);
      border-radius: 8px;
      padding: 20px;
      position: relative;
      overflow: hidden;
      margin-top: 18px;
    }
    .shimmer-line {
      height: 11px;
      background: var(--pi-border);
      margin-bottom: 12px;
      border-radius: 4px;
      position: relative;
      overflow: hidden;
    }
    .shimmer-line::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transform: translateX(-100%);
      animation: shimmer 1.5s infinite;
    }

    .shimmer-t { width: 35%; height: 13px; }
    .shimmer-l1 { width: 85%; }
    .shimmer-l2 { width: 95%; }
    .shimmer-l3 { width: 70%; }
    .shimmer-label {
      display: block;
      text-align: center;
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-muted);
      margin-top: 8px;
      letter-spacing: 0;
    }
    @keyframes shimmer {
      100% { transform: translateX(100%); }
    }
    
    /* Feedback Section */
    .feedback-section {
      background: var(--pi-card);
      border-top: 1px solid var(--pi-border);
      padding: 14px;
      text-align: center;
      margin-top: 14px;
      margin-bottom: 14px;
    }
    .feedback-title {
      font-size: 12px;
      font-weight: 700;
      color: var(--pi-text);
      display: block;
      margin-bottom: 10px;
    }
    .feedback-buttons {
      display: flex;
      gap: 10px;
      justify-content: center;
    }
    .feedback-btn {
      background: var(--pi-bg);
      border: 1px solid var(--pi-border);
      color: var(--pi-text);
      font-size: 12.5px;
      font-weight: 700;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .feedback-btn:hover {
      background: var(--pi-border);
      transform: translateY(-1px);
    }
    .feedback-thanks {
      font-size: 12.5px;
      font-weight: 700;
      color: var(--pi-success);
      display: none;
      margin-top: 4px;
    }

    /* Error and Authentication states */
    .error-panel {
      display: none;
      background: rgba(159, 255, 200, 0.04);
      border: 1px solid rgba(159, 255, 200, 0.18);
      border-radius: 8px;
      padding: 18px;
      text-align: left;
      margin-top: 18px;
    }
    .error-icon {
      font-size: 28px;
      margin-bottom: 10px;
    }
    .error-title {
      font-weight: 800;
      font-size: 15px;
      color: var(--pi-danger);
      margin-bottom: 6px;
    }
    .error-message {
      font-size: 12px;
      color: var(--pi-text);
      line-height: 1.5;
      margin-bottom: 14px;
    }
    *, *::before, *::after { letter-spacing: 0; }
    .panel-wrapper > * { flex-shrink: 0; }
    .panel-wrapper > .result-section { flex-shrink: 1; min-height: 0; }
    .panel-wrapper { overflow-y: auto; }
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { animation: none !important; transition: none !important; }
    }
    @media (max-width: 520px) {
      .panel-wrapper {
        top: auto;
        left: 12px;
        right: 12px;
        bottom: 12px;
        width: auto;
        max-width: none;
        max-height: calc(100vh - 24px);
        padding: 16px;
      }
      .action-row {
        grid-template-columns: 1fr;
      }
      .settings-grid {
        grid-template-columns: 1fr 1fr;
        gap: 6px;
      }
      .platform-pill {
        grid-column: 1 / -1;
        min-height: 20px;
        padding: 0;
        border: 0;
        font-size: 10px;
      }
      .comparison-grid {
        grid-template-columns: 1fr;
      }
    }
  `,m.appendChild(_);let v=document.createElement(`div`);v.className=`badge`,v.tabIndex=0,v.setAttribute(`role`,`button`),v.setAttribute(`aria-label`,`Open PromptIQ optimizer`),v.innerHTML=`<div class="score-dot" id="score-dot"></div><span id="score-text">PromptIQ: 0</span>`,m.appendChild(v);let y=document.createElement(`div`);y.className=`panel-wrapper`,y.innerHTML=`
    <div class="header">
      <div class="header-logo-group">
        <svg width="24" height="24" viewBox="0 0 128 128" aria-hidden="true" style="flex-shrink:0"><rect width="128" height="128" rx="26" fill="#9fffc8"/><path fill="#101414" d="M31 31h42l24 25v18L73 98H53l-22 13V31zm17 17v34l17-10h5l12-12-12-12H48z" fill-rule="evenodd"/></svg>
        <div class="title">PromptIQ</div>
        <div class="status-badge status-free">FREE</div>
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary" id="logout-sidebar-btn" aria-label="Log out of PromptIQ" style="padding: 4px 8px; font-size: 10px; background: rgba(159, 255, 200, 0.08); color: var(--pi-danger); border-color: rgba(159, 255, 200, 0.12); display: none;">Log Out</button>
        <button class="btn btn-secondary" id="close-btn" aria-label="Close PromptIQ optimizer" style="padding: 6px 12px; font-size: 11px;">Close</button>
      </div>
    </div>
    
    <div class="mode-selector-wrapper">
      <label>Mode, engine, and platform</label>
      <div class="settings-grid">
        <select class="select-control" id="mode-select" aria-label="Optimization mode">
          <option value="standard">Standard</option>
          <option value="concise">Concise</option>
          <option value="detailed">Detailed</option>
          <option value="creative">Creative</option>
          <option value="technical">Technical</option>
        </select>
        <select class="select-control" id="engine-select" aria-label="Optimization engine">
          <option value="quick_rewrite">Quick Rewrite</option>
          <option value="ai_rewrite" disabled hidden>AI Rewrite</option>
        </select>
        <div class="platform-pill" id="platform-pill">AI assistant</div>
      </div>
      <div class="engine-summary">
        <div class="engine-name" id="engine-name">Quick Rewrite</div>
        <div class="engine-copy" id="engine-copy">Create an account to score, save, and optimize prompts.</div>
      </div>
    </div>

    <div class="signin-card" id="signin-card">
      <div class="signin-title" id="signin-title">Account required</div>
      <div class="signin-copy" id="signin-copy">Sign in or create an account to use PromptIQ.</div>
      <button class="btn btn-secondary" id="signin-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%; padding: 8px 10px; font-size: 12px;">Continue to Account</button>
    </div>

    <!-- Visual Score Circle & Info -->
    <div class="score-area">
      <div class="score-ring-container">
        <svg class="score-ring" viewBox="0 0 36 36">
          <path class="score-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path class="score-ring-progress" id="score-ring-bar" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
        <div class="score-ring-val" id="score-ring-val">0</div>
      </div>
      <div class="score-info">
        <div class="score-label">Draft Quality</div>
        <div class="score-grade" id="score-grade">Empty</div>
      </div>
    </div>

    <!-- Dimension Chips -->
    <div class="chips-container" id="chips-container">
      <div class="chip chip-missing" data-dimension="task"><span class="chip-icon">✗</span> Task</div>
      <div class="chip chip-missing" data-dimension="context"><span class="chip-icon">✗</span> Context</div>
      <div class="chip chip-missing" data-dimension="role"><span class="chip-icon">✗</span> Role</div>
      <div class="chip chip-missing" data-dimension="format"><span class="chip-icon">✗</span> Format</div>
      <div class="chip chip-missing" data-dimension="constraints"><span class="chip-icon">✗</span> Constraints</div>
      <div class="chip chip-missing" data-dimension="specificity"><span class="chip-icon">✗</span> Specificity</div>
    </div>
    
    <button class="btn btn-primary" id="optimize-btn" aria-label="Optimize prompt" style="width: 100%;">Optimize Prompt</button>
    
    <!-- Shimmer Loader State -->
    <div class="loader-shimmer" id="loader-shimmer">
      <div class="shimmer-line shimmer-t"></div>
      <div class="shimmer-line shimmer-l1"></div>
      <div class="shimmer-line shimmer-l2"></div>
      <div class="shimmer-line shimmer-l3"></div>
      <span class="shimmer-label">Optimizing your prompt...</span>
    </div>

    <!-- Error/Auth card panel -->
    <div class="error-panel" id="error-panel">
      <div class="error-icon" id="error-panel-icon">!</div>
      <div class="error-title" id="error-panel-title">Optimization Failed</div>
      <div class="error-message" id="error-panel-message">Please try refreshing the page.</div>
      <button class="btn btn-secondary" id="error-open-popup-btn" aria-label="Open PromptIQ account page" style="width: 100%;">Open Account</button>
    </div>
    
    <!-- Result Editor Area -->
    <div class="result-section" id="result-section">
      <div class="success-summary">
        <div>
          <div class="success-title">Prompt is ready</div>
          <div class="success-copy">Review it, copy it, or send it back to the chat box.</div>
        </div>
        <div class="score-delta" id="score-delta">Improved</div>
      </div>
      <div class="editor-card">
        <div class="editor-header">
          <span class="editor-title" id="editor-view-title">Optimized Draft</span>
          <button class="btn btn-secondary" id="toggle-edit-btn" aria-label="Edit optimized prompt text" style="padding: 4px 10px; font-size: 11px;">Edit</button>
        </div>
        <div class="diff-view" id="diff-view"></div>
        <textarea class="optimized-textarea" id="optimized-text" style="display: none;"></textarea>
      </div>
      <button class="btn btn-primary" id="use-btn" aria-label="Use optimized prompt" style="width: 100%; margin: 12px 0;">Use Prompt</button>

      <div class="comparison-grid" id="comparison-grid" hidden>
        <div class="compare-box">
          <div class="compare-title">Original</div>
          <pre class="compare-text" id="compare-original"></pre>
        </div>
        <div class="compare-box">
          <div class="compare-title">Optimized</div>
          <pre class="compare-text" id="compare-optimized"></pre>
        </div>
      </div>
      
      <div class="changes-header" id="changes-header">
        <span class="changes-title">Changes Explained</span>
        <span style="font-size: 12px; color: var(--pi-primary); font-weight: 700;" id="toggle-changes-label">Show Changes</span>
      </div>
      <ul class="changes-list" id="changes-list"></ul>
      
      <!-- Feedback Loop Panel -->
      <div class="feedback-section" id="feedback-section">
        <span class="feedback-title">Was this optimization useful?</span>
        <div class="feedback-buttons" id="feedback-buttons-wrapper">
          <button class="feedback-btn" id="feedback-yes">Yes</button>
          <button class="feedback-btn" id="feedback-no">No</button>
        </div>
        <div class="feedback-thanks" id="feedback-thanks">Thank you! Your feedback helps us improve.</div>
      </div>
      
      <div class="action-row">
        <button class="btn btn-secondary" id="copy-btn" aria-label="Copy optimized prompt">Copy</button>
        <button class="btn btn-secondary" id="favorite-btn" aria-label="Save optimized prompt as favorite">Favorite</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="compare-btn" aria-label="Compare original and optimized prompt">Compare</button>
        <button class="btn btn-ghost" id="undo-btn" aria-label="Undo the last inserted optimization">Undo</button>
      </div>
      <div class="action-row">
        <button class="btn btn-ghost" id="retry-btn" aria-label="Retry optimization">Retry</button>
        <button class="btn btn-ghost" id="copy-original-btn" aria-label="Copy original prompt">Copy Original</button>
      </div>
    </div>
  `,m.appendChild(y);let b=m.getElementById(`optimized-text`),x=m.getElementById(`diff-view`),S=m.getElementById(`toggle-edit-btn`),C=m.getElementById(`changes-list`),w=m.getElementById(`changes-header`),T=m.getElementById(`toggle-changes-label`),E=m.getElementById(`optimize-btn`),D=m.getElementById(`loader-shimmer`),O=m.getElementById(`error-panel`),k=m.getElementById(`signin-card`),A=m.getElementById(`copy-btn`),j=m.getElementById(`copy-original-btn`),M=m.getElementById(`retry-btn`),N=m.getElementById(`mode-select`),P=m.getElementById(`engine-select`),F=m.getElementById(`platform-pill`),I=m.getElementById(`favorite-btn`),L=m.getElementById(`compare-btn`),R=m.getElementById(`undo-btn`),z=m.getElementById(`comparison-grid`),B=m.getElementById(`compare-original`),V=m.getElementById(`compare-optimized`);try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.get(`optimizationMode`,e=>{[...N.options].some(t=>t.value===e.optimizationMode)&&(N.value=e.optimizationMode)})}catch{}function H(){let e=m.getElementById(`engine-name`),t=m.getElementById(`engine-copy`),n=!!(p&&P.value===`ai_rewrite`);if(s||(E.textContent=n?`Send for AI Rewrite`:`Optimize Prompt`,E.setAttribute(`aria-label`,E.textContent)),!l||!u){e.textContent=`Account required`,t.textContent=l?`Review the privacy settings to continue.`:`Create an account to score, save, and optimize prompts.`;return}n?(e.textContent=`AI Rewrite`,t.textContent=`Sends this prompt to FreeLLMAPI and ${p.provider} to rewrite it. The result is saved to your account.`):(e.textContent=`Quick Rewrite`,t.textContent=`Runs on your device. Completed rewrites are saved to your account history.`)}function U(){let e=l&&u;N.disabled=!e,P.disabled=!e,E.disabled=!e||s,k.classList.toggle(`visible`,!e);let t=m.getElementById(`signin-title`),n=m.getElementById(`signin-copy`),r=m.getElementById(`score-text`);l?u?(r.textContent.includes(`Sign in`)||r.textContent.includes(`Finish setup`))&&(r.textContent=`PromptIQ: 0`):(t.textContent=`Finish privacy setup`,n.textContent=`Review how PromptIQ scores drafts and saves rewrites.`,r.textContent=`PromptIQ: Finish setup`):(t.textContent=`Account required`,n.textContent=`Sign in or create an account to use PromptIQ.`,r.textContent=`PromptIQ: Sign in`),(!e||!p)&&(P.value=`quick_rewrite`),H()}let W=()=>{let e=y.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)};v.addEventListener(`click`,W),v.addEventListener(`keydown`,e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),W())}),m.getElementById(`close-btn`).addEventListener(`click`,()=>{y.classList.remove(`visible`),o.classList.remove(`panel-open`),P.value=`quick_rewrite`,H()});let G=m.getElementById(`logout-sidebar-btn`);G.addEventListener(`click`,()=>{confirm(`Are you sure you want to log out of PromptIQ?`)&&r()}),m.getElementById(`signin-open-popup-btn`).addEventListener(`click`,h),m.getElementById(`error-open-popup-btn`).addEventListener(`click`,h),N.addEventListener(`change`,()=>{try{typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&chrome.storage.local.set({optimizationMode:N.value})}catch{}}),P.addEventListener(`change`,H);let K=async t=>{if(!(!t.isTrusted||E.disabled)){if(!l||!u){h();return}y.classList.remove(`has-result`),D.style.display=`block`,O.style.display=`none`,m.getElementById(`result-section`).style.display=`none`,E.disabled=!0;try{await e()}catch(e){console.error(`onOptimize failed:`,e)}finally{D.style.display=`none`,!s&&l&&u&&(E.disabled=!1)}}};E.addEventListener(`click`,K),S.addEventListener(`click`,()=>{let e=m.getElementById(`editor-view-title`);b.style.display===`none`?(b.value=x.textContent,b.style.display=`block`,x.style.display=`none`,S.textContent=`View Diff`,e.textContent=`Edit Mode`):(x.style.display=`block`,b.style.display=`none`,S.textContent=`Edit`,e.textContent=`Optimized Draft`)}),w.addEventListener(`click`,()=>{C.classList.toggle(`expanded`),T.textContent=C.classList.contains(`expanded`)?`Hide`:`Show Changes`});function q(e){return String(e??``).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`).replace(/'/g,`&#039;`)}return m.getElementById(`use-btn`).addEventListener(`click`,()=>{t(b.style.display===`none`?x.textContent:b.value),y.classList.remove(`visible`),o.classList.remove(`panel-open`)}),A.addEventListener(`click`,async()=>{let e=b.style.display===`none`?x.textContent:b.value;try{await navigator.clipboard.writeText(e),A.textContent=`Copied`}catch{A.textContent=`Copy failed`}setTimeout(()=>{A.textContent=`Copy`},1600)}),j.addEventListener(`click`,async()=>{let e=f?.original||``;try{await navigator.clipboard.writeText(e),j.textContent=`Copied`}catch{j.textContent=`Copy failed`}setTimeout(()=>{j.textContent=`Copy Original`},1600)}),L.addEventListener(`click`,()=>{z.hidden=!z.hidden,L.textContent=z.hidden?`Compare`:`Hide Compare`}),R.addEventListener(`click`,()=>{R.textContent=typeof i==`function`&&i()?`Undone`:`Nothing to undo`,setTimeout(()=>{R.textContent=`Undo`},1600)}),I.addEventListener(`click`,async()=>{if(!f||typeof a!=`function`)return;let e=b.style.display===`none`?x.textContent:b.value;I.disabled=!0;try{I.textContent=await a({...f,optimized:e,mode:N.value})?`Favorited`:`Favorite`}catch{I.textContent=`Favorite failed`}finally{setTimeout(()=>{I.disabled=!1,I.textContent===`Favorite failed`&&(I.textContent=`Favorite`)},1400)}}),M.addEventListener(`click`,K),m.getElementById(`feedback-yes`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`helpful`),m.getElementById(`feedback-buttons-wrapper`).style.display=`none`,m.getElementById(`feedback-thanks`).style.display=`block`)}),m.getElementById(`feedback-no`).addEventListener(`click`,async()=>{n&&c&&(await n(c,`unhelpful`),m.getElementById(`feedback-buttons-wrapper`).style.display=`none`,m.getElementById(`feedback-thanks`).style.display=`block`)}),{container:o,open:()=>{y.classList.add(`visible`),o.classList.add(`panel-open`)},setCloudRewrite:e=>{p=e;let t=P.querySelector(`option[value="ai_rewrite"]`);t.hidden=t.disabled=!p,U()},clearResult:()=>{c=null,f=null,b.value=``;for(let e of[x,B,V,C])e.replaceChildren();y.classList.remove(`has-result`),m.getElementById(`result-section`).style.display=`none`},setLoggedState:e=>{l=!!e,G.style.display=l?`block`:`none`,U()},setStorageReady:e=>{u=!!e,U()},showAccountRequired:(e=`signin`)=>{y.classList.add(`visible`),o.classList.add(`panel-open`),U()},getSettings:()=>({mode:N.value||`standard`,engine:p&&P.value===`ai_rewrite`?`ai_rewrite`:`quick_rewrite`,disclosureId:p?.id,platform:d||`general`}),setPlatform:e=>{d=e||`general`,F.textContent=g[d]||g.general},toggleVisibility:()=>{let e=y.classList.toggle(`visible`);o.classList.toggle(`panel-open`,e)},setTier:()=>{U()},updateScore:e=>{let t=m.getElementById(`score-dot`),n=m.getElementById(`score-text`),r=m.getElementById(`score-ring-bar`),i=m.getElementById(`score-ring-val`),a=m.getElementById(`score-grade`),o=Math.max(0,Math.min(100,e.score||0)),s=`Empty`;o>=76?s=`Strong`:o>=46?s=`Good`:o>0&&(s=`Weak`),i.textContent=o,a.textContent=s,n.textContent=`PromptIQ: ${o}`,r.setAttribute(`stroke-dasharray`,`${o}, 100`),t.className=`score-dot`,r.style.stroke=`var(--pi-muted)`,a.style.color=`var(--pi-text)`;let c=``,l=`var(--pi-muted)`;o>=76?(c=`score-excellent`,l=`var(--pi-success)`,a.style.color=`var(--pi-success)`):o>=46?(c=`score-good`,l=`var(--pi-warning)`,a.style.color=`var(--pi-warning)`):o>0&&(c=`score-weak`,l=`var(--pi-danger)`,a.style.color=`var(--pi-danger)`),c&&t.classList.add(c),r.style.stroke=l,m.querySelectorAll(`.chip`).forEach(t=>{let n=t.getAttribute(`data-dimension`);e.missing&&e.missing.includes(n)?(t.className=`chip chip-missing`,t.innerHTML=`<span class="chip-icon">✗</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`):(t.className=`chip chip-present`,t.innerHTML=`<span class="chip-icon">✓</span> ${n.charAt(0).toUpperCase()+n.slice(1)}`)})},showResult:(e,t,n,r,i=null,a={})=>{c=r,y.classList.add(`has-result`),O.style.display=`none`,m.getElementById(`result-section`).style.display=`block`,H(),z.hidden=!0,L.textContent=`Compare`,m.getElementById(`feedback-buttons-wrapper`).style.display=`flex`,m.getElementById(`feedback-thanks`).style.display=`none`,I.textContent=`Favorite`,b.value=e;let o=m.getElementById(`score-delta`);if(i&&Number.isFinite(i.originalScore)&&Number.isFinite(i.newScore)){let e=i.newScore-i.originalScore;o.textContent=e>=0?`+${e} pts`:`${e} pts`}else o.textContent=`Improved`;f={original:a.originalPrompt||``,optimized:e,platform:a.platform||d||`general`,intent:a.intent||null,mode:a.mode||N.value||`standard`,scoreOriginal:i?.originalScore??null,scoreOptimized:i?.newScore??null,timestamp:Date.now()},B.textContent=f.original,V.textContent=e,x.innerHTML=t.map(e=>e.added?`<span class="diff-added">${q(e.text)}</span>`:q(e.text)).join(``),C.innerHTML=n.map(e=>`
        <li class="change-item">
          <span class="change-icon" aria-hidden="true">+</span>
          <div class="change-content">
            <span class="change-label">${q(e.label)}:</span>
            <span>${q(e.description)}</span>
          </div>
        </li>
      `).join(``),C.classList.remove(`expanded`),T.textContent=`Show Changes`,x.style.display=`block`,b.style.display=`none`,S.textContent=`Edit`,m.getElementById(`editor-view-title`).textContent=`Optimized Draft`;let s=m.querySelector(`.success-summary`);s.classList.remove(`pulse`),s.offsetWidth,s.classList.add(`pulse`)},showError:e=>{y.classList.remove(`has-result`),D.style.display=`none`,E.disabled=!l||!u,m.getElementById(`result-section`).style.display=`none`;let t=m.getElementById(`error-panel-icon`),n=m.getElementById(`error-panel-title`),r=m.getElementById(`error-panel-message`);if(e.status===401||e.message.toLowerCase().includes(`log in`)||e.message.toLowerCase().includes(`session`)?(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=`Please log in again or try refreshing the page.`):(t.textContent=`!`,n.textContent=`Optimization failed`,r.textContent=e.message||`Please log in again or try refreshing the page.`),O.style.display=`block`,!(e.code===`LOCAL_DAILY_LIMIT_REACHED`||e.code===`PREMIUM_DAILY_LIMIT_REACHED`)&&(e.status===429||e.message.includes(`429`)||e.message.includes(`quota`))){s=!0;let t=e.message.match(/retry in ([\d\.]+)s/i),n=t?Math.ceil(parseFloat(t[1])):60;E.disabled=!0,E.textContent=`Retry in ${n}s`;let r=setInterval(()=>{n--,n<=0?(clearInterval(r),s=!1,U()):E.textContent=`Retry in ${n}s`},1e3)}}}}function h(e,t=2e3){let n,r,i=0;return{reset(){clearTimeout(n),r=null,i=0},schedule(a,o,s){if(clearTimeout(n),!a.trim()){r=null,i=0;return}if(a.length>6e3)return;r||=crypto.randomUUID();let c={kind:`draft`,clientId:r,text:a,platform:o,mode:s,revision:++i};n=setTimeout(()=>{Promise.resolve(e(c)).catch(()=>{})},t)}}}function g(e,t){let n=e.split(/(\s+)/),r=t.split(/(\s+)/),i=Array(n.length+1).fill(null).map(()=>Array(r.length+1).fill(0));for(let e=1;e<=n.length;e++)for(let t=1;t<=r.length;t++)n[e-1]===r[t-1]?i[e][t]=i[e-1][t-1]+1:i[e][t]=Math.max(i[e-1][t],i[e][t-1]);let a=[],o=n.length,s=r.length;for(;o>0||s>0;)o>0&&s>0&&n[o-1]===r[s-1]?(a.unshift({text:n[o-1],added:!1}),o--,s--):s>0&&(o===0||i[o][s-1]>=i[o-1][s])?(a.unshift({text:r[s-1],added:!0}),s--):o--;let c=[];for(let e of a)c.length>0&&c[c.length-1].added===e.added?c[c.length-1].text+=e.text:c.push({...e});return c}var _={role:{label:`Role / Persona`,icon:`👤`},task:{label:`Task Definition`,icon:`🎯`},context:{label:`Context / Background`,icon:`📖`},format:{label:`Output Format`,icon:`📊`},constraints:{label:`Constraints`,icon:`⛔`},specificity:{label:`Specificity`,icon:`🔍`},addition:{label:`Added Detail`,icon:`➕`},modification:{label:`Refined Phrasing`,icon:`✏️`},removal:{label:`Removed Clutter`,icon:`➖`}};function v(e){return Array.isArray(e)?e.map(e=>{let t=(e.type||``).toLowerCase(),n=_[t]||{label:`General Optimization`,icon:`⚡`};return{type:t,label:n.label,icon:n.icon,description:e.description||``}}):[]}var y={coding:/\b(code|function|class|bug|api|debug|regex|database|query|compile|github|git|javascript|js|python|html|css|java|c\+\+|rust|typescript|sql|programming|developer)\b/i,marketing:/\b(marketing|seo|copywriting|ad|email campaign|launch email|newsletter|product launch|sales|social media|instagram|facebook|audience|target market|ctr|conversion|funnel|landing page|brand|copywriter)\b/i,research:/\b(research|literature review|sources?|citations?|evidence|study|paper|methodology|hypothesis)\b/i,creative:/\b(story|novel|poem|fiction|creative writing|character|plot|scifi|dialogue|metaphor|brainstorm|ideas|concept art|fable|script|narrative)\b/i,business:/\b(business|strategy|startup|investor|deck|marketing plan|swot|okr|kpi|pitch|revenue|profit|executive|report|slide|meeting|project management|consultant)\b/i,finance:/\b(finance|stock|investment|budget|valuation|crypto|bitcoin|portfolio|market trend|sheet|accounting|tax|audit|cfo|compound interest)\b/i,education:/\b(teach|learn|course|student|explain to|tutorial|curriculum|grade|lesson|exam|test prep|syllabus|homework|math|science|tutor|educator)\b/i,productivity:/\b(productivity|schedule|habit|workflow|automate|calendar|checklist|to-do|time management|efficiency|organize)\b/i,analysis:/\b(analyze|data|trend|graph|chart|statistics|correlation|outlier|hypothesis|excel|dataset|insight|compare|analyst)\b/i,writing:/\b(write|essay|article|blog post|summarize|paraphrase|grammar|tone|prose|revise|edit|proofread|letter|email|author)\b/i},b={standard:{label:`Standard`,instruction:`Balance clarity, completeness, and practical structure without making the prompt unnecessarily long.`},concise:{label:`Concise`,instruction:`Make the prompt compact and direct while preserving the full task, constraints, and success criteria.`},detailed:{label:`Detailed`,instruction:`Expand context, acceptance criteria, examples, and evaluation rules so the AI has enough detail to produce a high-quality answer.`},creative:{label:`Creative`,instruction:`Encourage distinctive angles, variations, tone options, and ideation while keeping the request usable and bounded.`},technical:{label:`Technical`,instruction:`Emphasize precision, edge cases, implementation constraints, validation steps, and measurable acceptance criteria.`}},x={chatgpt:{label:`ChatGPT`,instruction:`Use clear role, task, context, output format, and constraints sections. Prefer markdown headings and explicit success criteria.`},claude:{label:`Claude`,instruction:`Use natural language instructions with context first, then desired output, constraints, and examples when useful.`},gemini:{label:`Gemini`,instruction:`Use explicit task steps, source/context boundaries, and a clear final-answer format.`},perplexity:{label:`Perplexity`,instruction:`Ask for source-aware analysis, concise synthesis, and separation between facts, assumptions, and recommendations.`},copilot:{label:`Copilot`,instruction:`Specify the environment, expected implementation, error cases, and verification steps.`},deepseek:{label:`DeepSeek`,instruction:`Use precise technical context, constraints, and a validation checklist for the final answer.`},grok:{label:`Grok`,instruction:`Keep the request direct, current-context aware, and explicit about the desired evidence and output.`},mistral:{label:`Le Chat`,instruction:`Use compact instructions, clear context boundaries, and an explicit deliverable.`},meta:{label:`Meta AI`,instruction:`Use straightforward natural language, concrete constraints, and a clear final format.`},poe:{label:`Poe`,instruction:`Keep the prompt model-neutral and state the task, context, constraints, and output clearly.`},you:{label:`You.com`,instruction:`Ask for concise synthesis, source-aware claims when relevant, and a practical final answer.`},general:{label:`AI assistant`,instruction:`Use a broadly compatible prompt structure with clear task, context, output format, and constraints.`}};function S(e){return b[e]?e:`standard`}function C(e){return x[e]?e:`general`}function w(e){let t=e.toLowerCase();for(let[e,n]of Object.entries(y))if(n.test(t))return e;return`general`}function T(e){let t=e.toLowerCase(),n=t.trim().split(/\s+/).filter(Boolean).length,r=/\b(act as|you are|persona|role|specialist|expert|copywriter|developer|designer|analyst|tutor|writer)\b/i.test(t),i=/\b(audience|reader|user|student|customer|client|executive|demographic|viewer)\b/i.test(t),a=/\b(table|markdown|json|bullets|format|structure|list|html|paragraphs|headings|outline|schema)\b/i.test(t),o=/\b(don't|do not|max|limit|avoid|must|restrict|exclude|words|characters|no)\b/i.test(t),s=/\b(write|create|summarize|explain|code|analyze|generate|make|build|list|tweak|improve)\b/i.test(t),c=n>15;return{role:r,audience:i,format:a,constraints:o,objectives:s,context:c,missing:[!r&&`role`,!i&&`audience`,!a&&`format`,!o&&`constraints`,!s&&`objectives`,!c&&`context`].filter(Boolean)}}function E(e,t){let n={coding:[`State assumptions about the language, framework, and runtime when they are not provided.`,`Handle relevant edge cases and include a short verification or test plan.`],marketing:[`Keep claims specific and credible; use labeled placeholders for missing product facts instead of inventing them.`,/\b(email|newsletter)\b/i.test(t)?`Provide three subject line options, preview text, and a polished email body with one clear call to action.`:`Match the message to the intended audience, channel, and desired action.`],research:[`Separate established facts, reasonable inferences, and unresolved questions.`,`Request reliable sources and note important limitations or conflicting evidence.`],business:[`Prioritize decisions, trade-offs, measurable outcomes, and practical next steps.`,`Use relevant metrics or frameworks only when they genuinely clarify the recommendation.`],creative:[`Preserve the requested premise and voice while offering distinctive, non-generic choices.`,`Avoid cliches and keep characters, tone, and continuity consistent.`],finance:[`State assumptions and distinguish calculations from judgment or general information.`,`Call out material risks, uncertainty, and data that should be verified.`],education:[`Explain concepts in a logical sequence and adapt the depth to the learner.`,`Use a short example and a quick check for understanding when useful.`],productivity:[`Turn the request into practical steps with clear priorities and realistic effort.`,`Prefer a simple workflow over unnecessary tools or complexity.`],analysis:[`Use only the supplied data or clearly labeled assumptions.`,`Show the key findings, relevant comparisons, and limitations before recommendations.`],writing:[`Preserve the intended meaning while improving clarity, flow, and tone.`,`Avoid filler, repetition, unsupported claims, and unnecessary formality.`],general:[`Address the request directly and make the result specific enough to use immediately.`,`Do not invent missing facts; ask concise clarifying questions when a missing detail would materially change the answer.`]};return n[e]||n.general}function D(e,t){return e===`coding`?`Return the implementation first, followed by concise setup, verification, and edge-case notes.`:e===`marketing`&&/\b(email|newsletter)\b/i.test(t)?`Return subject lines, preview text, and the final email in clean copy-ready sections.`:e===`research`?`Use clear headings, cite sources where possible, and end with limitations and open questions.`:e===`analysis`||e===`business`||e===`finance`?`Lead with the conclusion, then show supporting analysis and a short action list.`:e===`education`?`Use a step-by-step explanation with one concrete example and a short recap.`:e===`productivity`?`Return a prioritized checklist with owners, timing, or dependencies where relevant.`:e===`creative`?`Return the requested creative work without prefacing it with process commentary.`:`Use the clearest format for the task, with short headings or bullets only when they improve readability.`}function O(e,t={}){if(!e||e.trim()===``)return{enhancedPrompt:``,intent:`general`,missing:[],mode:`standard`,platform:`general`};let n=w(e),r=T(e),i=S(t.mode),a=C(t.platform),o=b[i],s=x[a],c={coding:`expert software engineer`,marketing:`senior marketing copywriter and conversion strategist`,research:`rigorous academic researcher and analyst`,business:`expert business consultant and corporate strategist`,creative:`creative writer and narrative designer`,finance:`senior financial analyst`,education:`expert educator and academic tutor`,productivity:`workflow automation and productivity specialist`,analysis:`senior data analyst`,writing:`professional editor and copyeditor`,general:`highly capable expert assistant`},l=e.trim(),u=E(n,l),d=[];if(!r.role&&i!==`concise`){let e=c[n]||c.general,t=/^[aeiou]/i.test(e)?`an`:`a`;d.push(`Work as ${t} ${e}.`)}d.push(``,`Task`,l,``,`Requirements`);for(let e of u)d.push(`- ${e}`);return d.push(`- ${o.instruction}`),d.push(`- ${s.instruction}`),r.audience||d.push(`- If the intended audience materially affects the answer, ask for it or use a clearly labeled assumption.`),d.push(`- Preserve the original intent and do not add facts, promises, or requirements that were not supplied.`),d.push(``,`Output`,D(n,l)),{enhancedPrompt:d.join(`
`).replace(/^\n+/,``).trim().trim(),intent:n,missing:r.missing,mode:i,platform:a}}var k=null,A=null,j=null,M=``,N=``,P=null,F=!1,I=null,L=0,R=h(e=>I&&t(e,I));async function z(e){let t=++L;F=!1,I=null,R.reset();let n=e===void 0?await a():e,r;if(n)try{r=await o(!0)}catch{}let i=await a();if(!(t!==L||n!==i)&&(F=!!(n&&r?.disclosureVersion===`2026-11-19-v4`),I=F&&r.saveDrafts?n:null,A?.setLoggedState(!!n),A?.setStorageReady(F),A?.setCloudRewrite(null),F&&k&&W(),F)){let e=await c();t===L&&A?.setCloudRewrite(e)}}function B(){return typeof chrome>`u`||!chrome.runtime||!chrome.runtime.id?(V(),!1):!0}function V(){R.reset();try{k&&k.removeEventListener(`input`,W),P&&P.disconnect(),window.removeEventListener(`keydown`,Y);let e=document.getElementById(`promptiq-container`);e&&e.remove()}catch{}}function H(){try{typeof chrome<`u`&&chrome.storage&&chrome.storage.onChanged&&chrome.storage.onChanged.addListener((e,t)=>{if(!(t!==`local`||!A)){if(e.sessionToken){M=``,N=``,A.clearResult(),R.reset();let t=e.sessionToken.newValue;z(t)}e.promptIqCapturePreferencesVersion&&z(),e.userTier&&A.setTier(e.userTier.newValue||`free`)}})}catch{}}async function U(){if(j=p(),!j)return;J(),A&&A.setPlatform(j.platform),await z(await a());let e=j.getInputElement();e&&G(e),K(),X(),Z(),H()}function W(e){if(!B()||!k||!A||!F)return;let t=j.getText(k);I&&e?.isTrusted&&typeof t==`string`&&R.schedule(t,j.platform,A.getSettings().mode);let n=l(t);n.missing=T(t).missing,A.updateScore(n)}function G(e){!e||!A||(k&&k!==e&&(R.reset(),k.removeEventListener(`input`,W)),k=e,k.addEventListener(`input`,W),F&&W())}function K(){P=new MutationObserver(()=>{if(!B())return;let e=j.getInputElement();e&&e!==k&&G(e)}),P.observe(document.body,{childList:!0,subtree:!0})}async function q(){await r(),M=``,N=``,++L,F=!1,I=null,R.reset(),A&&(A.clearResult(),A.setLoggedState(!1),A.setStorageReady(!1),A.setTier(`free`),A.showError(Error(`Signed out. Create an account or sign in to use PromptIQ.`)))}function J(){document.getElementById(`promptiq-container`)||(A=m(Q,ee,re,q,te,ne),document.body.appendChild(A.container))}function Y(e){B()&&e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()===`p`&&(e.preventDefault(),A&&A.toggleVisibility())}function X(){window.addEventListener(`keydown`,Y)}function Z(){try{chrome.runtime.onMessage.addListener((e,t,n)=>{if(B()){if(e.action===`OPTIMIZE_SELECTION`)A?.open(),k&&typeof e.text==`string`&&Q(e.text);else if(e.action===`INSERT_PROMPT`&&k){j.setText(k,e.text);let t=l(e.text);t.missing=T(e.text).missing,A.updateScore(t)}}})}catch{}}async function Q(t=null){if(!B())return;let o=await a();if(!o||!F){A.showAccountRequired(o?`consent`:`signin`);return}let s=(t??j.getText(k)??``).trim();if(!s){A.showError(Error(`Prompt is empty.`));return}if(s.length>6e3){A.showError(Error(`Rewrite supports up to 6,000 characters.`));return}let c=A.getSettings?A.getSettings():{mode:`standard`,platform:j.platform},u=c.mode||`standard`,d=t===null?c.engine:`quick_rewrite`;A&&(A.setLoggedState(!0),A.setStorageReady(!0),A.setTier(`free`));let f=O(s,{mode:u,platform:j.platform}),p,m=d===`ai_rewrite`;try{if(n(`optimization_requested`),m)try{let e=await chrome.runtime.sendMessage({action:`CALL_OPTIMIZER`,originalPrompt:s,platform:j.platform,disclosureId:c.disclosureId,detectedIntent:f.intent,mode:u,token:o});if(!e||!e.success){let t=Error(e?.error||`Failed to optimize prompt.`);throw t.status=e?.status,t.code=e?.code,t}p=e.result}catch(e){if(e.status===401||e.status===403)throw e;await i(`free`),p=$(f),p.changes.unshift({type:`specificity`,description:e.code===`CLOUD_AI_DAILY_LIMIT_REACHED`?`The daily AI Rewrite allowance was used, so PromptIQ completed this rewrite on your device.`:`AI Rewrite was unavailable, so PromptIQ completed this rewrite on your device.`}),m=!1,n(`optimization_fallback_used`)}else await i(`free`),p=$(f);if(o!==await a())return;M=p.optimized;let t=l(s).score,r=l(p.optimized).score,d=await e(s,p.optimized,r-t,j.platform,f.intent,u,t,r,m?`ai_rewrite`:`quick_rewrite`,o);if(o!==await a())return;let h=g(s,p.optimized),_=v(p.changes);A.showResult(p.optimized,h,_,d,{originalScore:t,newScore:r},{originalPrompt:s,platform:j.platform,intent:f.intent,mode:u,engine:m?`ai_rewrite`:`quick_rewrite`,tier:`free`}),n(`optimization_completed`)}catch(e){if(n(`optimization_failed`),e.code===`CLOUD_AI_DAILY_LIMIT_REACHED`||e.code===`LOCAL_DAILY_LIMIT_REACHED`)A&&A.showError(e);else if(e.status===401||e.status===403)await r(),F=!1,R.reset(),A&&(A.setLoggedState(!1),A.setStorageReady(!1),A.setTier(`free`)),A.showError(Error(`Your account session expired. Sign in again to continue.`));else if(e.message&&e.message.includes(`Extension context invalidated`)){let e=Error(`PromptIQ has been updated. Please refresh the page to continue.`);A.showError(e)}else A&&A.showError(e)}}function $(e){let t={role:`Added an expert role to guide tone and decision quality.`,task:`Clarified the objective and preserved the original request.`,context:`Added context guidance so the response is complete and useful.`,format:`Specified a structured output format for easier use.`,constraints:`Added practical boundaries to reduce vague or generic output.`,specificity:`Expanded the request with audience and delivery details.`};return{optimized:e.enhancedPrompt,changes:[`role`,`task`,`context`,`format`,`constraints`,`specificity`].map(e=>({type:e,description:t[e]}))}}function ee(e){if(!B()||!F||!k?.isConnected)return;let t=e||M;if(t){N=j.getText(k)||``,j.setText(k,t);let e=l(t);e.missing=T(t).missing,A.updateScore(e),n(`prompt_inserted`)}}function te(){if(!B()||!F||!N||!k?.isConnected)return!1;j.setText(k,N);let e=l(N);return e.missing=T(N).missing,A.updateScore(e),N=``,!0}async function ne(e){if(!B())return!1;let t=await s(e);return n(`favorite_toggled`),t.favorite}async function re(e,t){if(!B()||!e)return;let n=await a();if(n)try{await fetch(`https://promptiq-theta.vercel.app/api/feedback`,{method:`POST`,headers:{Authorization:`Bearer ${n}`,"Content-Type":`application/json`},body:JSON.stringify({id:e,feedback:t})})}catch{console.warn(`PromptIQ feedback could not be saved`)}}U();